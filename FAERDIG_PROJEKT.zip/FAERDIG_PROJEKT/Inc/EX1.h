/*
 * EX1.h
 *
 *  Created on: 7. jan. 2026
 *      Author: root
 */



#ifndef EX1_H_
#define EX1_H_

#include <stdint.h>
#include <stdio.h>

void PRN(uint8_t *code, uint16_t N);
uint8_t getFeedback(uint8_t P[10], uint8_t *FB, uint8_t N);
void shift(uint8_t P[10]);
uint8_t getOutput(uint8_t P1[10], uint8_t P2[10], uint8_t *O1, uint8_t *O2, uint8_t N1, uint8_t N2);
void PRN_alt(uint8_t* code, int16_t N);


#endif /* EX1_H_ */
