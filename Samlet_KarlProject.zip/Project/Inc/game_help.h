#ifndef GAME_HELP_H_
#define GAME_HELP_H_

#include "game_manager.h"

GameState help_update(void);

#endif
