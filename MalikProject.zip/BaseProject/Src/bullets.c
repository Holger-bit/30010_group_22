/*
 * bullets.c
 *
 *  Created on: 15 Jan 2026
 *      Author: malik
 */

#define FIX16_SHIFT 16
#define FIX16_MULT(a,b)  ( (int32_t)(((int64_t)(a) * (b)) >> FIX16_SHIFT) )
#define FIX16_DIV(a,b)   ( (int32_t)(((int64_t)(a) << FIX16_SHIFT) / (b)) )

#include "vect.h"
#include "Trigfunc.h"
#include "bullets.h"
#include "ansi.h"
#include "joys.h"
#include <stdio.h>

bullet_t bullets[MAX_BULLETS];
static uint8_t next_bullet = 0;

static int16_t origin_x = 0;
static int16_t origin_y = 0;

// for edge detect (shoot once per press)
static uint8_t prevJoy = 0;

// optional cooldown (prevents bounce / too-fast shots)
static uint8_t fireCooldown = 3;

// initialisere bullet
void initbullet(bullet_t *b, int32_t x, int32_t y, int32_t vx, int32_t vy)
{
    b->pos.x = x << 16;
    b->pos.y = y << 16;
    b->prev = b->pos;

    b->vel.x = vx << 16;
    b->vel.y = vy << 16;

    b->active = 1;
}

// Initialisere Bullets systemet
void bullets_init(void)
{
    for (int i = 0; i < MAX_BULLETS; i++) {
        bullets[i].active = 0;
        bullets[i].pos.x = bullets[i].pos.y = 0;
        bullets[i].prev.x = bullets[i].prev.y = 0;
        bullets[i].vel.x = bullets[i].vel.y = 0;
    }
    next_bullet = 0;
}

void bullets_set_origin(int x, int y)
{
    origin_x = (int16_t)x;
    origin_y = (int16_t)y;
}

void opdaterbullet(bullet_t *b, int32_t factor)
{
    if (!b->active) return;

    // Gemmer gamle placering for at rykke bolden
    b->prev = b->pos;

    int32_t k = factor << 16;

    // finder min position ved brug af ligningen x = x + vx *k
    b->pos.x += FIX16_MULT(b->vel.x, k);
    b->pos.y += FIX16_MULT(b->vel.y, k);

    // kill bullet if outside screen
    int16_t x = b->pos.x >> 16;
    int16_t y = b->pos.y >> 16;

    if (x < 0 || x >= 150 || y < 0 || y >= 50) {
        b->active = 0;
        b->prev = b->pos;   // makes erase consistent
    }
}

// Tegner bold
void tegnbullet(const bullet_t *b)
{
	if (!b->active) return;

	// Finder x, y værdier af hvor min bold skal være
	uint8_t x = (uint8_t)(b->pos.x >> 16);
	uint8_t y = (uint8_t)(b->pos.y >> 16);

	// Placerer min bold på skærmen
	gotoxy(x,y);
	printf("%c", 248);
}

void sletbullet(const bullet_t *b)
{
	// Finder placering af gammel bold
    uint8_t x = (uint8_t)(b->prev.x >> 16);
    uint8_t y = (uint8_t)(b->prev.y >> 16);

    // sletter hvad der var der
    gotoxy(x, y);
    printf(" ");
}

void shoot(int x, int y, int vx, int vy)
{
    // try to find an inactive bullet first
    for (int i = 0; i < MAX_BULLETS; i++) {
        if (!bullets[i].active) {
            initbullet(&bullets[i], x, y, vx, vy);
            return;
        }
    }

    // none free -> overwrite one (round-robin)
    initbullet(&bullets[next_bullet], x, y, vx, vy);
    next_bullet++;
    if (next_bullet >= MAX_BULLETS) next_bullet = 0;
}

void tick(void)
{
    // 1) update all bullets (movement)
    for (int i = 0; i < MAX_BULLETS; i++) {
        opdaterbullet(&bullets[i], 1);
    }

    // 2) handle shooting (read joystick)
    uint8_t joy = readJoystick();

    if (fireCooldown > 0) fireCooldown--;

    // shoot once on press (rising edge)
    if ((joy & JOY_CENTER) && !(prevJoy & JOY_CENTER)) {
        if (fireCooldown == 0) {
            shoot(origin_x + 1, origin_y, 1, 0);
            fireCooldown = 12;
        }
    }

    prevJoy = joy;
}

void bullets_poll(void)
{
    for (int i = 0; i < MAX_BULLETS; i++) {
        if (!bullets[i].active) continue;

        // slet gammel position
        sletbullet(&bullets[i]);

        // update position
        opdaterbullet(&bullets[i], 1);

        // tegn ny position (hvis stadig aktiv)
        if (bullets[i].active) {
            tegnbullet(&bullets[i]);
        }
    }
}
