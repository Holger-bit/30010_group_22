/*
 * projectiles.h
 *
 *  Created on: 16. jan. 2026
 *      Author: root
 */

#include "30010_io.h"
#include <stdint.h>
#include <stdio.h>

#ifndef PROJECTILES_H_
#define PROJECTILES_H_

#define MAX_PROJECTILES 100

typedef struct {
    int32_t x, y;
    int32_t vx, vy;
    uint8_t active;
} Projectile;

void updateProjectiles(Projectile bullets[]);

#endif /* PROJECTILES_H_ */
