#include "stm32f30x_conf.h" // STM32 config
#include "30010_io.h" // Input/output library for this course
#include "ansi.h"
#include "vect.h"
#include "joys.h"
#include "bullets.h"
#include "entity.h"
#include "timer.h"
#include "SPIL.h"

int main(void)
{
	uart_init(115200);
    clrscr();
    uart_init(115200);

	//winscreen();
	run_game_manager();

	while(1);
}

//int main(void)
//{
//	uart_init(9600);
//	clrscr();
//
//	joystick_init();
//	rgb_init();
//	while (1)
//	{
//		uint8_t js = readjoystick();
//		joytoRGB(js);
//	}
//}

//{
//	uart_init(9600);
//	clrscr();
//	joystick_init();
//
//	while (1)
//	{
//		joystickprint();
//	}
//}

//{
//	uart_init(115200);
//	Playballgame(1,1,80,20);
//}

//{
//    uart_init(9600);
//    clrscr();
//    windowwtitle(1,1,80,20, "--- Ball game --- Ball game --- Ball game --- Ball game --- Ball game ---", 1);
//    while (1) { }
//}

//{
//	uart_init(9600);
//	clrscr();
//
//	vector_t v;
//
//	//(1,2) i 16.16
//	initVector(&v, 1 << 16, 2 << 16);	// &v henter adressen af v
//	rotateVectorPrint(&v, 0);     // (1,2)
//	rotateVectorPrint(&v, 256);         // 180°/360*512 = 256 steps
//
//
//	//(6,4) i 16.16
//	initVector(&v, 6 << 16, 4 << 16);		// &v henter adressen af v
//	rotateVectorPrint(&v, 0);     // (6, 4)
//	rotateVectorPrint(&v, -14);	// -10°/360*512 = -14,22222 steps
//
//	//(-4,-4) i 16.16
//	initVector(&v, -4 << 16, -4 << 16);		// &v henter adressen af v
//	rotateVectorPrint(&v, 0);     // (-4, -4)
//	rotateVectorPrint(&v, 1280);	// 900°/360*512 = 900 steps
//
//	//(-4,2) i 16.16
//	initVector(&v, -4 << 16, 2 << 16);		// &v henter adressen af v
//	rotateVectorPrint(&v, 0);     // (4, 2)
//	rotateVectorPrint(&v, -49);	// -35°/360*512 =  steps
//	while (1) { }
//}


//{
//	uart_init(9600);
//
//	clrscr();
//
//	cosinus(0);      // cosin(0)
//	cosinus(64);     // cosin(45°) = sin(45/360*512)
//	cosinus(-111 	);   // cosin(-78°)
//	cosinus(923);    // cosin(649°)
//
//	sinus(0);
//	sinus(64);
//	sinus(-111);
//	sinus(923);
//
//	while (1) { }
//}


//{
//    uart_init(9600);
//    clrscr();
//    window(5,5,25,25, "Hello World", 1);
//    window(30,5,50,25, "Hello Gamers?", 0);
//    while (1) { }
//}

//{
	// Prepare variables
	//uint8_t i;
	//uint8_t code[10];

	// Setup communication with the PC
	//uart_init(9600);

	// Calculate PRN code
	//printf("SV1 PRN: ");
	//PRN(code,10);

	// Print code
	//for (i = 0 ; i < 10 ; i++){
	//	printf("%d,",code[i]);
	//}
	//printf("...\n");

	//while (1) { }
//}
