/*
 * RGB.c
 *
 *  Created on: 13 Jan 2026
 *      Author: malik
 */

#include "RGB.h"
#include "stm32f30x.h"
#include "joys.h"

#define PIN_BLUE 9 // PA9
#define PIN_GREEN 7 // PC7
#define PIN_RED 4 // PB4

// Lave GPIO pin til en output pin
// 'port' = GPIOA, GPIOB, GPIOC, ...
// 'pin'  = pin number (0–15)
static inline void pin_output(GPIO_TypeDef *port, uint8_t pin)
{
	port->MODER &= ~(0x3u << (pin*2)); // clearer mode bits af en bestemt pin
	port->MODER |= (0x1u << (pin*2)); // Sætter tilstanden til output
}

void rgb_init(void)
{
	//Aktivere GPIO klokke
	// RCC->AHBENR er hvad der aktiver
	// |= betyder sæt disse bits og behold andet uændret
	RCC->AHBENR |= RCC_AHBPeriph_GPIOA // Aktivering af port A
				| RCC_AHBPeriph_GPIOB // Aktivering af port B
				| RCC_AHBPeriph_GPIOC; // Aktivering af port C

	// Definer output for all mine pins
	pin_output(GPIOA, PIN_BLUE);
	pin_output(GPIOC, PIN_GREEN);
	pin_output(GPIOB, PIN_RED);

	// slukker for alle LED'er
	GPIOA->ODR |= (1u << PIN_BLUE);
	GPIOC->ODR |= (1u << PIN_GREEN);
	GPIOB->ODR |= (1u << PIN_RED);
}

void setLed(LedColor c)
{
    // kriterier for at tænde LED'er
	uint8_t r=0, g=0, b=0;

	// definer mine forskellige muligheder for farver efter det input jeg giver.
    switch (c)
    {
        case LED_RED:     r=1; break;
        case LED_GREEN:   g=1; break;
        case LED_BLUE:    b=1; break;
        case LED_CYAN:    g=1; b=1; break;
        case LED_MAGENTA: r=1; b=1; break;
        case LED_YELLOW:  r=1; g=1; break;
        case LED_WHITE:   r=1; g=1; b=1; break;
        case LED_OFF:
        default:          break;
    }

	// tænder for PB4 (red)
	if (r) GPIOB->BSRR = (1u << (PIN_RED + 16)); else GPIOB->BSRR = (1u << PIN_RED);
	// tænder for PC7 (green)
	if (g) GPIOC->BSRR = (1u << (PIN_GREEN + 16)); else GPIOC->BSRR = (1u << PIN_GREEN);
	// tænder for PA9 (blue)
	if (b) GPIOA->BSRR = (1u << (PIN_BLUE + 16)); else GPIOA->BSRR = (1u << PIN_BLUE);
}

void joytoRGB(uint8_t js)
{
	if (js & JOY_UP)          setLed(LED_GREEN);
	else if (js & JOY_DOWN)   setLed(LED_RED);
	else if (js & JOY_LEFT)   setLed(LED_BLUE);
	else if (js & JOY_RIGHT)  setLed(LED_MAGENTA);
	else if (js & JOY_CENTER) setLed(LED_WHITE);
	else                      setLed(LED_OFF);
}
