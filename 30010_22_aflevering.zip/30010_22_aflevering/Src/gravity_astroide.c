#include "gravity_astroide.h"
#include "ansi.h"
#include <stdio.h>

//når astroide ikke flyttes
void updateAsteroid(Asteroid *a) {

    gotoxy(a->x, a->y);     printf("     ");
    gotoxy(a->x, a->y + 1); printf("     ");
    gotoxy(a->x, a->y + 2); printf("     ");


    a->x += a->vx;


    if (a->x > 94) a->x = 2;
    if (a->x < 2) a->x = 94;


    gotoxy(a->x, a->y);     printf(" ___ ");
    gotoxy(a->x, a->y + 1); printf("|   |");
    gotoxy(a->x, a->y + 2); printf("|___|");
}

// når astroide ikke flyttes
void drawAsteroid(Asteroid *a) {
    gotoxy(a->x, a->y);     printf(" ___ ");
    gotoxy(a->x, a->y + 1); printf("|   |");
    gotoxy(a->x, a->y + 2); printf("|___|");
}
