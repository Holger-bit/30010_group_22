#include <stdint.h>
#include <stdio.h>
#include "stm32f30x_conf.h" // STM32 config
#include "30010_io.h" // Input/output library for this course
#include "LED.h"

void setupLed(void){
	//enable clock for alle portene
	RCC->AHBENR |= RCC_AHBPeriph_GPIOA; // Enable clock for GPIO Port A
	RCC->AHBENR |= RCC_AHBPeriph_GPIOB; // Enable clock for GPIO Port B
	RCC->AHBENR |= RCC_AHBPeriph_GPIOC; // Enable clock for GPIO Port C

	// Set pin PB4 to output, rød
	GPIOB->OSPEEDR &= ~(0x00000003 << (4 * 2)); // Clear speed register
	GPIOB->OSPEEDR |= (0x00000002 << (4 * 2)); // set speed register (0x01 - 10MHz, 0x02 - 2 MHz, 0x03 - 50 MHz)
	GPIOB->OTYPER &= ~(0x0001 << (4 * 1)); // Clear output type register
	GPIOB->OTYPER |= (0x0000 << (4)); // Set output type register (0x00 - Push pull, 0x01 - Open drain)
	GPIOB->MODER &= ~(0x00000003 << (4 * 2)); // Clear mode register
	GPIOB->MODER |= (0x00000001 << (4 * 2)); // Set mode register (0x00 – Input, 0x01 - Output, 0x02 - Alternate Function, 0x03 - Analog in/out)

	// Set pin PC7 to output, Grøn
	GPIOC->OSPEEDR &= ~(0x00000003 << (7 * 2)); // Clear speed register
	GPIOC->OSPEEDR |= (0x00000002 << (7 * 2)); // set speed register (0x01 - 10MHz, 0x02 - 2 MHz, 0x03 - 50 MHz)
	GPIOC->OTYPER &= ~(0x0001 << (7 * 1)); // Clear output type register
	GPIOC->OTYPER |= (0x0000 << (7)); // Set output type register (0x00 - Push pull, 0x01 - Open drain)
	GPIOC->MODER &= ~(0x00000003 << (7 * 2)); // Clear mode register
	GPIOC->MODER |= (0x00000001 << (7 * 2)); // Set mode register (0x00 – Input, 0x01 - Output, 0x02 - Alternate Function, 0x03 - Analog in/out)


	// Set pin PA9 to output, blå
	GPIOA->OSPEEDR &= ~(0x00000003 << (9 * 2)); // Clear speed register
	GPIOA->OSPEEDR |= (0x00000002 << (9 * 2)); // set speed register (0x01 - 10MHz, 0x02 - 2 MHz, 0x03 - 50 MHz)
	GPIOA->OTYPER &= ~(0x0001 << (9 * 1)); // Clear output type register
	GPIOA->OTYPER |= (0x0000 << (9)); // Set output type register (0x00 - Push pull, 0x01 - Open drain)
	GPIOA->MODER &= ~(0x00000003 << (9 * 2)); // Clear mode register
	GPIOA->MODER |= (0x00000001 << (9 * 2)); // Set mode register (0x00 – Input, 0x01 - Output, 0x02 - Alternate Function, 0x03 - Analog in/out)





}

void setLed(uint8_t colour)

{
	//sluk det gamle lys
	GPIOB->ODR |= (0x0001 << 4);
	GPIOC->ODR |= (0x0001 << 7);
	GPIOA->ODR |= (0x0001 << 9);

	// de er lavet så de 3 sidst cifre er RGB
	switch(colour)
{
	case 0b00000001:
		GPIOA->ODR &= ~(0x0001 << 9); //blå Set pin PA9 to low
		break;
	case 0b00000010:
		GPIOC->ODR &= ~(0x0001 << 7); //grøn Set pin PC7 to low
		break;
	case 0b00000100:
		GPIOB->ODR &= ~(0x0001 << 4); //rød, Set pin PB4 to low
		break;
	case 0b00000011:
		GPIOA->ODR &= ~(0x0001 << 9); //blå Set pin PA9 to low
		GPIOC->ODR &= ~(0x0001 << 7); //grøn Set pin PC7 to low
		break;
	case 0b00000101:
		GPIOA->ODR &= ~(0x0001 << 9); //blå Set pin PA9 to low
		GPIOB->ODR &= ~(0x0001 << 4); //rød, Set pin PB4 to low
		break;
	case 0b00000110:
		GPIOB->ODR &= ~(0x0001 << 4); //rød, Set pin PB4 to low
		GPIOC->ODR &= ~(0x0001 << 7); //grøn Set pin PC7 to low
		break;
	case 0b00000111:
		GPIOA->ODR &= ~(0x0001 << 9); //blå Set pin PA9 to low
		GPIOC->ODR &= ~(0x0001 << 7); //grøn Set pin PC7 to low
		GPIOB->ODR &= ~(0x0001 << 4); //rød, Set pin PB4 to low
		break;
	default:
		break;
}
}
