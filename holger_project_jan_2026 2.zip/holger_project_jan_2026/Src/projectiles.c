/*
 * projectiles.c
 *
 *  Created on: 16. jan. 2026
 *      Author: root
 */
#include "projectiles.h"
#include "ansi.h"
#include "30010_io.h"
#include "spil.h"
#include "gravity_astroide.h"
#include <stdint.h>
#include <stdio.h>



void updateProjectiles(Projectile bullets[]) {
    static uint8_t move_counter = 0;

    // Vi kører kun logikken hver 5. frame for at styre farten
    if (++move_counter >= 5) {
        for (int i = 0; i < MAX_PROJECTILES; i++) {
            if (bullets[i].active) {

                // 1. SLET skuddet på dets nuværende plads med det samme!
                gotoxy(bullets[i].x, bullets[i].y);
                printf(" ");

                // 2. TYNGDEKRAFT (Beregnes mens skuddet er "i luften")
                // Asteroiden er y, y+1, y+2 høj. Midten er y+1.
                int32_t dist_x = (rocky.x + 2) - bullets[i].x;
                int32_t dist_y = (rocky.y + 1) - bullets[i].y;

                if (abs(dist_x) < 12 && abs(dist_y) < 8) {
                    if (dist_x > 0) bullets[i].x++;
                    else if (dist_x < 0) bullets[i].x--;
                }

                // 3. RYK skuddet (Hastighed)
                bullets[i].x += bullets[i].vx;
                bullets[i].y += bullets[i].vy;

                // 4. TJEK KOLLISION (Ramte vi asteroiden nu?)
                if (bullets[i].x >= rocky.x && bullets[i].x < (rocky.x + 5) &&
                    bullets[i].y >= rocky.y && bullets[i].y < (rocky.y + 3))
                {
                    bullets[i].active = 0; // Skuddet dør
                    continue; // Gå videre til næste skud i arrayet
                }

                // 5. TJEK KANT (Er skuddet røget ud af banen?)
                if (bullets[i].y < 2 || bullets[i].x < 2 || bullets[i].x > 98) {
                    bullets[i].active = 0;
                    continue;
                }

                // 6. TEGN skuddet på den nye position
                gotoxy(bullets[i].x, bullets[i].y);
                printf("*");
            }
        }
        move_counter = 0; // Nulstil farten
    }
}
