#include "enemy.h"
#include "ansi.h"
#include <stdio.h>

#define WIN_X1 1
#define WIN_Y1 1
#define WIN_X2 100
#define WIN_Y2 50

#define PLAY_MIN_X (WIN_X1 + 1)   // 2
#define PLAY_MAX_X (WIN_X2 - 1)   // 99
#define PLAY_MIN_Y (WIN_Y1 + 1)   // 2
#define PLAY_MAX_Y (WIN_Y2 - 1)   // 49

// enemy sprite is 7 wide, 4 tall
static int enemy_inside_playfield(int x, int y)
{
    return (x >= PLAY_MIN_X && x <= (PLAY_MAX_X - 6) &&
            y >= PLAY_MIN_Y && y <= (PLAY_MAX_Y - 3));
}

static void printEnemy(uint8_t x, uint8_t y, uint8_t enemy_type)
{
    if (!enemy_inside_playfield(x, y)) return;

    (void)enemy_type; // only type 1 used right now

    gotoxy(x, y);     printf(" /\\_/\\ ");
    gotoxy(x, y + 1); printf("( 0 0 )");
    gotoxy(x, y + 2); printf("=(_Y_)=");
    gotoxy(x, y + 3); printf("  V-V  ");
}

static void clearEnemy(uint8_t x, uint8_t y)
{
    if (!enemy_inside_playfield(x, y)) return;

    gotoxy(x, y);     printf("       ");
    gotoxy(x, y + 1); printf("       ");
    gotoxy(x, y + 2); printf("       ");
    gotoxy(x, y + 3); printf("       ");
}

static void killEnemy(enemy_t *e)
{
    clearEnemy((uint8_t)e->x, (uint8_t)e->y);
    e->alive = 0;
    e->x = 0;
    e->y = 0;
}

static void detectBottomCollision(enemy_t enemies[], uint8_t enemy_count)
{
    for (uint8_t i = 0; i < enemy_count; i++) {
        if (!enemies[i].alive) continue;

        if (enemies[i].y > (PLAY_MAX_Y - 3)) { // 46 for your window
            killEnemy(&enemies[i]);
        }
    }
}

void enemy_init(enemy_t enemies[], uint8_t *enemy_count,
                uint8_t *enemy_start, uint8_t *enemy_step,
                uint8_t *spawn_x, uint8_t *spawn_y)
{
    for (uint8_t i = 0; i < MAX_ENEMIES; i++) {
        enemies[i].alive = 0;
        enemies[i].x = 0;
        enemies[i].y = 0;
    }

    *enemy_count = 0;
    *enemy_start = 0;
    *enemy_step = 0;

    *spawn_x = PLAY_MIN_X;  // 2
    *spawn_y = PLAY_MIN_Y;  // 2
}

void enemy_spawn(enemy_t enemies[], uint8_t *enemy_count, uint8_t *enemy_start,
                 uint8_t *spawn_x, uint8_t *spawn_y)
{
    if (*enemy_count >= MAX_ENEMIES) return;

    enemies[*enemy_count].x = (int8_t)(*spawn_x);
    enemies[*enemy_count].y = (int8_t)(*spawn_y);
    enemies[*enemy_count].alive = 1;
    (*enemy_count)++;

    // next spawn x (keep within safe range: <= PLAY_MAX_X-6)
    *spawn_x = (uint8_t)(*spawn_x + 9);
    if (*spawn_x > (PLAY_MAX_X - 6)) {
        *spawn_x = PLAY_MIN_X;
    }

    *enemy_start = 1;
}

void enemy_tick(uint8_t *enemy_step,
                uint16_t *spawn_counter, uint16_t *move_counter)
{
    (*spawn_counter)++;
    (*move_counter)++;

    if (*spawn_counter >= 1000) {
        // spawn itself is done in SPil.c (so we don’t need enemy_count here)
        *spawn_counter = 0;
    }

    if (*move_counter >= 100) {
        *enemy_step = 1;
        *move_counter = 0;
    }
}

void enemy_update_and_render(enemy_t enemies[], uint8_t enemy_count,
                             uint8_t *enemy_start, uint8_t *enemy_step)
{
    if (*enemy_step) {
        // move
        for (uint8_t i = 0; i < enemy_count; i++) {
            if (enemies[i].alive) {
                enemies[i].y++;
            }
        }

        detectBottomCollision(enemies, enemy_count);

        // render
        for (uint8_t i = 0; i < enemy_count; i++) {
            if (enemies[i].alive) {
                clearEnemy((uint8_t)enemies[i].x, (uint8_t)(enemies[i].y - 1));
                printEnemy((uint8_t)enemies[i].x, (uint8_t)enemies[i].y, 1);
            }
        }

        *enemy_step = 0;
    }

    if (*enemy_start && enemy_count > 0) {
        printEnemy((uint8_t)enemies[enemy_count - 1].x,
                   (uint8_t)enemies[enemy_count - 1].y, 1);
        *enemy_start = 0;
    }
}

void enemy_handle_bullets(enemy_t enemies[], uint8_t *enemy_count,
                          bullet_t bullets[])
{
    (void)enemy_count; // not needed, but kept for symmetry / future

    // We need count from caller. So assume caller passes correct count in *enemy_count:
    uint8_t n = *enemy_count;

    for (uint8_t i = 0; i < n; i++) {
        if (!enemies[i].alive) continue;

        int ex = enemies[i].x;
        int ey = enemies[i].y;

        int ex2 = ex + 6;
        int ey2 = ey + 3;

        for (uint8_t b = 0; b < MAX_BULLETS; b++) {
            if (!bullets[b].active) continue;

            int bx = (int)(bullets[b].pos.x >> 16);
            int by = (int)(bullets[b].pos.y >> 16);

            if (bx >= ex && bx <= ex2 && by >= ey && by <= ey2) {
                killEnemy(&enemies[i]);
                bullets[b].active = 0;
                break;
            }
        }
    }
}

