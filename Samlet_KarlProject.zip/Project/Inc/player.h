#ifndef PLAYER_H
#define PLAYER_H

#include <stdint.h>

typedef struct {
    int32_t x;
    int32_t y;
    uint8_t w;
    uint8_t h;
    int8_t  tilt;

    uint8_t left_pressed;
    uint8_t right_pressed;
    uint8_t left_timer;
    uint8_t right_timer;

    uint16_t move_counter;
} Entity;

void player_tick(Entity *p);
void player_init(Entity *p);
void player_handle_input(Entity *p, char key, uint8_t joystick);
void makeplayer(Entity *p, int erase);
void player_erase(Entity *p, int32_t old_x, int8_t old_tilt);
void player_draw(Entity *p);

#endif
