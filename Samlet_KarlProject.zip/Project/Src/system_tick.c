#include "system_tick.h"
#include "enemy.h"
#include "player.h"
#include "powerup.h"
#include "LCDpush.h"

extern Entity g_player;

void system_tick(void)
{
    enemy_tick();
    player_tick(&g_player);
    lcd_tick();
    powerup_tick();
//    bullets_tick();
}
