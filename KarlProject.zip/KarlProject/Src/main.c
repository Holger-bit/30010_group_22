#include "30010_io.h"
#include "timer.h"
#include "stopwatch.h"
#include "joystick.h"
#include "ansi.h"
#include "levels.h"
#include "enemy.h"
#include "system_tick.h"

int main(void) {
//	uint8_t j;
//	uint8_t j_old = 0;

    uart_init(115200);
    clrscr();

    setJoystick();

    stopwatch_init();

    timer15_setCallback(system_tick);
    timer15_init();

    stopwatch_start();

//    writelvl();



    while (1) {
    	enemy();
    }
}
