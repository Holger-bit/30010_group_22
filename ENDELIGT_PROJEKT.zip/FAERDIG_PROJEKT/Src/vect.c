/*
 * vect.c
 *
 *  Created on: 19. jan. 2026
 *      Author: root
 */
//#include "vect.h"
//#include "LUT_sin.h"
//#include <stdio.h>
//
//#define FIX16_SHIFT 16
//#define FIX16_MULT(a,b)  ( (int32_t)(((int64_t)(a) * (b)) >> FIX16_SHIFT) )
//#define FIX16_DIV(a,b)   ( (int32_t)(((int64_t)(a) << FIX16_SHIFT) / (b)) )
//
//void initVector(vector_t *v, int32_t x, int32_t y){
//	(*v).x = x;
//	(*v).y = y;
//}
//
//// tager en vector som input og en vinkel/360*512, dernæst giver det en roteret vector
//void rotateVector(vector_t *v, int32_t vinkel){
//	int32_t x = (*v).x; // opretter en ny variable for x i 16.16
//	int32_t y = (*v).y; // opretter en ny variable for y i 16.16
//
//	int32_t s16 = ((int32_t)sinus(vinkel)) << 2;    // 16.16
//	int32_t c16 = ((int32_t)cosinus(vinkel)) << 2;  // 16.16
//
//	int32_t xm = FIX16_MULT(x,c16) - FIX16_MULT(y,s16);
//	int32_t ym = FIX16_MULT(x,s16) + FIX16_MULT(y,c16);
//
//	//Previous code
//	//int64_t xm = ((int64_t)x*c-(int64_t)y*s) >> 16;
//	//int64_t ym = ((int64_t)x*s+(int64_t)y*c) >> 16;
//
//	// konverter fra 18.14 til 16.16
//	(*v).x = xm;
//	(*v).y = ym;
//}
//
//void rotateVectorPrint(vector_t *v, int32_t vinkel){
//    rotateVector(v, vinkel);
//    printf("(");
//    printFix(v->x);
//    printf(", ");
//    printFix(v->y);
//    printf(")\r\n");
//}
//

