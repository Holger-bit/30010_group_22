/*
 * EX4.h
 *
 *  Created on: 7. jan. 2026
 *      Author: root
 */

#ifndef EX4_H_
#define EX4_H_
#include <stdint.h>
#include <stdio.h>
typedef struct {
    int32_t x, y;   // Position
    int32_t vx, vy; // Hastighed (f.eks. 1 eller -1)
} Ball;

void window2(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2);
void vindue(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2);
int updateBall(Ball *b, uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2);
#endif /* EX4_H_ */
