/*
 * stopwatch.h
 *
 *  Created on: 14 Jan 2026
 *      Author: malik
 */

#ifndef STOPWATCH_H_
#define STOPWATCH_H_

void timer15_setcallback(void (*cb)(void));
void timer15_init(void);
void TIM1_BRK_TIM15_IRQHandler(void);

#endif /* STOPWATCH_H_ */
