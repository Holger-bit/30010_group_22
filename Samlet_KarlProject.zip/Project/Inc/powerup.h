#ifndef POWERUP_H_
#define POWERUP_H_

#include <stdint.h>
#include <stdbool.h>

void use_powerup(void);
void powerup_tick(void);
bool powerup_is_empty(void);
bool powerup_is_ready(void);
bool powerup_is_active(void);
uint8_t powerup_get_offset(void);

#endif /* POWERUP_H_ */
