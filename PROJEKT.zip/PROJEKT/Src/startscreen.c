/*
 * startscreen.c
 *
 *  Created on: 13. jan. 2026
 *      Author: root
 */
#include "ansi.h"
#include <stdint.h>
#include <stdio.h>
#include "startscreen.h"
#include "SPIL.h"

void maketitle(){
	clrscr();
	printf("\x1b[?25l"); // Skjul cursoren

	uint8_t x = 5;
	uint8_t y = 5;



	gotoxy(x,y);
	printf(" ######  ########     ###     ######  ########      ##     ##    ###    ##     ##");
	gotoxy(x,++y);
	printf("##    ## ##     ##   ## ##   ##    ## ##            ##     ##   ## ##   ###   ###");
	gotoxy(x,++y);
	printf("##       ##     ##  ##   ##  ##       ##            ##     ##  ##   ##  #### ####");
	gotoxy(x,++y);
	printf(" ######  ########  ##     ## ##       ######        ######### ##     ## ## ### ##");
	gotoxy(x,++y);
	printf("      ## ##        ######### ##       ##            ##     ## ######### ##     ##");
	gotoxy(x,++y);
	printf("##    ## ##        ##     ## ##    ## ##            ##     ## ##     ## ##     ##");
	gotoxy(x,++y);
	printf(" ######  ##        ##     ##  ######  ########      ##     ## ##     ## ##     ##");

	uint8_t etnytypunkt = 22;
	uint8_t etnytxpunkt = 40;

	gotoxy(etnytxpunkt,etnytypunkt);
	printf("    .--.  .-'''-.  .--.");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("   /.--./'.-. .-.`\\.--.\\");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("   ||  / / .| | .\\ \\  ||");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("   \\\\_/| \\__| |__/ |\\_//");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("    `-'\\  .-----.  /`-'");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("        \\/       \\/");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("        (\\`.___.'/)");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("         \\`.___.'/");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("          `.___.'");
}

void make_menu(uint8_t selected, uint16_t highscore){
	uint8_t x = 5;
	uint8_t y = 12;

	uint8_t style1; // Stil til Start Game
	uint8_t style2; // Stil til Help

	if (selected == 0) {
	    // Hvis "Start Game" er valgt (0)
	    style1 = 0; // Dobbeltstreg til Start Game
	    style2 = 1; // Enkeltstreg til Help
	} else {
	    // Hvis "Help" er valgt (1)
	    style1 = 1; // Enkeltstreg til Start Game
	    style2 = 0; // Dobbeltstreg til Help
	}


	window(x,y+10, x+12, y+12, "Start game", style1);

	window(x,y+16, x+12, y+18, "Help", style2);

	gotoxy(40, 17);
	printf("HIGHSCORE: %04d", highscore);


}
