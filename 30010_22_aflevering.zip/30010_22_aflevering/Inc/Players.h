/*
 * Player.h
 *
 *  Created on: 15. jan. 2026
 *      Author: root
 */
#include "30010_io.h"
#include <stdint.h>
#include <stdio.h>
#include "spil.h"
#include "ansi.h"


#ifndef PLAYER_H_
#define PLAYER_H_


typedef struct {
    int32_t x, y;  // Position
    int32_t w, h;    // Bredde og højde
    int8_t tilt; // tilt (bruges også i bullet)
} Entity;

void makeplayer(Entity * p, int erase);

#endif /* PLAYER_ENEMIES_H_ */
