/*
 * EX5.h
 *
 *  Created on: 8. jan. 2026
 *      Author: root
 */
#include <stdint.h>
#include <stdio.h>

#ifndef EX5_H_
#define EX5_H_

// farve definitioner 0b00000RGB
#define COLOUR_BLACK (0b00000000)
#define COLOUR_RED (0b00000100)
#define COLOUR_GREEN (0b00000010)
#define COLOUR_BLUE (0b00000001)
#define COLOUR_CYAN (0b00000011)
#define COLOUR_PINK (0b00000101)
#define COLOUR_YELLOW (0b00000110)
#define COLOUR_WHITE (0b00000111)


void setupjoystick(void);
uint8_t readJoystick();
void setLed(uint8_t joystickposition);
void setupLed(void);



#endif /* EX5_H_ */
