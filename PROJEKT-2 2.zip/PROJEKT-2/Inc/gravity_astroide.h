#ifndef GRAVITY_ASTROIDE_H_
#define GRAVITY_ASTROIDE_H_

#include <stdint.h>
#include "ansi.h"

// 1. Definition af typen Asteroid
typedef struct {
    int32_t x, y;
    int32_t vx;
} Asteroid;


// Prototyper
void updateAsteroid(Asteroid *a);
void drawAsteroid(Asteroid *a);

#endif
