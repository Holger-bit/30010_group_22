/*
 * bullets.h
 *
 *  Created on: 15 Jan 2026
 *      Author: malik
 */

#ifndef BULLETS_H_
#define BULLETS_H_

#include <stdint.h>
#include "vect.h"
#include "gravity_astroide.h"

// Bestemt antal bullet tilstand vi kan have i en instans
#define MAX_BULLETS 10

// definer en enkelt bullet struktur og den tilstand den kan være i
typedef struct {
    vector_t pos;     // positino 16.16
    vector_t vel;     // hastighed 16.16
    vector_t prev;    // tidliger position16.16
    uint8_t active;   // 0 = unused, 1 = active
} bullet_t;

//Antal bullets vi kan have i en instans
#define MAX_BOMBS 10

// // definer en enkelt bombe struktur og den tilstand den kan være i
typedef struct {
    int16_t x, y;        // Coordinater
    int8_t  vx, vy;      // Hastighed
    int16_t fuse;        // Nedtælling til hvornår bomben går af
    uint8_t active;      // enten 0 eller 1
    char under_char;     // what to restore
} Bomb;

void bullets_init(bullet_t bullets[], uint8_t *next_bullet);
void shoot(bullet_t bullets[], uint8_t *next_bullet,
    int x, int y, int vx, int vy, int k
);

void bullets_poll(bullet_t bullets[], const Asteroid *rocky);

void bombs_init(Bomb bombs[]);
void bomb_spawn(Bomb bombs[], int x, int y, int vx, int vy, int fuse);
void bombs_update(Bomb bombs[], bullet_t bullets[]);
void bullets_spawn_explosion(bullet_t bullets[], int x, int y);

static int point_in_enemy(int x, int y, int *hit_index);

#endif /* BULLETS_H_ */

