/*
 * Ballgame.c
 *
 *  Created on: 8 Jan 2026
 *      Author: malik
 */

#define FIX16_SHIFT 16
#define FIX16_MULT(a,b)  ( (int32_t)(((int64_t)(a) * (b)) >> FIX16_SHIFT) )
#define FIX16_DIV(a,b)   ( (int32_t)(((int64_t)(a) << FIX16_SHIFT) / (b)) )

#include "vect.h"
#include "Trigfunc.h"
#include "Ballgame.h"
#include "ansi.h"
#include <stdio.h>

// initialisere bolden
void initball(ball_t *b, int32_t x, int32_t y, int32_t vx, int32_t vy)
{
	b->pos.x = x << 16;
	b->pos.y = y << 16;
	b->vel.x = vx << 16;
	b->vel.y = vy << 16;
}

// Opdater boldens position
void opdaterball( ball_t *b, int32_t factor)
{
	// Gemmer gamle placering for at rykke bolden
	b->prev = b->pos;

	// laver min værdi i 16.16
	int32_t k = factor << 16;

	// finder min position ved brug af ligningen x = x + vx *k
	b->pos.x += FIX16_MULT(b->vel.x, k);
	b->pos.y += FIX16_MULT(b->vel.y, k);
}

// Tegner bold op
void tegnball(const ball_t *b)
{
	// Finder x, y værdier af hvor min bold skal være
	uint8_t x = (uint8_t)(b->pos.x >> 16);
	uint8_t y = (uint8_t)(b->pos.y >> 16);

	// Placerer min bold på skærmen
	gotoxy(x,y);
	printf("o");
}

void sletball(const ball_t *b)
{
	// Finder placering af gammel bold
    uint8_t x = (uint8_t)(b->prev.x >> 16);
    uint8_t y = (uint8_t)(b->prev.y >> 16);

    // sletter hvad der var der
    gotoxy(x, y);
    printf(" ");
}

static void delay(volatile uint32_t d)
{
    while (d--) { }
}

uint8_t checkCollision(ball_t *b, uint8_t x1, uint8_t y1,
		uint8_t x2, uint8_t y2, uint32_t *hits)
{
	// Kollisions tæller
	uint8_t collided = 0;

	// Optegner grænser som bolden skal bevæge sig indenfor
	int32_t minx = (x1 + 1) << 16;
	int32_t maxx = (x2 - 1) << 16;
	int32_t miny = (y1 + 1) << 16;
	int32_t maxy = (y2 - 1) << 16;

	//venstre og højre væg
	if (b->pos.x <= minx)
	{
		b->pos.x=minx;
		b->vel.x = - b->vel.x;
		collided = 1;
	}
	else if (b->pos.x >= maxx)
	{
		b->pos.x=maxx;
		b->vel.x = - b->vel.x;
		collided = 1;
	}

	//Øvre og nedre væg
	if (b->pos.y <= miny)
	{
		b->pos.y=miny;
		b->vel.y = - b->vel.y;
		collided = 1;
	}
	else if (b->pos.y >= maxy)
	{
		b->pos.y=maxy;
		b->vel.y = - b->vel.y;
		collided = 1;
	}

	// Tæller antal kollisioner
	if (collided && hits) {
		(*hits)++;
	}
	return collided;
}

static void vishits(uint8_t x1, uint8_t x2, uint8_t y1, uint32_t hits)
{
	gotoxy((uint8_t)((x1 + x2) / 2),y1);
	printf("Hits:%lu",(unsigned long)hits);
}

void moveball(ball_t *b, uint8_t x1, uint8_t y1,
		uint8_t x2, uint8_t y2)
{
	uint32_t hits = 0;

	while(1)
	{
		// sletter gammel bold
		sletball(b);

		// opdater placering
	    opdaterball(b, 1);

	    //checker kollisioner
	    checkCollision( b, x1, y1, x2, y2, &hits);

	    //Tegner gits counter
	    vishits(x1, x2, y1, hits);

	    // Tegner ny bold
	    tegnball(b);
	    delay(200000);
	}
}

void Playballgame( uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2)
{
	//initialises ball
	ball_t bold;
	initball(&bold,20,10,1,1);
	ball_t bold1;
	initball(&bold1,30,15,2,2);

	// starten om på skærmen
	clrscr();

	// tegn væggen
	windowwtitle(x1, y1, x2, y2,"--- Ball game --- Ball game --- Ball game --- Ball game --- Ball game ---", 1);

	// bevæge bold
	moveball(&bold, x1, y1, x2, y2);
	moveball(&bold1, x1, y1, x2, y2);

}
