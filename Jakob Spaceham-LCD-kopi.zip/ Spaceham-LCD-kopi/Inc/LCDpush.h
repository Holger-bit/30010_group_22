#ifndef LCDPUSH_H_
#define LCDPUSH_H_

#include <stdint.h>
#include <stdbool.h>

void lcd_write_string(uint8_t *buffer, char* string, uint16_t line);
void lcd_scroll(uint8_t *buffer);
void lcd_write_heart(uint8_t *buffer, char* string, uint16_t line);
void lcd_hearts_remove(char *hearts);
void lcd_write_bomb(uint8_t *buffer, char* string, uint16_t line);
void lcd_bombs_remove(char *hearts);
void lcd_write_timer(uint8_t *buffer, char* string, uint16_t line, uint8_t offset);
void lcd_write_powerup(uint8_t *buffer, char* string, uint16_t line);
void lcd_write_score(uint8_t *buffer, uint16_t line, uint16_t score);
void lcd_delay_ms(uint32_t ms);
void game_over(uint8_t *buffer);
bool hit(void);
void lcd_clear(uint8_t *buffer);
uint32_t sys_millis(void);
void time_init(void);
void SysTick_Handler(void);


#endif
