/*
 * Player_enemies.c
 *
 *  Created on: 15. jan. 2026
 *      Author: root
 */
#include "Player_enemies.h"



void makeplayer(Entity *p, int erase) {
    // Vi har 5 tilt-stadier og raketten er 6 linjer høj
    char *sprites[5][6] = {
        // [0]: MEGET VENSTRE (-2) -> Top: \\;
        { "\\\\    ", " . . ", " |o| ", " |o| ", " .-. ", "|/-\\|" },
        // [1]: LIDT VENSTRE (-1)  -> Top: \;
        { " \\   ", " . . ", " |o| ", " |o| ", " .-. ", "|/-\\|" },
        // [2]: LIGE UD (0)        -> Top: |
        { "  |  ", " . . ", " |o| ", " |o| ", " .-. ", "|/-\\|" },
        // [3]: LIDT HØJRE (1)     -> Top: /
        { "   / ", " . . ", " |o| ", " |o| ", " .-. ", "|/-\\|" },
        // [4]: MEGET HØJRE (2)    -> Top: //
        { "    //", " . . ", " |o| ", " |o| ", " .-. ", "|/-\\|" }
    };

    // SIKKERHED: Tving index til at være mellem 0 og 4
    int index = p->tilt + 2;
    if (index < 0) index = 0;
    if (index > 4) index = 4;

    for (int i = 0; i < 6; i++) {
        gotoxy(p->x, p->y + i);
        if (erase) {
            printf("      "); // Sletter 6 tegn
        } else {
            // Vi bruger %-6s for at sikre at den altid printer 6 tegn
            printf("%-6s", sprites[index][i]);
        }
    }
}
