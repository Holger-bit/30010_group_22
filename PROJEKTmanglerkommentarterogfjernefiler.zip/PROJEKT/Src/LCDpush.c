/*
 * LCDpush.c
 *
 *  Created on: 16. jan. 2026
 *      Author: root
 */

#include "LCDpush.h"
#include <stdio.h>
#include "charset.h"
#include "stm32f30x.h"
#include <string.h>
#include <stdbool.h>
#include "30010_io.h"






void lcd_write_string(uint8_t *buffer, char* string, uint16_t line)
{
	uint8_t len = (uint8_t) (strlen(string)); //finder laengden af string
	for (uint8_t k = 0; k<len; k++){ //looper gennem laengden af string og counter k
		uint8_t a = string[k]; //assigner characteren ved k'ende loop til a
		for (uint8_t j = 0; j<5; j++){//looper gennem 0-5 for at assigne en ascii kode til hvert index
			uint8_t b;
			b = character_data[a-32][j];//saetter b = ascii kode for hvert loop
			*(buffer + line + j) = b; //indexerer bufferen og saetter ascii koden til den
	}
		line += 6; // rykker frem bufferen frem til ny character naeste loop

}
}


void lcd_write_powerup(uint8_t *buffer, char* string, uint16_t line)
{
	const uint8_t symbol[] = {0x1C, 0x22, 0x49, 0x5D, 0x49, 0x22, 0x1C};

	uint8_t len = (uint8_t) (strlen(string)); //finder laengden af string
	for (uint8_t k = 0; k<len; k++){ //looper gennem laengden af string og counter k
		for (uint8_t j = 0; j<7; j++){//looper gennem 0-5 for at assigne en ascii kode til hvert index
			uint8_t b;
			b = symbol[j];//saetter b = ascii kode for hvert loop
			*(buffer + line + j) = b; //indexerer bufferen
	}
		line += 8; // rykker bufferen frem til ny character naeste loop
}
}


void lcd_draw_timer(uint8_t *buffer, uint8_t powerlen, uint16_t line, uint8_t timer_offset)
{

    if (timer_offset >= powerlen) return; // stop timer naar timeren udloeber

    // Effekt: "forsvind fra venstre mod højre":
    // Vi starter med at rykke line til højre med offset*3,
    // og tegner derefter resten.
    line += (uint16_t)(timer_offset * 3u);// Rykker linjen hver gang offset oeges, saa det ligner den rykker sig mod venstre


    for (uint8_t k = timer_offset; k < powerlen; k++)//
    {
        buffer[line + 0] = 0x78, 0x78, 0x78;
        buffer[line + 1] = 0x78, 0x78, 0x78;
        buffer[line + 2] = 0x78, 0x78, 0x78;
        line += 3;
    }
}

void lcd_draw_timer_omvendt(uint8_t *buffer, uint8_t bomblen, uint16_t line, uint8_t bombtimer_offset)
{
    const uint8_t buffertimer[8] = {0x78, 0x78, 0x78, 0x78, 0x78, 0x78, 0x78, 0x78};

    if (bombtimer_offset >= bomblen) return; // timer udløbet

    // Antal blokke der stadig skal vises
    uint8_t visible = bomblen - bombtimer_offset;

    for (uint8_t k = 0; k < visible; k++)
        {
            // skriv ALLE 9 bytes
            for (uint8_t i = 0; i < 8; i++) {
                buffer[line + i] = buffertimer[i];
            }

            line += 8; // næste "blok"
        }
    }


void lcd_write_score(uint8_t *buffer, uint16_t line, uint16_t score)
{
    if (score > 9999) score = 9999;

    char s[5];
    s[0] = '0' + (score / 1000);
    s[1] = '0' + (score / 100) % 10;
    s[2] = '0' + (score / 10)  % 10;
    s[3] = '0' + (score % 10);
    s[4] = '\0';

    lcd_write_string(buffer, s, line);
}

void lcd_write_heart(uint8_t *buffer, char* string, uint16_t line)
{
	const uint8_t heart[] = { 0x1C, 0x3E, 0x7E, 0xFC, 0x7E, 0x3E, 0x1C };
	uint8_t len = (uint8_t) (strlen(string)); //finder laengden af string

	for (uint8_t k = 0; k<len; k++){ //looper gennem laengden af string og counter k
		for (uint8_t j = 0; j<7; j++){//looper gennem 0-5 for at assigne en ascii kode til hvert index
			uint8_t b;
			b = heart[j];//saetter b = ascii kode for hvert loop
			*(buffer + line + j) = b; //indexerer bufferen og saetter ascii koden til den
	}
		line += 8; // rykker frem bufferen frem til ny character naeste loop
}
}

void lcd_write_bomb(uint8_t *buffer, char* string, uint16_t line)
{
	const uint8_t bomb[] = { 0x38, 0x7C, 0xFE, 0xFE, 0xFE, 0x7D, 0x39 };
	uint8_t len = (uint8_t) (strlen(string)); //finder laengden af string

	 line += 51;

	for (uint8_t k = 0; k<len; k++){ //looper gennem laengden af string og counter k
		for (uint8_t j = 0; j<7; j++){//looper gennem 0-5 for at assigne en ascii kode til hvert index
			uint8_t b;
			b = bomb[j];//saetter b = ascii kode for hvert loop
			*(buffer + line + j) = b; //indexerer bufferen og saetter ascii koden til den
	}
		line += 8; // rykker frem bufferen frem til ny character naeste loop
}
}


void lcd_hearts_remove(char *hearts)
{
    size_t len = strlen(hearts);
    if (len > 0) {
        hearts[len - 1] = '\0';   // fjerner sidste “heart”
    }
}

void lcd_bombs_remove(char *hearts)
{
    size_t len = strlen(hearts);
    if (len > 0) {
        hearts[len - 1] = '\0';   // fjerner sidste “heart”
    }

}

void game_over(uint8_t *buffer)
{
    memset(buffer, 0x00, 512);              // ryd skærmbuffer (brug evt. sizeof(buffer) der hvor den findes)
    lcd_write_string(buffer, "GAME OVER", 60);
    lcd_push_buffer(buffer);
}



void lcd_clear(uint8_t *buffer)
{
    memset(buffer, 0x00, 512);
    lcd_push_buffer(buffer);
}








