/*
 * bullets.c
 *
 *  Created on: 15 Jan 2026
 *      Author: malik
 */

// genvej til at gange eller dividere med 16.16 fixed point numre
#define FIX16_SHIFT 16
#define FIX16_MULT(a,b)  ( (int32_t)(((int64_t)(a) * (b)) >> FIX16_SHIFT) )
#define FIX16_DIV(a,b)   ( (int32_t)(((int64_t)(a) << FIX16_SHIFT) / (b)) )

// genvej til at handle med negative tal og få den absolute værdi
#define IABS32(x) (((x) < 0) ? -(x) : (x))

// vindue skærm genveje
#define WIN_X1 1
#define WIN_Y1 1
#define WIN_X2 100
#define WIN_Y2 50
#define PLAY_MIN_X (WIN_X1 + 1)   // 2
#define PLAY_MAX_X (WIN_X2 - 1)   // 99
#define PLAY_MIN_Y (WIN_Y1 + 2)   // 3
#define PLAY_MAX_Y (WIN_Y2 - 1)   // 49

// Asteroid bredde og længde
#define AST_W 5
#define AST_H 3
// Hvor tæt man skal være inden man bliver påvirket af tyngrkraft i char
#define GRAVITY_RANGE_X 12
#define GRAVITY_RANGE_Y 8
// Træk kraft i 16.16
#define GRAVITY_PULL_X  (1 << 15)   // 0.5 char
#define GRAVITY_PULL_Y  (1 << 14)   // 0.25 char

// Enemies bredde og højde
#define ENEMY_W 7
#define ENEMY_H 4

#include "bullets.h"
#include "gravity_astroide.h"
#include "enemy.h"
#include "ansi.h"
#include <stdio.h>
static int point_in_enemy(int x, int y, int *hit_index);

// initialisere bullet
static void initbullet(bullet_t *b, int32_t x, int32_t y, int32_t vx, int32_t vy)
{
    b->pos.x = x << 16;
    b->pos.y = y << 16;
    b->prev = b->pos;

    b->vel.x = vx << 16;
    b->vel.y = vy << 16;

//    // Dividere hastighed med 4 da hastigheden er for hurtig ved at shifte
//    b-> vel.x >>= 2;
//	b-> vel.y >>= 2;

    b->active = 1;
}

static int inside_playfield(int x, int y)
{
    // Checker om mit objekt er inde i der hvor spillet foregår
	return (x >= PLAY_MIN_X && x <= PLAY_MAX_X &&
            y >= PLAY_MIN_Y && y <= PLAY_MAX_Y);
}

static void apply_asteroid_gravity_and_collision(bullet_t *b, const Asteroid *rocky)
{
    // bullets heltal positioner (skærm coordinator)
    int32_t bX = (int32_t)(b->pos.x >> 16);
    int32_t bY = (int32_t)(b->pos.y >> 16);

    // Finder afstanden mellem min bullet og asteroide
    int32_t dx = (rocky->x + 2) - bX;
    int32_t dy = (rocky->y + 1) - bY;

    // 1) tyngdekraft trækker hvis man er tæt nok på
    if (IABS32(dx) < GRAVITY_RANGE_X && IABS32(dy) < GRAVITY_RANGE_Y) {

    	//kigger på afhængigt om bullets er til højre eller venstre for asteroiden
    	//trækker skuddet mod asteroidens midte for x
    	if (dx > 0) b->pos.x += GRAVITY_PULL_X;
        else if (dx < 0) b->pos.x -= GRAVITY_PULL_X;

    	//samme for y
        if (dy > 0) b->pos.y += GRAVITY_PULL_Y;
        else if (dy < 0) b->pos.y -= GRAVITY_PULL_Y;
    }

    // 2) sammenstød med asteroid (sletter bullet)
    if (bX >= rocky->x && bX < (rocky->x + AST_W) &&
        bY >= rocky->y && bY < (rocky->y + AST_H))
    {
    	//deaktivere bullet
        b->active = 0;
    }
}


//opdater bullet informationer
static void opdaterbullet(bullet_t *b, int32_t factor, const Asteroid *rocky)
{
    if (!b->active) return;

    // Gemmer gamle placering for at rykke bolden
    b->prev = b->pos;

    int32_t k = factor << 16;

    // finder min position ved brug af ligningen x = x + vx *k
    b->pos.x += FIX16_MULT(b->vel.x, k);
    b->pos.y += FIX16_MULT(b->vel.y, k);

    // laver tyngdekraft + asteroid kollision
    apply_asteroid_gravity_and_collision(b, rocky);


	if (!b->active) return;

    // kill bullet if outside screen
    int16_t x = (int16_t)(b->pos.x >> 16);
    int16_t y = (int16_t)(b->pos.y >> 16);


    //register hvis en enemy er dræbt
	int hit_i;
	if (point_in_enemy(x, y, &hit_i)) {
		killEnemy(&enemies[hit_i]);
		b->active = 0;
		return;
	}

    if (!inside_playfield(x, y)) {
        b->active = 0;
        return;
    }
}

// Tegner bold
static void tegnbullet(const bullet_t *b)
{
	if (!b->active) return;

	// Finder x, y værdier af hvor min bold skal være
	uint8_t x = (uint8_t)(b->pos.x >> 16);
	uint8_t y = (uint8_t)(b->pos.y >> 16);

	if (!inside_playfield(x, y)) return;   // never draw the frame

	// Placerer min bold på skærmen
	gotoxy(x,y);
	printf("%c", 248);
}

//Registrer hvorvidt bullet er i fjender
static int point_in_enemy(int x, int y, int *hit_index)
{
    // looper over alle mine fjender
	for (int i = 0; i < MAX_ENEMIES; i++) {
        // hop over døde fjender
		if (!enemies[i].alive) continue;

		// Registrer hvorvidt mine fjender og et vilkårligt punkt overlapper
        if (x >= enemies[i].x && x < (enemies[i].x + ENEMY_W) &&
            y >= enemies[i].y && y < (enemies[i].y + ENEMY_H))
        {
            //Tæller om det overlapper
        	if (hit_index) *hit_index = i;
            return 1;
        }
    }
    return 0;
}

// sletter tidligere instanser
static void sletbullet(const bullet_t *b)
{
	// Finder placering af gammel bold
    uint8_t x = (uint8_t)(b->prev.x >> 16);
    uint8_t y = (uint8_t)(b->prev.y >> 16);

    // ser om bullet er indenfor vinduet
    if (!inside_playfield(x, y)) return;

    //ser om bullet er i fjender
    if (point_in_enemy(x, y, NULL)) return;

    // sletter hvad der var i prev position
    gotoxy(x, y);
    printf(" ");
}

// Initialisere min ledige skud
void bullets_init(bullet_t bullets[], uint8_t *next_bullet)
{
	// Kigger gennem hver brugt eller ubrugt skuds tilstand
    for (int i = 0; i < MAX_BULLETS; i++) {

    	//Resetter mine skud til ikke at være aktive
        bullets[i].active = 0;

        //Resetter min x go y position
        bullets[i].pos.x = bullets[i].pos.y = 0;

        //Resetter min tidligere position i x og y
        bullets[i].prev.x = bullets[i].prev.y = 0;

        //Resetter min hastighed i x og y
        bullets[i].vel.x = bullets[i].vel.y = 0;
    }
    *next_bullet = 0;
}

// Skyder
void shoot(bullet_t bullets[],uint8_t *next_bullet,
    int x, int y, int vx, int vy, int k)
{

	// try to find an inactive bullet first
	for (int i = 0; i < MAX_BULLETS; i++) {
        if (!bullets[i].active) {
            initbullet(&bullets[i], x, y, vx, vy);
            // faktor der gøre bullets langsommere
            bullets[i].vel.x >>= k;
            bullets[i].vel.y >>= k;
            return;
        }
    }

	// none free -> overwrite one (round-robin)
    initbullet(&bullets[*next_bullet], x, y, vx, vy);
    (*next_bullet)++;
    if (*next_bullet >= MAX_BULLETS) *next_bullet = 0;
}

void bullets_poll(bullet_t bullets[], const Asteroid *rocky)
{
    for (int i = 0; i < MAX_BULLETS; i++) {
    	// Always erase previous position
    	sletbullet(&bullets[i]);

    	// Only update/draw if bullet is active
    	if (bullets[i].active) {
    		opdaterbullet(&bullets[i], 1, rocky);

        	if (bullets[i].active) {
        		tegnbullet(&bullets[i]);
        	}
    	}
    }
}

// Initialisere en bombe
void bombs_init(Bomb bombs[])
{
	// Kigger enkeltvis gennem hver bombe
    for (int i = 0; i < MAX_BOMBS; i++) {

    	// resetter min bombe så den kan benyttes
        bombs[i].active = 0;

        //resetter min bombes positino
        bombs[i].x = bombs[i].y = 0;

        //resetter min bombes hastighed
        bombs[i].vx = bombs[i].vy = 0;

        //restter fuse til bomben
        bombs[i].fuse = 0;

        //restter baggrunds character
        bombs[i].under_char = ' ';
    }
}

// Generer mine bomber
void bomb_spawn(Bomb bombs[], int x, int y, int vx, int vy, int fuse)
{
	//Generer en bombe ud fra mine ledige bombe tilstande
    for (int i = 0; i < MAX_BOMBS; i++) {

    	//Hvis jeg ikke har en aktiv bombe generer jeg en bombe
        if (!bombs[i].active) {

        	//Sætter den til aktiv
            bombs[i].active = 1;

            //Sætter min position til der hvor jeg ønsker bomben
            bombs[i].x = (int16_t)x;

            //sætter min y værdi
            bombs[i].y = (int16_t)y;

            //Sætter hastighed i x
            bombs[i].vx = (int8_t)vx;

            //Sætter hastighed i y
            bombs[i].vy = (int8_t)vy;

            //Sætter min fuse's tid
            bombs[i].fuse = (int16_t)fuse;

            //Sætter min baggrund på pladsen
            bombs[i].under_char = ' ';
            return;
        }
    }
}

// Laver 7 skud i forskellige retnigner fra (x,y)
void bullets_spawn_explosion(bullet_t bullets[], int x, int y)
{
    // 7 retninger defineres at skulle skyde i
    static const int8_t dirs[7][2] = {
        { 0,-1}, { 1, 0}, {-1, 0},
        { 1,-1}, {-1,-1}, { 1, 1}, {-1, 1}
    };

    // Looper over mine forskellige retninger og generer en ny bullet
    for (int d = 0; d < 7; d++) {

        // Fidner en fri bullet slot
        for (int i = 0; i < MAX_BULLETS; i++) {
            if (!bullets[i].active) {

                initbullet(&bullets[i], x, y, dirs[d][0], dirs[d][1]);

                break; // gå til næste retning direction
            }
        }
    }
}

void bombs_update(Bomb bombs[], bullet_t bullets[])
{
    //Starter en move counter til at tælle min bevægelse
	static uint32_t move_counter = 0;
    move_counter++;

    if (move_counter < 5) return;
    move_counter = 0;


    for (int i = 0; i < MAX_BOMBS; i++) {
        if (!bombs[i].active) continue;

        // 1) Genskabe baggrunden under bomben
        gotoxy(bombs[i].x, bombs[i].y);
        printf("%c", bombs[i].under_char);

        // 2) bevæge bomben
        bombs[i].x += bombs[i].vx;
        bombs[i].y += bombs[i].vy;

        // 3) fuse tæller ned
        bombs[i].fuse--;

        // 4) exploder
        if (bombs[i].fuse <= 0) {
            bullets_spawn_explosion(bullets, bombs[i].x, bombs[i].y);
            bombs[i].active = 0;
            continue;
        }

        // 5) Sluk for bombe funktionen hvis den er udenfor min playing field
        if (!inside_playfield(bombs[i].x, bombs[i].y)) {
            bombs[i].active = 0;
            continue;
        }

        // 6) gem baggrund
        bombs[i].under_char = ' ';

        // 7) Tegn bombe
        gotoxy(bombs[i].x, bombs[i].y);
        printf("%c", 79);
    }
}
