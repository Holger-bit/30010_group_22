#include "system_tick.h"
#include "stopwatch.h"
#include "enemy.h"


void system_tick(void)
{
    stopwatch_tick();
    enemy_tick();
}
