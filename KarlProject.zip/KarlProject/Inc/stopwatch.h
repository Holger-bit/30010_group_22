#ifndef STOPWATCH_H
#define STOPWATCH_H

#include <stdint.h>

typedef struct {
    uint8_t hsec;
    uint8_t sec;
    uint8_t min;
    uint8_t hour;
} stopwatch_time_t;

void stopwatch_init(void);

void stopwatch_start(void);
void stopwatch_startstop(void);
void stopwatch_reset(void);
void stopwatch_split1(void);
void stopwatch_split2(void);

// Called every 0.01 s from timer interrupt
void stopwatch_tick(void);

// Read current time safely
stopwatch_time_t stopwatch_getTime(void);

void stopwatch(void);

#endif
