#include "LCDpush.h"
#include <stdio.h>
#include "charset.h"
#include "stm32f30x.h"
#include <string.h>
#include <stdbool.h>
#include "30010_io.h"
#include "LED.h"
#include "powerup.h"


static uint16_t score = 0;
static char hearts[] = "123";
static char timer_str[] = "01234567890123456789"; // *****// 20 tegn
static uint8_t update_lcd = 0;
static uint8_t full_redraw = 1;




void lcd_write_string(uint8_t *buffer, char* string, uint16_t line)
{
	uint8_t len = (uint8_t) (strlen(string)); //finder laengden af string
	for (uint8_t k = 0; k<len; k++){ //looper gennem laengden af string og counter k
		uint8_t a = string[k]; //assigner characteren ved k'ende loop til a
		for (uint8_t j = 0; j<5; j++){//looper gennem 0-5 for at assigne en ascii kode til hvert index
			uint8_t b;
			b = character_data[a-32][j];//saetter b = ascii kode for hvert loop
			*(buffer + line + j) = b; //indexerer bufferen og saetter ascii koden til den
	}
		line += 6; // rykker frem bufferen frem til ny character naeste loop

}
}

void lcd_write_powerup(uint8_t *buffer, char* string, uint16_t line)
{
	const uint8_t symbol[] = {0x1C, 0x22, 0x49, 0x5D, 0x49, 0x22, 0x1C};

	uint8_t len = (uint8_t) (strlen(string)); //finder laengden af string
	for (uint8_t k = 0; k<len; k++){ //looper gennem laengden af string og counter k
		for (uint8_t j = 0; j<7; j++){//looper gennem 0-5 for at assigne en ascii kode til hvert index
			uint8_t b;
			b = symbol[j];//saetter b = ascii kode for hvert loop
			*(buffer + line + j) = b; //indexerer bufferen
	}
		line += 8; // rykker bufferen frem til ny character naeste loop
}
}


void lcd_write_timer(uint8_t *buffer, char *string, uint16_t line, uint8_t offset)
{
    const uint8_t timer[3] = {0x78, 0x78, 0x78};// timer udseende

    uint8_t len = (uint8_t)strlen(string);
    if (offset >= len) return; // stop timer naar timeren udloeber

    // Effekt: "forsvind fra venstre mod højre":
    // Vi starter med at rykke line til højre med offset*3,
    // og tegner derefter resten.
    line += (uint16_t)(offset * 3u);// Rykker linjen hver gang offset oeges, saa det ligner den rykker sig mod venstre


    for (uint8_t k = offset; k < len; k++)//
    {
        buffer[line + 0] = timer[0];
        buffer[line + 1] = timer[1];
        buffer[line + 2] = timer[2];
        line += 3;
    }
}



void lcd_write_score(uint8_t *buffer, uint16_t line, uint16_t score)
{
    if (score > 9999) score = 9999;

    char s[5];
    s[0] = '0' + (score / 1000);
    s[1] = '0' + (score / 100) % 10;
    s[2] = '0' + (score / 10)  % 10;
    s[3] = '0' + (score % 10);
    s[4] = '\0';

    lcd_write_string(buffer, s, line);
}

void lcd_write_heart(uint8_t *buffer, char* string, uint16_t line)
{
	const uint8_t heart[] = { 0x1C, 0x3E, 0x7E, 0xFC, 0x7E, 0x3E, 0x1C };
	uint8_t len = (uint8_t) (strlen(string)); //finder laengden af string

	for (uint8_t k = 0; k<len; k++){ //looper gennem laengden af string og counter k
		for (uint8_t j = 0; j<7; j++){//looper gennem 0-5 for at assigne en ascii kode til hvert index
			uint8_t b;
			b = heart[j];//saetter b = ascii kode for hvert loop
			*(buffer + line + j) = b; //indexerer bufferen og saetter ascii koden til den
	}
		line += 8; // rykker frem bufferen frem til ny character naeste loop
}
}


void lcd_hearts_remove(char *hearts)
{
    size_t len = strlen(hearts);
    if (len > 0) {
        hearts[len - 1] = '\0';   // fjerner sidste “heart”
        full_redraw = 1;
    }
}

void game_over(uint8_t *buffer)
{
    memset(buffer, 0x00, 512);              // ryd skærmbuffer (brug evt. sizeof(buffer) der hvor den findes)
    lcd_write_string(buffer, "GAME OVER", 60);
    lcd_push_buffer(buffer);
}


void lcd_clear(uint8_t *buffer)
{
    memset(buffer, 0x00, 512);
    lcd_push_buffer(buffer);
}


void lcd_update(void)
{
    static uint8_t buffer[512];

    if (!update_lcd) return;
    update_lcd = 0;

    if (full_redraw) {
        memset(buffer, 0x00, sizeof(buffer));
        full_redraw = 0;
    }

    lcd_write_heart(buffer, hearts, 1);
    lcd_write_score(buffer, 104, score);

    /* ---- POWERUP RENDERING ---- */

    if (powerup_is_empty()) {
        setLed(COLOUR_BLACK);
    }
    if (powerup_is_ready()) {
        setLed(COLOUR_BLUE);
        lcd_write_powerup(buffer, "1", 385);
    }

    if (powerup_is_active()) {
        setLed(COLOUR_PINK);
        lcd_write_timer(
            buffer,
            timer_str,
            451,
            powerup_get_offset()
        );
        full_redraw = 1;
    }

//    lcd_scroll(buffer);
    lcd_push_buffer(buffer);
}



void lcd_tick(void)
{
    static uint16_t lcd_counter   = 0;

    // LCD refresh every 50 ms
    if (++lcd_counter >= 30) {
        update_lcd = 1;
        lcd_counter = 0;
    }
}


