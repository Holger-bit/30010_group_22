/*
 * bullets.h
 *
 *  Created on: 15 Jan 2026
 *      Author: malik
 */

#ifndef BULLETS_H_
#define BULLETS_H_

#include <stdint.h>
#include "vect.h"
#include "gravity_astroide.h"

#define MAX_BULLETS 10

// grupperer alle vores bullet variable i et sted
typedef struct {
    vector_t pos;
    vector_t vel;
    vector_t prev;
    uint8_t active;
} bullet_t;

// sætter en værdi for hvor mange bombe tilstande vi har aktive
#define MAX_BOMBS 10

//grupperer alle vores bomb variable i et sted
typedef struct {
    int16_t x, y;
    int8_t  vx, vy;
    int16_t fuse;
    uint8_t active;
    char under_char;
} Bomb;

void bullets_init(bullet_t bullets[], uint8_t *next_bullet);
void shoot(bullet_t bullets[], uint8_t *next_bullet,
    int x, int y, int vx, int vy, int k
);

void bullets_poll(bullet_t bullets[], const Asteroid *rocky);

void bombs_init(Bomb bombs[]);
void bomb_spawn(Bomb bombs[], int x, int y, int vx, int vy, int fuse);
void bombs_update(Bomb bombs[], bullet_t bullets[]);
void bullets_spawn_explosion(bullet_t bullets[], int x, int y);


#endif /* BULLETS_H_ */

