#ifndef ENEMY_H_
#define ENEMY_H_

#include <stdint.h>
#include "bullets.h"   // bullet_t, MAX_BULLETS

#define MAX_ENEMIES 10

typedef struct {
    int8_t  x;
    int8_t  y;
    uint8_t alive;
} enemy_t;

void enemy_init(enemy_t enemies[], uint8_t *enemy_count,
                uint8_t *enemy_start, uint8_t *enemy_step,
                uint8_t *spawn_x, uint8_t *spawn_y);

void enemy_spawn(enemy_t enemies[], uint8_t *enemy_count, uint8_t *enemy_start,
                 uint8_t *spawn_x, uint8_t *spawn_y);

void enemy_tick(uint8_t *enemy_step,
                uint16_t *spawn_counter, uint16_t *move_counter);

void enemy_update_and_render(enemy_t enemies[], uint8_t enemy_count,
                             uint8_t *enemy_start, uint8_t *enemy_step);

void enemy_handle_bullets(enemy_t enemies[], uint8_t *enemy_count,
                          bullet_t bullets[]);

#endif
