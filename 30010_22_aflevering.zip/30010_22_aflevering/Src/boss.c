#include "boss.h"
#include "ansi.h"

// De forskellig tegn, der bruges til at tegne cellerne
#define HLINE   196   // ─
#define VLINE   179   // │

#define ULC     218   // ┌
#define URC     191   // ┐
#define LLC     192   // └
#define LRC     217   // ┘

#define TDOWN   194   // ┬
#define TUP     193   // ┴
#define TRIGHT  195   // ├
#define TLEFT   180   // ┤

#define CROSS   197   // ┼

void boss_key(void)
{
    int x = 4;
    int y = 2;

    const int cols = 8;
    const int rows = 24;
    const int cell_w = 11;

// Print kolonneoverskrifterne A-H
    for (int c = 0; c < cols; c++) {
        gotoxy(x + c * (cell_w + 1) + cell_w / 2, y - 1);
        printf("%c", 'A' + c);
    }

// Øverste kant. Hjørner, T'er og linjer
    gotoxy(x - 1, y);
    printf("%c", ULC);
    for (int c = 0; c < cols; c++) {
        for (int i = 0; i < cell_w; i++) printf("%c", HLINE); 				// Print de øverste vandrette linjer over hver celle
        printf(c == cols - 1 ? "%c" : "%c", c == cols - 1 ? URC : TDOWN); 	// Efter hver celle, print et T med mindre det er enden, så print hjørnet
    }

// Alle cellerne rækkevis
    for (int r = 0; r < rows; r++) {

// Print rækkens nummer 1-24
        gotoxy(1, y + r * 2 + 1);
        printf("%2d", r + 1);

// Alle de lodrette linjer
        gotoxy(x - 1, y + r * 2 + 1);
        printf("%c", VLINE);								// Print de venstre lodrette linjer
        for (int c = 0; c < cols; c++) {
            for (int i = 0; i < cell_w; i++) printf(" ");	// Print mellemrum i cellerne (lettere end at bruge goto)
            printf("%c", VLINE);							// Print vandrette linjer mellem celler og den højre væg (efter mellemrum)
        }

// Resten af de vandrette linjer, kryds, T'er og hjørner. Meget lig funktionerne før
        gotoxy(x - 1, y + r * 2 + 2);
        printf("%c", r == rows - 1 ? LLC : TRIGHT);					// Print T'erne på venstre væg og det nederste hjørne
        for (int c = 0; c < cols; c++) {
            for (int i = 0; i < cell_w; i++) printf("%c", HLINE);	// Print de vandrette linjer mellem hver celle kolonnevis og rækkevis. Og de nederste linjer
            if (c == cols - 1)
                printf("%c", r == rows - 1 ? LRC : TLEFT);			// I sidste kolonne print T'er og nederste højre hjørne
            else
                printf("%c", r == rows - 1 ? TUP : CROSS);			// Resten af kolonnerne print kryds og T'erne i bunden
        }
    }
// Print teksten inden i nogle af cellerne
    gotoxy(x, y + 1);
    printf("I am");
    gotoxy(x + 1 + cell_w, y + 1);
	printf("Working");
    gotoxy(x + 2*(1 + cell_w), y + 1);
	printf("Don't");
    gotoxy(x + 3*(1 + cell_w), y + 1);
	printf("Worry");

    gotoxy(x + 2*(1 + cell_w), 15*y + 1);
	printf("Press \'y\'");
    gotoxy(x + 3*(1 + cell_w), 15*y + 1);
	printf("to go back");
}

