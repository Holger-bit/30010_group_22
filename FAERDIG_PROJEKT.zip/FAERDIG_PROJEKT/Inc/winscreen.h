/*
 * winscreen.h
 *
 *  Created on: 13. jan. 2026
 *      Author: root
 */

#include "ansi.h"
#include <stdint.h>
#include <stdio.h>

#ifndef WINSCREEN_H_
#define WINSCREEN_H_


void winscreen();

#endif /* WINSCREEN_H_ */
