/*
 * startscreen.h
 *
 *  Created on: 13. jan. 2026
 *      Author: root
 */

#include "ansi.h"
#include <stdint.h>
#include <stdio.h>

#ifndef STARTSCREEN_H_
#define STARTSCREEN_H_


void make_menu(uint8_t selected);
void maketitle();


#endif /* STARTSCREEN_H_ */
