/*
 * EX5.c
 *
 *  Created on: 8. jan. 2026
 *      Author: root
 */

#include <stdint.h>
#include <stdio.h>
#include "stm32f30x_conf.h"
#include "30010_io.h"
#include "EX5.h"


void setupjoystick(void){

	//enable clock for alle portene
	RCC->AHBENR |= RCC_AHBPeriph_GPIOA; // Enable clock for GPIO Port A
	RCC->AHBENR |= RCC_AHBPeriph_GPIOB; // Enable clock for GPIO Port B
	RCC->AHBENR |= RCC_AHBPeriph_GPIOC; // Enable clock for GPIO Port C


	//PC0 (right), PA4 (up), PB5 (center), PC1 (left), and PB0 (down)


	// Set pin PC0 to input
	GPIOC->MODER &= ~(0x00000003 << (0 * 2)); // Clear mode register
	GPIOC->MODER |= (0x00000000 << (0 * 2)); // Set mode register (0x00 – Input, 0x01 - Output, 0x02 - Alternate Function, 0x03 - Analog in/out)
	GPIOC->PUPDR &= ~(0x00000003 << (0 * 2)); // Clear push/pull register
	GPIOC->PUPDR |= (0x00000002 << (0 * 2)); // Set push/pull register (0x00 -No pull, 0x01 - Pull-up, 0x02 - Pull-down)

	// Set pin PA4 to input
	GPIOA->MODER &= ~(0x00000003 << (4 * 2)); // Clear mode register
	GPIOA->MODER |= (0x00000000 << (4 * 2)); // Set mode register (0x00 – Input, 0x01 - Output, 0x02 - Alternate Function, 0x03 - Analog in/out)
	GPIOA->PUPDR &= ~(0x00000003 << (4 * 2)); // Clear push/pull register
	GPIOA->PUPDR |= (0x00000002 << (4 * 2)); // Set push/pull register (0x00 -No pull, 0x01 - Pull-up, 0x02 - Pull-down)

	// Set pin PB5 to input
	GPIOB->MODER &= ~(0x00000003 << (5 * 2)); // Clear mode register
	GPIOB->MODER |= (0x00000000 << (5 * 2)); // Set mode register (0x00 – Input, 0x01 - Output, 0x02 - Alternate Function, 0x03 - Analog in/out)
	GPIOB->PUPDR &= ~(0x00000003 << (5 * 2)); // Clear push/pull register
	GPIOB->PUPDR |= (0x00000002 << (5 * 2)); // Set push/pull register (0x00 -No pull, 0x01 - Pull-up, 0x02 - Pull-down)

	// Set pin PC1 to input
	GPIOC->MODER &= ~(0x00000003 << (1 * 2)); // Clear mode register
	GPIOC->MODER |= (0x00000000 << (1 * 2)); // Set mode register (0x00 – Input, 0x01 - Output, 0x02 - Alternate Function, 0x03 - Analog in/out)
	GPIOC->PUPDR &= ~(0x00000003 << (1 * 2)); // Clear push/pull register
	GPIOC->PUPDR |= (0x00000002 << (1 * 2)); // Set push/pull register (0x00 -No pull, 0x01 - Pull-up, 0x02 - Pull-down)

	// Set pin PB0 to input
	GPIOB->MODER &= ~(0x00000003 << (0 * 2)); // Clear mode register
	GPIOB->MODER |= (0x00000000 << (0 * 2)); // Set mode register (0x00 – Input, 0x01 - Output, 0x02 - Alternate Function, 0x03 - Analog in/out)
	GPIOB->PUPDR &= ~(0x00000003 << (0 * 2)); // Clear push/pull register
	GPIOB->PUPDR |= (0x00000002 << (0 * 2)); // Set push/pull register (0x00 -No pull, 0x01 - Pull-up, 0x02 - Pull-down)
}

uint8_t readJoystick()
{
	//PC0 (right), PA4 (up), PB5 (center), PC1 (left), and PB0 (down)
	uint16_t val = 0;
	uint8_t output_val = 0;


	//Hent up, PA4
	val = GPIOA->IDR & (0x0001 << 4); //Read from pin PA4
	val = (val >> 4);
	output_val |= (val << 0); // shift til position fra pdf

	//hent down, PB0
	val = GPIOB->IDR & (0x0001 << 0); //Read from pin PB0
	val = (val >> 0);
	output_val |= (val << 1);

	//hent left, PC1
	val = GPIOC->IDR & (0x0001 << 1); //Read from pin PC1
	val = (val >> 1);
	output_val |= (val << 2);


	//Hent right
	val = GPIOC->IDR & (0x0001 << 0); //Read from pin PC0
	val = (val >> 0);
	output_val |= (val << 3);

	//hent center, PB5
	val = GPIOB->IDR & (0x0001 << 5); //Read from pin PB5
	val = (val >> 5);
	output_val |= (val << 4);

	return output_val;
}

void setupLed(void){
	//enable clock for alle portene
	RCC->AHBENR |= RCC_AHBPeriph_GPIOA; // Enable clock for GPIO Port A
	RCC->AHBENR |= RCC_AHBPeriph_GPIOB; // Enable clock for GPIO Port B
	RCC->AHBENR |= RCC_AHBPeriph_GPIOC; // Enable clock for GPIO Port C

	// Set pin PB4 to output, rød
	GPIOB->OSPEEDR &= ~(0x00000003 << (4 * 2)); // Clear speed register
	GPIOB->OSPEEDR |= (0x00000002 << (4 * 2)); // set speed register (0x01 - 10MHz, 0x02 - 2 MHz, 0x03 - 50 MHz)
	GPIOB->OTYPER &= ~(0x0001 << (4 * 1)); // Clear output type register
	GPIOB->OTYPER |= (0x0000 << (4)); // Set output type register (0x00 - Push pull, 0x01 - Open drain)
	GPIOB->MODER &= ~(0x00000003 << (4 * 2)); // Clear mode register
	GPIOB->MODER |= (0x00000001 << (4 * 2)); // Set mode register (0x00 – Input, 0x01 - Output, 0x02 - Alternate Function, 0x03 - Analog in/out)

	// Set pin PC7 to output, Grøn
	GPIOC->OSPEEDR &= ~(0x00000003 << (7 * 2)); // Clear speed register
	GPIOC->OSPEEDR |= (0x00000002 << (7 * 2)); // set speed register (0x01 - 10MHz, 0x02 - 2 MHz, 0x03 - 50 MHz)
	GPIOC->OTYPER &= ~(0x0001 << (7 * 1)); // Clear output type register
	GPIOC->OTYPER |= (0x0000 << (7)); // Set output type register (0x00 - Push pull, 0x01 - Open drain)
	GPIOC->MODER &= ~(0x00000003 << (7 * 2)); // Clear mode register
	GPIOC->MODER |= (0x00000001 << (7 * 2)); // Set mode register (0x00 – Input, 0x01 - Output, 0x02 - Alternate Function, 0x03 - Analog in/out)


	// Set pin PA9 to output, blå
	GPIOA->OSPEEDR &= ~(0x00000003 << (9 * 2)); // Clear speed register
	GPIOA->OSPEEDR |= (0x00000002 << (9 * 2)); // set speed register (0x01 - 10MHz, 0x02 - 2 MHz, 0x03 - 50 MHz)
	GPIOA->OTYPER &= ~(0x0001 << (9 * 1)); // Clear output type register
	GPIOA->OTYPER |= (0x0000 << (9)); // Set output type register (0x00 - Push pull, 0x01 - Open drain)
	GPIOA->MODER &= ~(0x00000003 << (9 * 2)); // Clear mode register
	GPIOA->MODER |= (0x00000001 << (9 * 2)); // Set mode register (0x00 – Input, 0x01 - Output, 0x02 - Alternate Function, 0x03 - Analog in/out)
}

void setLed(uint8_t colour)

{
	//sluk det gamle lys
	GPIOB->ODR |= (0x0001 << 4);
	GPIOC->ODR |= (0x0001 << 7);
	GPIOA->ODR |= (0x0001 << 9);

	// de er lavet så de 3 sidst cifre er RGB
	switch(colour)
{
	case 0b00000001:
		GPIOA->ODR &= ~(0x0001 << 9); //blå Set pin PA9 to low
		break;
	case 0b00000010:
		GPIOC->ODR &= ~(0x0001 << 7); //grøn Set pin PC7 to low
		break;
	case 0b00000100:
		GPIOB->ODR &= ~(0x0001 << 4); //rød, Set pin PB4 to low
		break;
	case 0b00000011:
		GPIOA->ODR &= ~(0x0001 << 9); //blå Set pin PA9 to low
		GPIOC->ODR &= ~(0x0001 << 7); //grøn Set pin PC7 to low
		break;
	case 0b00000101:
		GPIOA->ODR &= ~(0x0001 << 9); //blå Set pin PA9 to low
		GPIOB->ODR &= ~(0x0001 << 4); //rød, Set pin PB4 to low
		break;
	case 0b00000110:
		GPIOB->ODR &= ~(0x0001 << 4); //rød, Set pin PB4 to low
		GPIOC->ODR &= ~(0x0001 << 7); //grøn Set pin PC7 to low
		break;
	case 0b00000111:
		GPIOA->ODR &= ~(0x0001 << 9); //blå Set pin PA9 to low
		GPIOC->ODR &= ~(0x0001 << 7); //grøn Set pin PC7 to low
		GPIOB->ODR &= ~(0x0001 << 4); //rød, Set pin PB4 to low
		break;
	default:
		break;
}
}






