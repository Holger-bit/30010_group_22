#include "30010_io.h"
#include "stopwatch.h"
#include "ansi.h"
#include "joystick.h"

static volatile stopwatch_time_t time = {0};
static volatile uint8_t running = 0;

stopwatch_time_t stopwatch_getTime(void) {
    return time;   // copy struct (atomic enough for this size)
}

void stopwatch_init(void) {
    stopwatch_reset();
}
void stopwatch_start(void) {
    running = 1;
}
void stopwatch_split1(void) {
    stopwatch_time_t t = stopwatch_getTime();
    gotoxy(0,2);
	printf("Split 1: %u:%02u:%02u:%02u",
		   t.hour, t.min, t.sec, t.hsec);
}
void stopwatch_split2(void) {
    stopwatch_time_t t = stopwatch_getTime();
    gotoxy(0,3);
	printf("Split 2: %u:%02u:%02u:%02u",
		   t.hour, t.min, t.sec, t.hsec);
}
void stopwatch_startstop(void) {
    if (running == 0)
    	running = 1;
    else if (running == 1)
    	running = 0;
}
void stopwatch_reset(void) {
    time.hsec = 0;
    time.sec  = 0;
    time.min  = 0;
    time.hour = 0;
}
void stopwatch_tick(void) {
    if (!running) return;

    time.hsec++;
    if (time.hsec >= 100) {
        time.hsec = 0;
        time.sec++;
    }
    if (time.sec >= 60) {
        time.sec = 0;
        time.min++;
    }
    if (time.min >= 60) {
        time.min = 0;
        time.hour++;
    }
}


void stopwatch(void) {
    static uint8_t j_old = 0;
    static stopwatch_time_t t_old = {0};
    uint8_t j = readJoystick();

    if (j != j_old) {
    	if (j & (1 << 4)) {        // center pressed
			stopwatch_startstop();
		}

		if (j & (1 << 1)) {        // down pressed
			stopwatch_reset();
		}

		if (j & (1 << 2)) {        // down pressed
			stopwatch_split1();
		}

		if (j & (1 << 3)) {        // down pressed
			stopwatch_split2();
		}
    }

    stopwatch_time_t t = stopwatch_getTime();
    if (t.sec != t_old.sec) {
		gotoxy(0,0);
		printf("Time: %u:%02u:%02u:%02u",
			   t.hour, t.min, t.sec, t.hsec);
    }
    t_old = t;
    j_old = j;
}
