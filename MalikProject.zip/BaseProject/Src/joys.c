/*
 * joys.c
 *
 *  Created on: 13 Jan 2026
 *      Author: malik
 */


#include "joys.h"
#include <stdio.h>
#include "stm32f30x.h"

void setupjoystick(void)
{
	//Aktivere GPIO klokke
	// RCC->AHBENR er hvad der aktiver
	// |= betyder sæt disse bits og behold andet uændret
	RCC->AHBENR |= RCC_AHBPeriph_GPIOA // Aktivering af port A
				| RCC_AHBPeriph_GPIOB // Aktivering af port B
				| RCC_AHBPeriph_GPIOC; // Aktivering af port C

	// PC0 (Højre), PA4 (up), PB5 (midten), PC1 (venstre) og PB0 (ned)

	//sæt pin PC0 til input
	GPIOC->MODER &= ~(0x00000003 << (0*2)); // sletter de 2 mode bits for pin 0
	GPIOC->MODER |=  (0x00000000 << (0*2)); // sæt mode til 00 (klar til input) (0x00 - input,, 0x01 -output, 0x02 -alternate function, 0x03 -analog in/out)
	GPIOC->PUPDR &= ~(0x00000003 << (0*2)); // clear push/pull register
	GPIOC->PUPDR |=  (0x00000002 << (0*2)); // set push/pull register (0x00 -no pull, 0x01 -pull-up, 0x02 -pull-down)

	//sæt pin PA4 til input
	GPIOA->MODER &= ~(0x00000003 << (4*2)); // sletter de 2 mode bits for pin 0
	GPIOA->MODER |=  (0x00000000 << (4*2)); // sæt mode til 00 (klar til input) (0x00 - input,, 0x01 -output, 0x02 -alternate function, 0x03 -analog in/out)
	GPIOA->PUPDR &= ~(0x00000003 << (4*2)); // clear push/pull register
	GPIOA->PUPDR |=  (0x00000002 << (4*2)); // set push/pull register (0x00 -no pull, 0x01 -pull-up, 0x02 -pull-down)

	//sæt pin PB5 til input
	GPIOB->MODER &= ~(0x00000003 << (5*2)); // sletter de 2 mode bits for pin 0
	GPIOB->MODER |=  (0x00000000 << (5*2)); // sæt mode til 00 (klar til input) (0x00 - input,, 0x01 -output, 0x02 -alternate function, 0x03 -analog in/out)
	GPIOB->PUPDR &= ~(0x00000003 << (5*2)); // clear push/pull register
	GPIOB->PUPDR |=  (0x00000002 << (5*2)); // set push/pull register (0x00 -no pull, 0x01 -pull-up, 0x02 -pull-down)

	//sæt pin PC1 til input
	GPIOC->MODER &= ~(0x00000003 << (1*2)); // sletter de 2 mode bits for pin 0
	GPIOC->MODER |=  (0x00000000 << (1*2)); // sæt mode til 00 (klar til input) (0x00 - input,, 0x01 -output, 0x02 -alternate function, 0x03 -analog in/out)
	GPIOC->PUPDR &= ~(0x00000003 << (1*2)); // clear push/pull register
	GPIOC->PUPDR |=  (0x00000002 << (1*2)); // set push/pull register (0x00 -no pull, 0x01 -pull-up, 0x02 -pull-down)

	//sæt pin PB0 til input
	GPIOB->MODER &= ~(0x00000003 << (0*2)); // sletter de 2 mode bits for pin 0
	GPIOB->MODER |=  (0x00000000 << (0*2)); // sæt mode til 00 (klar til input) (0x00 - input,, 0x01 -output, 0x02 -alternate function, 0x03 -analog in/out)
	GPIOB->PUPDR &= ~(0x00000003 << (0*2)); // clear push/pull register
	GPIOB->PUPDR |=  (0x00000002 << (0*2)); // set push/pull register (0x00 -no pull, 0x01 -pull-up, 0x02 -pull-down)
}

uint8_t readJoystick(void)
{
	uint16_t val = 0;
	uint8_t output_val = 0;

	// Hent up, PA4 (up)
	val = GPIOA->IDR & (0x0001 << 4); // Read from pin PA4 by making a mask and keeps only PA4
	val = (val >> 4); // turns 0x0010 into 0x0001 so val is either 0 or 1
	output_val |= (val<<0); //shift til position som vi ønsker

	// Hent up, PB0 (ned)
	val = GPIOB->IDR & (0x0001 << 0); // Read from pin PB0
	val = (val >> 0); //
	output_val |= (val<<1); //shift til position som vi ønsker

	// Hent up, PC1 (venstre)
	val = GPIOC->IDR & (0x0001 << 1); // Read from pin PC1
	val = (val >> 1); //
	output_val |= (val<<2); //shift til position som vi ønsker

	// Hent up, PC0 (højre)
	val = GPIOC->IDR & (0x0001 << 0); // Read from pin PC0
	val = (val >> 0); //
	output_val |= (val<<3); //shift til position som vi ønsker

	// Hent up, PB5
	val = GPIOB->IDR & (0x0001 << 5); // Read from pin PB0
	val = (val >> 5); //
	output_val |= (val<<4); //shift til position som vi ønsker

	return output_val;
}

void joystickprint(void)
{
	static uint8_t old_state = 0xFF; // static husker værdier mellem at køre funktioner
	uint8_t state;

	state = readJoystick();

	if (state != old_state)
	{
		switch(state)
		{
			case 0b00000001:
				printf("Up\n");
				break;
			case 0b00000010:
				printf("Ned\n");
				break;
			case 0b00000100:
				printf("Venstre\n");
				break;
			case 0b00001000:
				printf("Hoejre\n");
				break;
			case 0b00010000:
				printf("Midten\n");
				break;
			default:
				//Multiple directions or bounce
				break;
		}

		old_state = state;
	}
}
