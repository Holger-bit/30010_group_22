/*
 * startscreen.c
 *
 *  Created on: 13. jan. 2026
 *      Author: root
 */
#include "ansi.h"
#include <stdint.h>
#include <stdio.h>
#include "startscreen.h"

void maketitle(){
	clrscr();
	printf("\x1b[?25l"); // Skjul cursoren

	uint8_t x = 5;
	uint8_t y = 5;



	gotoxy(x,y);
	printf(" ######  ########     ###     ######  ########      ##     ##    ###    ##     ##");
	gotoxy(x,++y);
	printf("##    ## ##     ##   ## ##   ##    ## ##            ##     ##   ## ##   ###   ###");
	gotoxy(x,++y);
	printf("##       ##     ##  ##   ##  ##       ##            ##     ##  ##   ##  #### ####");
	gotoxy(x,++y);
	printf(" ######  ########  ##     ## ##       ######        ######### ##     ## ## ### ##");
	gotoxy(x,++y);
	printf("      ## ##        ######### ##       ##            ##     ## ######### ##     ##");
	gotoxy(x,++y);
	printf("##    ## ##        ##     ## ##    ## ##            ##     ## ##     ## ##     ##");
	gotoxy(x,++y);
	printf(" ######  ##        ##     ##  ######  ########      ##     ## ##     ## ##     ##");

	uint8_t etnytypunkt = 22;
	uint8_t etnytxpunkt = 40;

	gotoxy(etnytxpunkt,etnytypunkt);
	printf("    .--.  .-'''-.  .--.");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("   /.--./'.-. .-.`\\.--.\\");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("   ||  / / .| | .\\ \\  ||");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("   \\\\_/| \\__| |__/ |\\_//");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("    `-'\\  .-----.  /`-'");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("        \\/       \\/");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("        (\\`.___.'/)");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("         \\`.___.'/");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("          `.___.'");












}

void make_menu(uint8_t selected){
	uint8_t x = 5;
	uint8_t y = 12;

	uint8_t style1 = (selected == 0) ? 0 : 1;
	uint8_t style2 = (selected == 1) ? 0 : 1;

	window(x,y+10, x+12, y+12, "Start game", style1);

	window(x,y+16, x+12, y+18, "Help", style2);

}
