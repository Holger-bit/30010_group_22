#include "game_play.h"
#include "player.h"
#include "30010_io.h"
#include "joystick.h"
#include "ansi.h"
#include "LCDpush.h"
#include <string.h>
#include "LED.h"
#include "powerup.h"
#include "enemy.h"

/*
 * The ONE true player instance
 * - Owned by game_play
 * - Used by system_tick via extern
 */
Entity g_player;

GameState play_update(void)
{
    static uint8_t started = 0;

    if (!started) {
        setJoystick();
        setupLed();
		setLed(COLOUR_BLACK);
        player_init(&g_player);
        lcd_init();
        started = 1;
    }

    char key = uart_get_char();
    uint8_t joy = readJoystick();

    int32_t old_x = g_player.x;
    int8_t  old_tilt = g_player.tilt;

    /* Input only sets state */
    player_handle_input(&g_player, key, joy);

    /* Rendering reacts to tick-updated state */
    if (g_player.x != old_x || g_player.tilt != old_tilt) {
        player_erase(&g_player, old_x, old_tilt);
        player_draw(&g_player);
    }


	lcd_update();
	use_powerup();
	enemy();

    /* Back to menu */
    if (key == 'b') {
        started = 0;
        clrscr();
        return STATE_MENU;
    }

    return STATE_PLAYING;
}
