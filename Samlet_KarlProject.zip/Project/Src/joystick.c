#include "joystick.h"
#include "stm32f30x_conf.h"

void setJoystick(void) {

    // enable all ports
    RCC->AHBENR |= RCC_AHBENR_GPIOAEN; // Enable clock for GPIO Port A
    RCC->AHBENR |= RCC_AHBENR_GPIOBEN; // Enable clock for GPIO Port B
    RCC->AHBENR |= RCC_AHBENR_GPIOCEN; // Enable clock for GPIO Port C

    // PCA (right), PA4 (up), PA5 (down), PC0 (center), PC1 (left), and PB0 (down)

    // Set PA1 PIN to input
    GPIOA->MODER &= ~(0x00000003 << (1 * 2)); // Clear mode register
    GPIOA->MODER |=  (0x00000000 << (1 * 2)); // Set as input
    GPIOA->PUPDR &= ~(0x00000003 << (1 * 2)); // Clear pupd register
    GPIOA->PUPDR |=  (0x00000002 << (1 * 2)); // Set pull-down

    // Set PA4 PIN to input
    GPIOA->MODER &= ~(0x00000003 << (4 * 2)); // Clear mode register
    GPIOA->MODER |=  (0x00000000 << (4 * 2)); // Set as input
    GPIOA->PUPDR &= ~(0x00000003 << (4 * 2)); // Clear pupd register
    GPIOA->PUPDR |=  (0x00000002 << (4 * 2)); // Set pull-down

    // Set PA5 PIN to input
    GPIOA->MODER &= ~(0x00000003 << (5 * 2)); // Clear mode register
    GPIOA->MODER |=  (0x00000000 << (5 * 2)); // Set as input
    GPIOA->PUPDR &= ~(0x00000003 << (5 * 2)); // Clear pupd register
    GPIOA->PUPDR |=  (0x00000002 << (5 * 2)); // Set pull-down

    // Set PC0 PIN to input
    GPIOC->MODER &= ~(0x00000003 << (0 * 2)); // Clear mode register
    GPIOC->MODER |=  (0x00000000 << (0 * 2)); // Set as input
    GPIOC->PUPDR &= ~(0x00000003 << (0 * 2)); // Clear pupd register
    GPIOC->PUPDR |=  (0x00000002 << (0 * 2)); // Set pull-down

    // Set PC1 PIN to input
    GPIOC->MODER &= ~(0x00000003 << (1 * 2)); // Clear mode register
    GPIOC->MODER |=  (0x00000000 << (1 * 2)); // Set as input
    GPIOC->PUPDR &= ~(0x00000003 << (1 * 2)); // Clear pupd register
    GPIOC->PUPDR |=  (0x00000002 << (1 * 2)); // Set pull-down

    // Set PB0 PIN to input
    GPIOB->MODER &= ~(0x00000003 << (0 * 2)); // Clear mode register
    GPIOB->MODER |=  (0x00000000 << (0 * 2)); // Set as input
    GPIOB->PUPDR &= ~(0x00000003 << (0 * 2)); // Clear pupd register
    GPIOB->PUPDR |=  (0x00000002 << (0 * 2)); // Set pull-down
}

uint8_t readJoystick() {

    // PC0 (right), PA4 (up), PB5 (center), PC1 (left), and PB0 (down)
    uint16_t val = 0;
    uint8_t output_val = 0;

    // Hent up, PA4
    val = GPIOA->IDR & (0x0001 << 4);   // Read from pin PA4
    val = val >> 4;
    output_val |= (val << 0);           // shift til position fra pdf

    // Hent down, PB0
    val = GPIOB->IDR & (0x0001 << 0);   // Read from pin PB0
    val = val >> 0;
    output_val |= (val << 1);

    // Hent left, PC1
    val = GPIOC->IDR & (0x0001 << 1);   // Read from pin PC1
    val = val >> 1;
    output_val |= (val << 2);

    // Hent right
    val = GPIOC->IDR & (0x0001 << 0);   // Read from pin PC0
    val = val >> 0;
    output_val |= (val << 3);

    // Hent center, PB5
    val = GPIOB->IDR & (0x0001 << 5);   // Read from pin PB5
    val = val >> 5;
    output_val |= (val << 4);

    return output_val;
}
