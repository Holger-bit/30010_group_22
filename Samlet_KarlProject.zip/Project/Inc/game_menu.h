#ifndef GAME_MENU_H
#define GAME_MENU_H

#include <stdint.h>
#include "game_manager.h"

void menu_init(uint8_t *selected);
GameState menu_update(uint8_t *selected);

#endif
