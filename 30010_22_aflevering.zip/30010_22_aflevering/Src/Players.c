/*
 * Player.c
 *
 *  Created on: 15. jan. 2026
 *      Author: root
 */
#include <Players.h>



void makeplayer(Entity *p, int erase) {
    // Vi har 5 tilt-stadier og raketten er 6 linjer høj
    char *sprites[5][6] = {
        // [0]: MEGET VENSTRE (-2)  \\;
        { "\\\\    ", " . . ", " |o| ", " |o| ", " .-. ", "|/-\\|" },
        // [1]: LIDT VENSTRE (-1) \;
        { " \\   ", " . . ", " |o| ", " |o| ", " .-. ", "|/-\\|" },
        // [2]: LIGE UD (0) |
        { "  |  ", " . . ", " |o| ", " |o| ", " .-. ", "|/-\\|" },
        // [3]: LIDT HØJRE (1)  /
        { "   / ", " . . ", " |o| ", " |o| ", " .-. ", "|/-\\|" },
        // [4]: MEGET HØJRE (2) //
        { "    //", " . . ", " |o| ", " |o| ", " .-. ", "|/-\\|" }
    };

    int index;


    //sikre at jeg holder mig indenfor array og vælger rigtg sprite
    switch (p->tilt) {
        case -2: index = 0; break;
        case -1: index = 1; break;
        case 0:  index = 2; break;
        case 1:  index = 3; break;
        case 2:  index = 4; break;
        default: index = 2; break;
    }

    for (int i = 0; i < 6; i++) {
        gotoxy(p->x, p->y + i);
        if (erase) {
            printf("      "); // Sletter 6 tegn
        } else {
            // Vi bruger %-6s for at sikre at den altid printer 6 tegn
            printf("%-6s", sprites[index][i]);
        }
    }
}
