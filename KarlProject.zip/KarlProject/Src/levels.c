#include "30010_io.h"
#include "levels.h"
#include "ansi.h"
#include "joystick.h"

static uint16_t score = 0;
static uint8_t level = 1;

uint8_t x = 0;
uint8_t counter = 0;



void set_game_speed(uint16_t arr) {
    TIM15->ARR = 100/arr;
}

//void killEnemy(void) {
//	score += 100;
//
//    if (score > 500) {
//        lvlup();
//    }
//    writelvl();
//}

void level2gamespeed(void) {
	switch (level){
	case 1:
		set_game_speed(1);
		break;
	case 2:
		set_game_speed(2);
		break;
	case 3:
		set_game_speed(3);
		break;
	}
}

void lvlup(void) {
	level++;
	level2gamespeed();
	score = 0;

}


void moving(void){
	counter++;
	if (counter > 100) {
		gotoxy(x-1, 0);
		printf(" ");
		gotoxy(x, 0);
		printf("o");
		x++;
		counter = 0;
	}
}

void writelvl(void) {
    gotoxy(0,2);
    printf("Score: %04u", score);
    gotoxy(0,3);
    printf("Level: %u", level);
}

