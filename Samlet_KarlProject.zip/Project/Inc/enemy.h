#ifndef ENEMY_H_
#define ENEMY_H_

#include <stdint.h>


typedef struct {
    int8_t  x;
    int8_t  y;
    uint8_t alive;
} enemy_t;

#define MAX_ENEMIES 10


void enemy(void);
void enemy_tick(void);

#endif /* ENEMY_H_ */
