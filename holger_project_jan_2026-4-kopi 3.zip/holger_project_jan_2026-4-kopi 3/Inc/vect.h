

#ifndef VECT_H_
#define VECT_H_

#include <stdint.h>

typedef struct {
	int32_t x, y;
} vector_t;

void initVector(vector_t *v, int32_t x, int32_t y);
void rotateVector(vector_t *v, int32_t vinkel);
void rotateVectorPrint(vector_t *v, int32_t vinkel);



#endif /* VECT_H_ */
