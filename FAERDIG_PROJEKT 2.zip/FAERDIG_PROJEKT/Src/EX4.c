/*
 * EX4.c
 *
 *  Created on: 7. jan. 2026
 *      Author: root
 */
#include <stdint.h>
#include <stdio.h>
#include "EX4.h"
#include "ansi.h"
#define ESC 0x1B

void window2(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2) {
    uint8_t tl, tr, bl, br, v, h; // Tegn til hjørner og sider
    uint8_t i;
    tl = 201; tr = 187; bl = 200; br = 188; v = 186; h = 205;


    // 1. Tegn hjørner
    gotoxy(x1, y1); printf("%c", tl);
    gotoxy(x2, y1); printf("%c", tr);
    gotoxy(x1, y2); printf("%c", bl);
    gotoxy(x2, y2); printf("%c", br);

    // 2. Tegn vandrette linjer (top og bund)
    for (i = x1 + 1; i < x2; i++) {
        gotoxy(i, y1); printf("%c", h);
        gotoxy(i, y2); printf("%c", h);
    }

    // 3. Tegn lodrette linjer (sider)
    for (i = y1 + 1; i < y2; i++) {
        gotoxy(x1, i); printf("%c", v);
        gotoxy(x2, i); printf("%c", v);
    }

}


void vindue(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2) {
    // 1. Tegn den store kasse
    window2(x1, y1, x2, y2);

//    // 2. Beregn og tegn den lille kasse i midten
//    uint8_t midtX = (x1 + x2) / 2;
//    uint8_t midtY = (y1 + y2) / 2;
//    window2(midtX - 3, midtY - 1, midtX + 3, midtY + 1);
}

int updateBall(Ball *b, uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2) {
    int hit = 0;

    // 1. Slet bold (husk b-> i stedet for b. da det er en pointer)
    gotoxy(b->x, b->y);
    printf(" ");

    // 2. Opdater position
    b->x += b->vx;
    b->y += b->vy;

    // 3. Bounce x-vægge
    if (b->x <= x1 + 1 || b->x >= x2 - 1) {
        b->vx = -b->vx;
        hit = 1; // VI RAMTE VÆGGEN!
    }

    // 4. Bounce y-vægge
    if (b->y <= y1 + 1 || b->y >= y2 - 1) {
        b->vy = -b->vy;
        hit = 1; // VI RAMTE VÆGGEN!
    }

    // 5. Tegn bold
    gotoxy(b->x, b->y);
    printf("O");

    return hit;
}
// uint32_t count = 0;
//	uint8_t midtX = 30;
//	uint8_t midtY = 10;
//
//    uart_init(9600);
//    clrscr();
//    vindue(1,1,60,20);
//
//
//
//      clrscr();
//      vindue(1, 1, 60, 20); // Tegner det store og det lille vindue i midten
//
//      Ball b = {20, 10, 1, 1};
//      Ball * pB = &b;
//
//      while (1) {
//          // Hvis updateBall returnerer 1, betyder det, at vi ramte en væg
//          if (updateBall(pB, 1, 1, 60, 20)) {
//              count++;
//
//
//              gotoxy(midtX - 1, midtY);
//              printf("%lu", count); // %lu bruges til uint32_t
//          }
//    }






