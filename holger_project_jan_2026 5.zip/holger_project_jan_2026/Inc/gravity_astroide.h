#ifndef GRAVITY_ASTROIDE_H_
#define GRAVITY_ASTROIDE_H_

#include <stdint.h>
#include "ansi.h"

// 1. Definition af typen Asteroid
typedef struct {
    int32_t x, y;
    int32_t vx;
} Asteroid;

// 2. Fortæl alle filer at der findes en variabel der hedder 'rocky' et sted
extern Asteroid rocky;

// Prototyper
void updateAsteroid(Asteroid *a);

#endif
