#include "30010_io.h"
#include "levels.h"
#include "ansi.h"


static uint8_t level = 1;


// Returnerer ens level, så man kan bruge det i andre filer
uint8_t get_lvl(void) {
	return level;
}

void reset_lvl(void) {
	level = 1;
}


void lvlup(void) {
	level++;
}


// Printer et stort henholdsvis "LEVEL 1", "-2" og "-3", hvis ens level er 1, 2 eller 3
void print_lvlscreen(void){
	uint8_t x = 5;
	uint8_t y = 5;
	if (level == 1) {
		gotoxy(x, y);
		printf("##       ######## ##     ## ######## ##            ## ");
		gotoxy(x, ++y);
		printf("##       ##       ##     ## ##       ##           ### ");
		gotoxy(x, ++y);
		printf("##       ##       ##     ## ##       ##            ## ");
		gotoxy(x, ++y);
		printf("##       ######   ##     ## ######   ##            ## ");
		gotoxy(x, ++y);
		printf("##       ##        ##   ##  ##       ##            ## ");
		gotoxy(x, ++y);
		printf("##       ##         ## ##   ##       ##            ## ");
		gotoxy(x, ++y);
		printf("##       ##          ###    ##       ##            ## ");
		gotoxy(x, ++y);
		printf("##       ##          ###    ##       ##            ## ");
		gotoxy(x, ++y);
		printf("######## ########    ###    ######## ########      ####");

	}
	else if (level == 2) {
		gotoxy(x, y);
		printf("##       ######## ##     ## ######## ##            ####### ");
		gotoxy(x, ++y);
		printf("##       ##       ##     ## ##       ##           ##     ##");
		gotoxy(x, ++y);
		printf("##       ##       ##     ## ##       ##                  ##");
		gotoxy(x, ++y);
		printf("##       ######   ##     ## ######   ##            ####### ");
		gotoxy(x, ++y);
		printf("##       ##        ##   ##  ##       ##           ##       ");
		gotoxy(x, ++y);
		printf("##       ##         ## ##   ##       ##           ##       ");
		gotoxy(x, ++y);
		printf("##       ##          ###    ##       ##           ##       ");
		gotoxy(x, ++y);
		printf("##       ##          ###    ##       ##           ##       ");
		gotoxy(x, ++y);
		printf("######## ########    ###    ######## ########      ########");

	}
	else if (level == 3) {
		gotoxy(x, y);
		printf("##       ######## ##     ## ######## ##            ####### ");
		gotoxy(x, ++y);
		printf("##       ##       ##     ## ##       ##           ##     ##");
		gotoxy(x, ++y);
		printf("##       ##       ##     ## ##       ##                  ##");
		gotoxy(x, ++y);
		printf("##       ######   ##     ## ######   ##            ####### ");
		gotoxy(x, ++y);
		printf("##       ##        ##   ##  ##       ##                  ##");
		gotoxy(x, ++y);
		printf("##       ##         ## ##   ##       ##           ##     ##");
		gotoxy(x, ++y);
		printf("##       ##          ###    ##       ##           ##     ##");
		gotoxy(x, ++y);
		printf("##       ##          ###    ##       ##           ##     ##");
		gotoxy(x, ++y);
		printf("######## ########    ###    ######## ########      ####### ");

	}
}

