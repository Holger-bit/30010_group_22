#ifndef TIMER_H_
#define TIMER_H_

#include <stdint.h>

extern volatile uint8_t gtimerIRQFLAG;


void timer15_init(void);
void TIM1_BRK_TIM15_IRQHandler(void);



#endif /* TIMER_H_ */

