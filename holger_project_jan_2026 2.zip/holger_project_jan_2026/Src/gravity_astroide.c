#include "gravity_astroide.h"
#include "ansi.h"
#include <stdio.h>

Asteroid rocky = {2, 15, 1};

void updateAsteroid(Asteroid *a) {
    static uint16_t speed_counter = 0; // Tæller frames
    speed_counter++;

    // 1. Slet den gamle kasse (begge linjer)
    // Vi sletter hver frame for at undgå at skud efterlader "huller" i den
    gotoxy(a->x, a->y);     printf("     "); // Linje 1
    gotoxy(a->x, a->y + 1); printf("     "); // Linje 2
    gotoxy(a->x, a->y + 2); printf("     "); // Linje 3

    // 2. Flyt kun asteroiden hvis der er gået 40 frames
    if (speed_counter >= 40) {
        a->x += a->vx;
        speed_counter = 0;

        // Start forfra hvis den rammer kanten (100 bred)
        if (a->x > 94) a->x = 2;
        if (a->x < 2) a->x = 94;
    }

    // 3. Tegn den nye kasse (Box design)
    fgcolor(14); // Gul farve
    gotoxy(a->x, a->y);     printf(" ___ "); // Top
    gotoxy(a->x, a->y + 1); printf("|   |"); // midt
    gotoxy(a->x, a->y + 2); printf("|___|"); // Bund
    fgcolor(15); // Tilbage til hvid
}
