#ifndef STARTSCREEN_H_
#define STARTSCREEN_H_


void make_menu(uint8_t selected);
void maketitle();


#endif /* STARTSCREEN_H_ */
