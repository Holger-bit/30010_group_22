#ifndef SYSTEM_TICK_H_
#define SYSTEM_TICK_H_

void system_tick(void);

#endif /* SYSTEM_TICK_H_ */
