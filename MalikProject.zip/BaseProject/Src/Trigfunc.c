/*
 * Trigfunc.c
 *
 *  Created on: 7 Jan 2026
 *      Author: malik
 */

#include "Trigfunc.h"
#include "LUTfil.h"
#include <stdio.h>

#define MASK_511 0x1FF

void printFix(int32_t i)
{
	// Prints a signed 16.16 fixed point number
	if ((i & 0x80000000) != 0)
	{ // Handle negative numbers
		printf("-");
		i = ~i + 1;
	}
	printf("%ld.%04ld", i >> 16, 10000 * (uint32_t)(i & 0xFFFF) >> 16);
	// Print a maximum of 4 decimal digits to avoid overflow
}

// indsæt: vinkel i 512 skridt enheder (kan være negative)
// output: sinus i 2.14 fixed point
int16_t sinus(int32_t vinkel)
{
	uint16_t idx = (uint16_t)(vinkel & MASK_511); // periodisk indpakning
	int16_t s2_14 = SIN[idx];

	// converter 2.14 -> 16.16 for at printFix
	int32_t s16_16 = (((int32_t)s2_14) << 2);
	//printFix(s16_16);
	//printf("\n");
	return s2_14;
}

int16_t cosinus(int32_t vinkel)
{

	uint16_t idx = (uint16_t)((vinkel + 128) & MASK_511); // periodisk indpakning
	int16_t s2_14 = SIN[idx];

	// converter 2.14 -> 16.16 for at printFix
	int32_t s16_16 = ((int32_t)s2_14) << 2;
	//printFix(s16_16);
	//printf("\n");
	return s2_14;
}
