#include "ansi.h"
#define ESC 0x1B

#define UP_RIGHT	1
#define UP_LEFT 	2
#define DOWN_RIGHT 	3
#define DOWN_LEFT 	4

int count_digits(int n) {
    int count = 0;
    while (n > 0) {
        n /= 10;
        count++;
    }
    return count;
}

void hitWindow(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2) {
	uint8_t Hline_thick;
	uint8_t Vline_thick;
	uint8_t URcorner_thick;
	uint8_t ULcorner_thick;
	uint8_t LRcorner_thick;
	uint8_t LLcorner_thick;

//	uint8_t Hline_thin;
//	uint8_t Vline_thin;
	uint8_t URcorner_thin;
	uint8_t ULcorner_thin;
	uint8_t LRcorner_thin;
	uint8_t LLcorner_thin;

	// Tyk
	Hline_thick = 205;
	Vline_thick = 186;
	URcorner_thick = 187;
	ULcorner_thick = 201;
	LRcorner_thick = 188;
	LLcorner_thick = 200;

	// Tynd
//	Hline_thin = 196;
//	Vline_thin = 179;
	URcorner_thin = 191;
	ULcorner_thin = 218;
	LRcorner_thin = 217;
	LLcorner_thin = 192;


	int hits = 0;

	// Clear
	clrscr();

	inverse(0);

	// Tegn hitstekst
	gotoxy(x1 - 4 + (x2 - x1)/2, y1 + (y2 - y1)/2);
	printf("Hits: %d", hits);

	// Tegn hitskasse
	gotoxy(x1 - 5 + (x2 - x1)/2, y1 - 1 + (y2 - y1)/2);
	printf("%c", ULcorner_thin);
	gotoxy(x1 + 3 + (x2 - x1)/2, y1 - 1 + (y2 - y1)/2);
	printf("%c", URcorner_thin);
	gotoxy(x1 - 5 + (x2 - x1)/2, y1 + 1 + (y2 - y1)/2);
	printf("%c", LLcorner_thin);
	gotoxy(x1 + 3 + (x2 - x1)/2, y1 + 1 + (y2 - y1)/2);
	printf("%c", LRcorner_thin);

	// Tegn lodrette
	for(uint8_t i = y1 + 1; i < y2; i++) {
		gotoxy(x1, i);
		printf("%c", Vline_thick);
		gotoxy(x2, i);
		printf("%c", Vline_thick);
	}

	// Tegn vanrette
	for(uint8_t i = x1 + 1; i < x2; i++) {
		gotoxy(i, y1);
		printf("%c", Hline_thick);
		gotoxy(i, y2);
		printf("%c", Hline_thick);
	}

	// Tegn hjørner
	gotoxy(x1, y1);
	printf("%c", ULcorner_thick);
	gotoxy(x2, y1);
	printf("%c", URcorner_thick);
	gotoxy(x1, y2);
	printf("%c", LLcorner_thick);
	gotoxy(x2, y2);
	printf("%c", LRcorner_thick);


	gotoxy(x2, y2);

}

//void moving_ball(uint8_t x0, uint8_t y0, uint8_t dir) {
//
//	printf("\x1b[?25l");
//
//	gotoxy(x0,y0);
//	printf("o");
//
//	while (dir == UP_RIGHT) {
//		gotoxy(x, y);
//		clreol();
//		gotoxy(x+1,y-1);
//		printf("o");
//		x++;
//		y--;
//	}
//
//}
//









