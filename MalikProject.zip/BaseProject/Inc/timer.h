/*
 * timer.h
 *
 *  Created on: 14 Jan 2026
 *      Author: malik
 */

#ifndef TIMER_H_
#define TIMER_H_


void timer15_setcallback(void (*cb)(void));
void timer15_init(void);
void TIM1_BRK_TIM15_IRQHandler(void);
void timer15_stop(void);


#endif /* TIMER_H_ */
