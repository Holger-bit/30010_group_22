/*
 * bullets.c
 *
 *  Created on: 15 Jan 2026
 *      Author: malik
 */

#define FIX16_SHIFT 16
#define FIX16_MULT(a,b)  ( (int32_t)(((int64_t)(a) * (b)) >> FIX16_SHIFT) )

#define WIN_X1 1
#define WIN_Y1 1
#define WIN_X2 100
#define WIN_Y2 50

#define PLAY_MIN_X (WIN_X1 + 1)   // 2
#define PLAY_MAX_X (WIN_X2 - 1)   // 99
#define PLAY_MIN_Y (WIN_Y1 + 1)   // 2
#define PLAY_MAX_Y (WIN_Y2 - 1)   // 49

#include "vect.h"
#include "Trigfunc.h"
#include "bullets.h"
#include "ansi.h"
#include <stdio.h>

// initialisere bullet
static void initbullet(bullet_t *b, int32_t x, int32_t y, int32_t vx, int32_t vy)
{
    b->pos.x = x << 16;
    b->pos.y = y << 16;
    b->prev = b->pos;

    b->vel.x = vx << 16;
    b->vel.y = vy << 16;

    b->active = 1;
}

static int inside_playfield(int x, int y)
{
    return (x >= PLAY_MIN_X && x <= PLAY_MAX_X &&
            y >= PLAY_MIN_Y && y <= PLAY_MAX_Y);
}

//opdater bullet informationer
static void opdaterbullet(bullet_t *b, int32_t factor)
{
    if (!b->active) return;

    // Gemmer gamle placering for at rykke bolden
    b->prev = b->pos;

    int32_t k = factor << 16;

    // finder min position ved brug af ligningen x = x + vx *k
    b->pos.x += FIX16_MULT(b->vel.x, k);
    b->pos.y += FIX16_MULT(b->vel.y, k);

    // kill bullet if outside screen

    int16_t x = (int16_t)(b->pos.x >> 16);
    int16_t y = (int16_t)(b->pos.y >> 16);

    if (!inside_playfield(x, y)) {
        b->active = 0;
        return;
    }
}

// Tegner bold
static void tegnbullet(const bullet_t *b)
{
	if (!b->active) return;

	// Finder x, y værdier af hvor min bold skal være
	uint8_t x = (uint8_t)(b->pos.x >> 16);
	uint8_t y = (uint8_t)(b->pos.y >> 16);

	if (!inside_playfield(x, y)) return;   // never draw the frame

	// Placerer min bold på skærmen
	gotoxy(x,y);
	printf("%c", 248);
}

// sletter tidligere instanser
static void sletbullet(const bullet_t *b)
{
	// Finder placering af gammel bold
    uint8_t x = (uint8_t)(b->prev.x >> 16);
    uint8_t y = (uint8_t)(b->prev.y >> 16);

    if (!inside_playfield(x, y)) return;   // never erase the frame

    // sletter hvad der var i prev position
    gotoxy(x, y);
    printf(" ");
}


void bullets_init(bullet_t bullets[], uint8_t *next_bullet)
{
    for (int i = 0; i < MAX_BULLETS; i++) {
        bullets[i].active = 0;
        bullets[i].pos.x = bullets[i].pos.y = 0;
        bullets[i].prev.x = bullets[i].prev.y = 0;
        bullets[i].vel.x = bullets[i].vel.y = 0;
    }
    *next_bullet = 0;
}

// Skyder
void shoot(bullet_t bullets[],uint8_t *next_bullet,
    int x, int y, int vx, int vy)
{
	// try to find an inactive bullet first
	for (int i = 0; i < MAX_BULLETS; i++) {
        if (!bullets[i].active) {
            initbullet(&bullets[i], x, y, vx, vy);
            return;
        }
    }

	// none free -> overwrite one (round-robin)
    initbullet(&bullets[*next_bullet], x, y, vx, vy);
    (*next_bullet)++;
    if (*next_bullet >= MAX_BULLETS) *next_bullet = 0;
}

void bullets_poll(bullet_t bullets[])
{
    for (int i = 0; i < MAX_BULLETS; i++) {
    	// Always erase previous position
    	sletbullet(&bullets[i]);

    	// Only update/draw if bullet is active
    	if (bullets[i].active) {
    		opdaterbullet(&bullets[i], 1);

        	if (bullets[i].active) {
        		tegnbullet(&bullets[i]);
        	}
    	}
    }
}
