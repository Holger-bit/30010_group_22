#include <stdint.h>
#include <stdbool.h>

#ifndef LCDPUSH_H_
#define LCDPUSH_H_


void lcd_write_string(uint8_t *buffer, char* string, uint16_t line);
void lcd_write_powerup(uint8_t *buffer, char* string, uint16_t line);
void lcd_write_timer(uint8_t *buffer, char* string, uint16_t line, uint8_t offset);
void lcd_write_score(uint8_t *buffer, uint16_t line, uint16_t score);
void lcd_write_heart(uint8_t *buffer, char* string, uint16_t line);
void lcd_hearts_remove(char *hearts);
void game_over(uint8_t *buffer);
void lcd_clear(uint8_t *buffer);
void lcd_update(void);
void lcd_tick(void);


#endif /* LCDPUSH_H_ */
