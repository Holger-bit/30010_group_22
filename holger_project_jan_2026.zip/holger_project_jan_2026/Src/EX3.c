/*
 * EX3.c
 *
 *  Created on: 7. jan. 2026
 *      Author: root
 */
#include <stdint.h>
#include <stdio.h>
#include "LUT_sin.h"
#include "EX3.h"

#define FIX14_SHIFT 14
#define FIX14_MULT(a, b) ( (a)*(b) >> FIX14_SHIFT )
#define FIX14_DIV(a, b) ( ((a) << FIX14_SHIFT) / b )



void printFix(int32_t i);
int32_t expand(int32_t i);
int32_t sinusfunk(int32_t i);
int32_t cosfunk(int32_t i);
void rotateVector(vector_t *v, int32_t angle);
void initVector(vector_t *v, int32_t x, int32_t y);

void printFix(int32_t i) {
	i = i << 2;
    // Prints a signed 16.16 fixed point number
    if ((i & 0x80000000) != 0) { // Handle negative numbers
        printf("-");
        i = ~i + 1;
    }
    printf("%ld.%04ld", i >> 16, 10000 * (uint32_t)(i & 0xFFFF) >> 16);
    // Print a maximum of 4 decimal digits to avoid overflow
}

int32_t expand(int32_t i) {
    // Converts an 18.14 fixed point number to 16.16
    return i << 2;
}

int32_t sinfunk(int32_t i)
{
	while(i<0){i+=512;};
	int32_t fra_tabel = lut[i%512];
	int32_t resultat = (fra_tabel);
	return resultat;
}

int32_t cosfunk(int32_t i)
{
	i += 128;
	return sinfunk(i);
}

void rotateVector(vector_t *v, int32_t angle)
{
	int32_t x = FIX14_MULT(v->x,cosfunk(angle)) - FIX14_MULT(v->y,sinfunk(angle));
	int32_t y = FIX14_MULT(v->x,sinfunk(angle)) + FIX14_MULT(v->y,cosfunk(angle));
	v-> x = x;
	v-> y = y;
}

void initVector(vector_t *v, int32_t x, int32_t y)
{
	v->x = x << 14;
	v->y = y << 14;
}
