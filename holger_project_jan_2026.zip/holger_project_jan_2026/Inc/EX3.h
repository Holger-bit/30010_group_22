/*
 * EX3.h
 *
 *  Created on: 7. jan. 2026
 *      Author: root
 */


#ifndef EX3_H_
#define EX3_H_

#include <stdint.h>
#include <stdio.h>
typedef struct {
int32_t x, y;
} vector_t;

void printFix(int32_t i);
int32_t expand(int32_t i);
int32_t sinfunk(int32_t i);
int32_t cosfunk(int32_t i);
void rotateVector(vector_t *v, int32_t angle);
void initVector(vector_t *v, int32_t x, int32_t y);



#endif /* EX3_H_ */
