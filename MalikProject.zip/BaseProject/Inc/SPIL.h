/*
 * SPIL.h
 *
 *  Created on: 12. jan. 2026
 *      Author: root
 */

#ifndef SPIL_H_
#define SPIL_H_

#include <stdint.h>
#include <stdio.h>

void run_game_manager(void);


#endif /* SPIL_H_ */
