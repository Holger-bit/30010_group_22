#ifndef GAME_MANAGER_H
#define GAME_MANAGER_H

#include <stdint.h>

typedef enum {
    STATE_MENU,
    STATE_PLAYING,
    STATE_HELP
} GameState;

void run_game_manager(void);

#endif
