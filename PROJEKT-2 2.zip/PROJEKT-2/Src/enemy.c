#include "enemy.h"
#include "ansi.h"
#include <stdio.h>
#include "30010_io.h"
#include "EX5.h"
#include "levels.h"

// Variabler (Fjernet static på enemies så projectiles.c kan se dem)
enemy_t enemies[MAX_ENEMIES];
static uint8_t enemy_count = 0;
volatile uint8_t enemy_start = 0;
volatile uint8_t enemy_step = 0;
static uint16_t spawn_timer = 0;
static uint16_t move_counter = 0;
static uint8_t level_speed = 1;
static uint16_t score = 0;

#define GRID_SLOTS 10
#define SLOT_WIDTH 10
#define START_X 2
#define START_Y 2
#define WAVES 5
#define NO_SPAWN 255

typedef struct {
    uint8_t delay[GRID_SLOTS*WAVES];
    uint8_t spawned[GRID_SLOTS*WAVES];
} wave_t;

static wave_t current_wave = {
    .delay   = {NO_SPAWN, 0,  1, 		NO_SPAWN, NO_SPAWN, NO_SPAWN, NO_SPAWN, 5, 		  2,  		NO_SPAWN,
    			7,		  3,  NO_SPAWN, 8, 		  NO_SPAWN, 6, 		  9, 		NO_SPAWN, 6,  		4,
				10, 	  6,  NO_SPAWN, 12, 	  7, 		NO_SPAWN, 14, 		NO_SPAWN, 10, 		9,
				NO_SPAWN, 9,  10, 		NO_SPAWN, NO_SPAWN, 15, 	  NO_SPAWN, 16, 	  15, 		NO_SPAWN,
				17, 	  12, 18, 		NO_SPAWN, 12, 		NO_SPAWN, 17, 		19, 	  NO_SPAWN, 13},
    .spawned = {0}
};

void printEnemy(uint8_t x, uint8_t y, uint8_t enemy_type) {
    if (y < 3) return; // SIKKERHED: Tegn aldrig på linje 1 eller 2

    if (enemy_type == 1) {
        fgcolor(2);
        gotoxy(x, y);   printf(" /\\_/\\ ");
        gotoxy(x, y+1); printf("( 0 0 )");
        gotoxy(x, y+2); printf("=(_Y_)=");
        gotoxy(x, y+3); printf("  V-V  ");
        fgcolor(15);
    }
}

void clearEnemy(uint8_t x, uint8_t y) {

    for (int i = 0; i < 4; i++) {
        if (y + i >= 3) { // Tjek hver af de 4 linjer i fjenden
            gotoxy(x, y + i);
            printf("       ");
        }
    }
}
void spawnEnemyAtColumn(uint8_t col)
{
    for (uint8_t i = 0; i < MAX_ENEMIES; i++) {
        if (!enemies[i].alive) {

            enemies[i].x = START_X + col * SLOT_WIDTH;
            enemies[i].y = START_Y;
            enemies[i].alive = 1;

            if (i >= enemy_count)
                enemy_count = i + 1;

            enemy_start = 1;
            return;
        }
    }
}

void killEnemy(enemy_t *dying_enemy) {
	score += 10;
    clearEnemy(dying_enemy->x, dying_enemy->y);
    dying_enemy->alive = 0;
    if (score >= 250) {
    	lvlup();
    	score = 0;
    }
}

uint16_t get_score(void) {
	return score;
}

void reset_score(void) {
	score = 0;
}

static uint8_t detectCollision(void)
{
    uint8_t hits = 0;

    for (uint8_t i = 0; i < enemy_count; i++)
    {
        if (enemies[i].alive && enemies[i].y > 44)
        {
            hits++;
            killEnemy(&enemies[i]);
        }
    }

    return hits;
}


void enemy_tick(void) {


    spawn_timer++; // Tæller hver frame (10ms)
    level_speed = get_lvl();

    /* ---- Wave spawner ---- */
    for (uint8_t i = 0; i < GRID_SLOTS*WAVES; i++) {
        if (current_wave.delay[i] == NO_SPAWN)
            continue;
        if (!current_wave.spawned[i] &&
            spawn_timer >= current_wave.delay[i] * 200/level_speed) {

            spawnEnemyAtColumn(i % GRID_SLOTS);
            current_wave.spawned[i] = 1;
        }
    }

    /* ---- Enemy movement rate ---- */
    if (++move_counter >= 50/level_speed) {
        enemy_step = 1;
        move_counter = 0;
    }
}

uint8_t enemy_update(void)
{
    uint8_t hits = 0;   // ← lokal variabel (lever kun i denne funktion)

    if (enemy_step)
    {
        // 1) Flyt enemies
        for (uint8_t i = 0; i < enemy_count; i++)
        {
            if (enemies[i].alive)
            {
                clearEnemy(enemies[i].x, enemies[i].y);
                enemies[i].y++;
            }
        }

        // 2) TJEK om nogen ramte bunden
        hits = detectCollision();

        // 3) Tegn enemies igen
        for (uint8_t i = 0; i < enemy_count; i++)
        {
            if (enemies[i].alive)
            {
                printEnemy(enemies[i].x, enemies[i].y, 1);
            }
        }

        enemy_step = 0;
    }

    return hits;   // ← send antal “bottom hits” tilbage til SPil.c
}


void init_enemies_session(void) {
    enemy_count = 0;
    enemy_start = 0;
    enemy_step = 0;
    spawn_timer = 0;
    move_counter = 0;

    for(int i = 0; i < GRID_SLOTS * WAVES; i++) {
        current_wave.spawned[i] = 0;
    }
    for(int i = 0; i < MAX_ENEMIES; i++) {
        enemies[i].alive = 0;
    }
}

