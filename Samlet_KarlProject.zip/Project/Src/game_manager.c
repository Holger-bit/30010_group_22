#include "game_manager.h"
#include "game_menu.h"
#include "game_play.h"
#include "game_help.h"

void run_game_manager(void)
{
    GameState state = STATE_MENU;
    uint8_t selected = 0;

    menu_init(&selected);

    while (1) {
        switch (state) {

        case STATE_MENU:
            state = menu_update(&selected);
            break;

        case STATE_PLAYING:
            state = play_update();
            break;

        case STATE_HELP:
            state = help_update();
            break;
        }
    }
}
