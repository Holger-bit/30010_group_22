/*
 * SPIL.h
 *
 *  Created on: 12. jan. 2026
 *      Author: root
 */

#ifndef SPIL_H_
#define SPIL_H_


#include <stdint.h>
#include <stdio.h>

extern volatile uint8_t game_tick;

void run_game_manager(void);
void min_timer_callback(void);



#endif /* SPIL_H_ */
