#ifndef JOYSTICK_H
#define JOYSTICK_H

#include <stdint.h>

void setJoystick(void);
uint8_t readJoystick(void);

#endif
