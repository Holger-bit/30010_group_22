/*
 * startscreen.c
 *
 *  Created on: 13. jan. 2026
 *      Author: root
 */
#include "ansi.h"
#include <stdint.h>
#include <stdio.h>
#include "startscreen.h"
#include "SPIL.h"

void maketitle(){
	clrscr();
	printf("\x1b[?25l"); // skjul cursoren

	uint8_t x = 5;
	uint8_t y = 5;



	gotoxy(x,y);
	printf(" ######  ########     ###     ######  ########      ##     ##    ###    ##     ##");
	gotoxy(x,++y);
	printf("##    ## ##     ##   ## ##   ##    ## ##            ##     ##   ## ##   ###   ###");
	gotoxy(x,++y);
	printf("##       ##     ##  ##   ##  ##       ##            ##     ##  ##   ##  #### ####");
	gotoxy(x,++y);
	printf(" ######  ########  ##     ## ##       ######        ######### ##     ## ## ### ##");
	gotoxy(x,++y);
	printf("      ## ##        ######### ##       ##            ##     ## ######### ##     ##");
	gotoxy(x,++y);
	printf("##    ## ##        ##     ## ##    ## ##            ##     ## ##     ## ##     ##");
	gotoxy(x,++y);
	printf(" ######  ##        ##     ##  ######  ########      ##     ## ##     ## ##     ##");

	uint8_t etnytypunkt = 22;
	uint8_t etnytxpunkt = 40;



	// abe tegning fra internettet, "asciiart"
	gotoxy(etnytxpunkt,etnytypunkt);
	printf("    .--.  .-'''-.  .--.");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("   /.--./'.-. .-.`\\.--.\\");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("   ||  / / .| | .\\ \\  ||");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("   \\\\_/| \\__| |__/ |\\_//");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("    `-'\\  .-----.  /`-'");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("        \\/       \\/");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("        (\\`.___.'/)");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("         \\`.___.'/");
	gotoxy(etnytxpunkt,++etnytypunkt);
	printf("          `.___.'");
}

void make_menu(uint8_t selected, uint16_t highscore){
	uint8_t x = 5;
	uint8_t y = 12;

	uint8_t style1;
	uint8_t style2;
	// 0 = dobbelt streg
	// 1 = singel streg

	if (selected == 0) {
	    style1 = 0;
	    style2 = 1;
	} else {
	    style1 = 1;
	    style2 = 0;
	}


	window(x,y+10, x+12, y+12, "Start game", style1);

	window(x,y+16, x+12, y+18, "Help", style2);

	//highscore
	gotoxy(40, 17);
	printf("HIGHSCORE: %04d", highscore);


}
