#include "game_manager.h"
#include "ansi.h"
#include "30010_io.h"


GameState help_update(void) {
	static char input;
    gotoxy(10,10);
    printf("I MENUEN BRUG 'W' OG 'S' TIL AT NAVIGERE");
    gotoxy(10,11);
    printf("TRYK 'ENTER' FOR AT VAELGE");
    gotoxy(10,13);
    printf("TRYK 'b' FOR AT GA TILBAGE");

    gotoxy(50,10);
    printf("I 1961 blev chimpansen Ham beloennet med et");
    gotoxy(50,11);
    printf("aeble efter sin succesfulde returrejse til rummet.");

    input = uart_get_char();
    if (input == 'b') {
        return STATE_MENU;
//        maketitle();
//        make_menu(selected);
    }
    else {
    	return STATE_HELP;
    }
}
