#ifndef LEVELS_H_
#define LEVELS_H_

void moving(void);
void writelvl(void);

void lvlup(void);


#endif
