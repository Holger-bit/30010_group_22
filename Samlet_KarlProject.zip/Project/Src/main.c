#include "30010_io.h"
#include "timer.h"
#include "system_tick.h"
#include "ansi.h"
#include "game_manager.h"

int main(void) {
//	uint8_t j;
//	uint8_t j_old = 0;

    uart_init(115200);
    clrscr();

    timer15_setCallback(system_tick);
    timer15_init();

    run_game_manager();


    while (1) {
    }
}
