/*
 * enemy.h
 *
 *  Created on: 20. jan. 2026
 *      Author: root
 */

#ifndef ENEMY_H_
#define ENEMY_H_

#include <stdint.h>

typedef struct {
    uint8_t x, y;
    uint8_t alive;
} enemy_t;

#define MAX_ENEMIES 10

// Gør variablerne synlige for projectiles.c
extern enemy_t enemies[MAX_ENEMIES];

// Funktioner
void enemy_tick(void);
void enemy(void);
void init_enemies_session(void);
void killEnemy(enemy_t *dying_enemy);

#endif
