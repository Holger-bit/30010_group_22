/*
 * projectiles.h
 *
 *  Created on: 16. jan. 2026
 *      Author: root
 */

#include "30010_io.h"
#include <stdint.h>
#include <stdio.h>

#ifndef PROJECTILES_H_
#define PROJECTILES_H_

#define MAX_PROJECTILES 10
#define MAX_BOMBS 1
#define MAX_POWERUP 25




typedef struct {
    int32_t x, y;
    int32_t vx, vy;
    uint8_t active;
    char under_char;
} Projectile;

void updateProjectiles(Projectile bullets[]);



//typedef struct {
//    int32_t x, y;
//    int32_t vx, vy;
//    uint8_t active;
//    char under_char;
//} LASER;
//
//void updatePowerup(LASER laser[]);




//typedef struct {
//    int32_t x, y;
//    int32_t vx, vy;
//    uint8_t active;
//    int16_t fuse;
//    char under_char;
//} Bomb;


//void updateBombs(Bomb bombs[], Projectile bullets[]);
//void spawnExplosionShots(Projectile bullets[], int x, int y);













#endif /* PROJECTILES_H_ */



