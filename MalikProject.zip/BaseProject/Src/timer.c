/*
 * timer.c
 *
 *  Created on: 14 Jan 2026
 *      Author: malik
 */


#include "joys.h"
#include "timer.h"
#include "stm32f30x.h"

static void (*tick_callback)(void)=0;

void timer15_setcallback(void (*cb)(void))
{
	tick_callback = cb;
}

void timer15_init(void)
{
	RCC->APB2ENR |= RCC_APB2Periph_TIM15; // Enable clock line to timer 15
	TIM15->CR1 &= ~TIM_CR1_CEN; // Configure timer 15
	TIM15->ARR = 99; // Set reload value
	TIM15->PSC = 6399; // Set prescale value
	TIM15->DIER |= TIM_DIER_UIE;
	NVIC_SetPriority(TIM1_BRK_TIM15_IRQn, 1);
	NVIC_EnableIRQ(TIM1_BRK_TIM15_IRQn);
	TIM15->CR1 |= TIM_CR1_CEN;
}

void TIM1_BRK_TIM15_IRQHandler(void)
{
	if (TIM15->SR & TIM_SR_UIF) {
		TIM15->SR &= ~TIM_SR_UIF;
		if (tick_callback){
			tick_callback();
		}
	}
}

void timer15_stop(void)
{
    TIM15->CR1 &= ~TIM_CR1_CEN;
}
