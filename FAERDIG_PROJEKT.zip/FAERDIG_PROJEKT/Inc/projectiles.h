#ifndef PROJECTILES_H_
#define PROJECTILES_H_

#include <stdint.h>
#include "vect.h"
#include "enemy.h"

#define MAX_PROJECTILES 50 // Brug dette navn i stedet for MAX_BULLETS
#define MAX_BOMBS 1

extern enemy_t enemies[];

typedef struct {
    vector_t pos;     // 16.16
    vector_t vel;     // 16.16
    vector_t prev;    // 16.16
    uint8_t active;
} bullet_t; // Du kan kalde den bullet_t eller Projectile, bare vær konsistent



typedef struct {
    int32_t x, y;
    int32_t vx, vy;
    uint8_t active;
    int16_t fuse;
    char under_char;
} Bomb;

void bullets_init(bullet_t bullets[], uint8_t *next_bullet);
void shoot(bullet_t bullets[], uint8_t *next_bullet, int x, int y, int vx, int vy);
void updateProjectiles(bullet_t bullets[]);
void spawnExplosionShots(bullet_t bullets[], int x, int y);
void updateBombs(Bomb bombs[], bullet_t bullets[]);

#endif
