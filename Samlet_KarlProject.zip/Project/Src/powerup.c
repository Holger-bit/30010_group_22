#include "powerup.h"
#include "LCDpush.h"
#include "joystick.h"

typedef enum {
    POWERUP_EMPTY,
    POWERUP_READY,
    POWERUP_ACTIVE
} powerup_state_t;

static powerup_state_t powerup_state = POWERUP_READY;
static uint16_t powerup_timer = 0;
static uint16_t  powerup_offset = 0;

#define POWERUP_STEP_TICKS     30   // how often the bar moves
#define POWERUP_MAX_STEPS      20   // length of bar

void use_powerup(void)
{
    static uint8_t j_old = 0;
    uint8_t j = readJoystick();

    /* rising edge on CENTER */
    if (powerup_state == POWERUP_READY &&
    	j != j_old &&
		j & (1 << 4)) {

        powerup_state = POWERUP_ACTIVE;
        powerup_timer = 0;
    }

    j_old = j;
}

bool powerup_is_empty(void) {
	return powerup_state == POWERUP_EMPTY;
}
bool powerup_is_ready(void) {
	return powerup_state == POWERUP_READY;
}
bool powerup_is_active(void) {
	return powerup_state == POWERUP_ACTIVE;
}
uint8_t powerup_get_offset(void) {
	return powerup_offset;
}


void powerup_tick(void)
{
    if (powerup_state == POWERUP_ACTIVE) {
        powerup_timer++;

        if (powerup_timer >= POWERUP_STEP_TICKS) {
            powerup_timer = 0;
            powerup_offset++;

            if (powerup_offset >= POWERUP_MAX_STEPS) {
                powerup_state = POWERUP_EMPTY;
                powerup_offset = 0;
            }
        }
    }
}
