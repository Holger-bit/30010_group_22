/*
 * Player_enemies.h
 *
 *  Created on: 15. jan. 2026
 *      Author: root
 */
#include <stdint.h>
#include <stdio.h>
#include "spil.h"
#include "ansi.h"
#include "30010_io.h"

#ifndef PLAYER_ENEMIES_H_
#define PLAYER_ENEMIES_H_


typedef struct {
    int32_t x, y;  // Position
    int32_t w, h;    // Bredde og højde på jeres ASCII art
    int8_t tilt; // tilt
} Entity;

void makeplayer(Entity * p, int erase);

#endif /* PLAYER_ENEMIES_H_ */
