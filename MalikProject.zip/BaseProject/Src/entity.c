/*
 * entity.c
 *
 *  Created on: 15 Jan 2026
 *      Author: malik
 */

#include "entity.h"
#include "ansi.h"

#include <stdio.h>


void entity_erase(const entity_t *e)
{
    gotoxy(e->prev_x, e->prev_y);
    printf(" ");
}

void entity_draw(const entity_t *e)
{
    gotoxy(e->x, e->y);
    printf("%c", e->ch);
}

