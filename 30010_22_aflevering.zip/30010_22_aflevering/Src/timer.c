#include "timer.h"
#include "stm32f30x_conf.h" // STM32 config


volatile uint8_t gtimerIRQFLAG = 0;


void timer15_init(void) {
	RCC->APB2ENR |= RCC_APB2Periph_TIM15;   	//Enabler clocken til timer15
	TIM15->CR1 &= ~TIM_CR1_CEN;             	// Gør så timeren ikke kører før vi har initieret den
	TIM15->PSC = 6399;   						// Prescaler: Dividerer 64 MHz clock med (6399 + 1) = 6400 → 10 kHz timer clock
	TIM15->ARR = 99;     						// Auto-reload: Hav vores interrupt på hver 100 tick, så vi har en interrupt hver 0.01 s (100 Hz)
	TIM15->DIER |= TIM_DIER_UIE;   				// Enabler update interrupt
	NVIC_SetPriority(TIM1_BRK_TIM15_IRQn, 1); 	// Giver interrupt rigtig høj prioritet
	NVIC_EnableIRQ(TIM1_BRK_TIM15_IRQn); 		// Enabler interrupts
	TIM15->CR1 |= TIM_CR1_CEN;   				// Starter timeren
}


void TIM1_BRK_TIM15_IRQHandler(void)
{
	if (TIM15->SR & TIM_SR_UIF) { 	// Clearer interrupt flag
		TIM15->SR &= ~TIM_SR_UIF;

		gtimerIRQFLAG = 1;			// Tælleren brugt i SPil.c
	}
}
