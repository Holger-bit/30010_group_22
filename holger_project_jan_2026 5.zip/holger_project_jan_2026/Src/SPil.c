#include "spil.h"
#include "startscreen.h"
#include "ansi.h"
#include "30010_io.h"
#include "Player_enemies.h"
#include "EX5.h"
#include "LCDpush.h"
#include <string.h>
#include "charset.h"
#include "gravity_astroide.h"
#include "timer.h"
#include "projectiles.h"

// --- GLOBALE VARIABLER ---
static Entity player = {47, 40, 6, 6, 0};
static bullet_t bullets[MAX_PROJECTILES];
static uint8_t next_bullet_idx = 0;

volatile uint8_t game_tick = 0;

// Callback fra Timer 15
void spil_timer_callback(void) {
    game_tick = 1;
}

typedef enum {
    STATE_MENU,
    STATE_PLAYING,
    STATE_HELP
} State;

void run_game_manager(void) {
    State currentState = STATE_MENU;
    uint8_t selected = 0;
    char input;

    // --- HARDWARE INIT (Kører kun én gang) ---
    setupjoystick();
    setupLed();
    setLed(COLOUR_BLACK);
    lcd_init();
    timer15_init();
    timer15_setCallback(spil_timer_callback);

    maketitle();
    make_menu(selected);

    while (1) {
        input = uart_get_char();

        switch (currentState) {
            case STATE_MENU:
                if (input != 0) {
                    if (input == 'w') { selected = 0; make_menu(selected); }
                    else if (input == 's') { selected = 1; make_menu(selected); }
                    else if (input == 13 || input == 32) {
                        if (selected == 0) {
                            currentState = STATE_PLAYING;
                        } else {
                            clrscr();
                            currentState = STATE_HELP;
                        }
                    }
                }
                break;

            case STATE_PLAYING:
            {
                static uint8_t start = 0;
                static uint16_t score = 0;
                static char hearts[] = "123";
                static uint8_t buffer[512];

                // TÆLLERE (Baseret på 10ms ticks)
                static uint32_t skud_taeller = 0;
                static uint32_t sten_taeller = 0;
                static uint32_t lcd_taeller = 0;

                // POWERUP VARIABLE
                static uint8_t powerup_ready = 0;
                static uint8_t powerup_active = 0;
                static uint8_t timer_offset = 0;
                static char timer_str[] = "01234567890123456789";

                // --- RESET VED HVER SPIL-START ---
                if (start == 0) {
                    player.x = 47; player.y = 40; player.tilt = 0;
                    score = 0;
                    strcpy(hearts, "123");
                    skud_taeller = 0; sten_taeller = 0; lcd_taeller = 0;
                    powerup_ready = 0; powerup_active = 0; timer_offset = 0;

                    clrscr();
                    window(1, 1, 100, 50, " SPACE HAM ", 0);
                    // (drawPortal er fjernet herfra)
                    bullets_init(bullets, &next_bullet_idx);
                    makeplayer(&player, 0);
                    start = 1;
                }

                // --- MOTOR (100 Hz) ---
                if (game_tick == 1) {
                    game_tick = 0;

                    uint8_t joy = readJoystick();
                    int8_t old_tilt = player.tilt;
                    int32_t old_x = player.x;

                    // 1. Powerup system
                    if (input == 'r' || input == 'R') {
                        powerup_ready = 1;
                        setLed(COLOUR_BLUE);
                    }
                    if (joy == 16 && powerup_ready && !powerup_active) {
                        powerup_ready = 0;
                        powerup_active = 1;
                        timer_offset = 0;
                        setLed(COLOUR_PINK);
                    }

                    // 2. Navigation
                    if (joy == 4) player.tilt = -2;
                    else if (joy == 5) player.tilt = -1;
                    else if (joy == 8) player.tilt = 2;
                    else if (joy == 9) player.tilt = 1;
                    else player.tilt = 0;

                    if (input == 'a' && player.x > 3) player.x -= 2;
                    if (input == 'd' && player.x < (99 - player.w)) player.x += 2;

                    // 3. Skydning
                    skud_taeller++;
                    uint32_t cooldown = powerup_active ? 10 : 30;
                    if (skud_taeller >= cooldown) {
                        shoot(bullets, &next_bullet_idx, player.x + 3, player.y - 1, player.tilt, -1);
                        skud_taeller = 0;
                    }

                    // 4. Asterolde og Skud
                    bullets_poll(bullets);

                    sten_taeller++;
                    if (sten_taeller >= 3) {
                        updateAsteroid(&rocky);
                        sten_taeller = 0;
                    }

                    // 5. Raket
                    if (player.x != old_x || player.tilt != old_tilt) {
                        int32_t tx = player.x; int8_t tt = player.tilt;
                        player.x = old_x; player.tilt = old_tilt;
                        makeplayer(&player, 1);
                        player.x = tx; player.tilt = tt;
                    }
                    makeplayer(&player, 0);

                    // 6. LCD HUD (Hvert 100. tick = 1 sekund)
                    lcd_taeller++;
                    if (lcd_taeller >= 100) {
                        memset(buffer, 0x00, 512);
                        lcd_write_heart(buffer, hearts, 1);
                        lcd_write_score(buffer, 104, score);

                        if (powerup_ready) lcd_write_powerup(buffer, "1", 385);

                        if (powerup_active) {
                            lcd_write_timer(buffer, timer_str, 451, timer_offset);
                            if (timer_offset < 19) timer_offset++;
                            else {
                                powerup_active = 0;
                                setLed(COLOUR_BLACK);
                            }
                        }
                        lcd_push_buffer(buffer);
                        lcd_taeller = 0;
                    }

                    // 7. Tilbage til menu
                    if (input == 'b') {
                        setLed(COLOUR_BLACK);
                        start = 0;
                        currentState = STATE_MENU;
                        clrscr(); maketitle(); make_menu(0);
                        break;
                    }
                }
            }
            break;

            case STATE_HELP:
                if (input == 'b') {
                    currentState = STATE_MENU;
                    clrscr(); maketitle(); make_menu(0);
                }
                break;
        }
    }
}
