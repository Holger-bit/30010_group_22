/*
 * Ballgame.h
 *
 *  Created on: 8 Jan 2026
 *      Author: malik
 */

#ifndef BALLGAME_H_
#define BALLGAME_H_

#include <stdint.h>
#include "Trigfunc.h"
#include "vect.h"
#include "ansi.h"

typedef struct {
	vector_t pos; // position (x,y) i 16.16
	vector_t vel; // position (vx,vy) i 16.16
	vector_t prev; // tidligere placering i 16.16
} ball_t;

void initball(ball_t *b, int32_t x, int32_t y, int32_t vx, int32_t vy);
void opdaterball( ball_t *b, int32_t factor);
void tegnball(const ball_t *b);
void sletball(const ball_t *b);
void moveball(ball_t *b, uint8_t x1, uint8_t y1,uint8_t x2, uint8_t y2);
uint8_t checkCollision(ball_t *b, uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint32_t *hits);
void Playballgame( uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2);


#endif /* BALLGAME_H_ */
