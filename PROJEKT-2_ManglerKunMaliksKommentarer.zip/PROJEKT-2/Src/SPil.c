#include "Players.h"
#include "spil.h"
#include "startscreen.h"
#include "ansi.h"
#include "30010_io.h"
#include "EX5.h"
#include "LCDpush.h"
#include <string.h>
#include "charset.h"
#include "gravity_astroide.h"
#include "timer.h"
#include "bullets.h"
#include "enemy.h"
#include "boss.h"
#include "levels.h"
#include "winscreen.h"

void run_game_manager(void) {


	//Declarations and initialization
	uint8_t start = 0;

	Entity player = {47, 40, 6, 6, 0};
    Asteroid rocky = {2, 15, 1};

    bullet_t bullets[MAX_BULLETS];
	uint8_t next_bullet_idx = 0;

	State currentState = STATE_MENU;
    uint8_t selected = 0;
    uint8_t level = 1;
    uint16_t score = 0;
    uint16_t highscore = 0;

    reset_lvl();

    char input;

    // tællere
    uint32_t skud_taeller;
    uint32_t sten_taeller;
	uint32_t lcd_taeller;
	uint32_t lvl_taeller = 0;

	//power up
    uint8_t powerup_ready;
    uint8_t powerup_active;
    uint8_t timer_offset;

    //bombe
    char Bombs[4];
    uint8_t bomblen = 3; // 3 tegn + escape
	uint8_t bombtimer_active;
	uint8_t bombtimer_offset;
	int bombs_left; //antal bomber tilbage (til affyring)
    uint32_t cooldown;
    char hearts[4];

    // hardware
    setupjoystick();
    setupLed();
    setLed(COLOUR_BLACK);
    lcd_init();

    uint8_t powerlen = 20;
    uint8_t buffer[512]= {};
    Bomb bombs[MAX_BOMBS] = {0};
	lcd_clear(buffer);

    // lav menuen når man starter programmet
    maketitle();
    make_menu(selected, highscore);

    while (1) {
        input = uart_get_char();


        switch (currentState) { //switcher mellem states. Gør at vi kan have menu, spil, help screen, boss-key screen og level screen

        	case STATE_MENU:
                if (input != 0) { //Når der er input
                    if (input == 'w') { selected = 0; make_menu(selected, highscore); }
                    else if (input == 's') { selected = 1; make_menu(selected, highscore); }
                    else if (input == 13 || input == 32) {
                        if (selected == 0) {			// Hvis man vælger "Start game" går man først til level screen, som automatisk går til spillet
                        	clrscr();
                        	print_lvlscreen();
                            currentState = STATE_LVL;
                        } else {						// Hvis man vælger "Help" går man til help screen
                            clrscr();
                            currentState = STATE_HELP;
                        }
                    }
                }
                break;

            case STATE_PLAYING:
            {
                // 1. udføres ved start af spil. Sker hver gang currentState ændrer sig til STATE_PLAYING med mindre man kommer fra boss-key screen
                if (start == 0) {
                    player.x = 47; player.y = 40; player.tilt = 0;
                    score = 0;


                    skud_taeller = 0; sten_taeller = 0; lcd_taeller = 0;
                    powerup_ready = 0; powerup_active = 0; timer_offset = 0;
                    init_enemies_session();
                    clrscr();
                    window(1, 1, 100, 50, " SPACE HAM ", 0);
                    bullets_init(bullets, &next_bullet_idx);
                    bombs_init(bombs);
                    makeplayer(&player, 0);
                    start = 1;

                    strcpy(hearts, "123");
                    hearts[0] = '1'; hearts[1] = '2'; hearts[2] = '3'; hearts[3] = '\0';

                    strcpy(Bombs, "123");


	                //bombe
					bombtimer_active = 0;
					bombtimer_offset = 0;

					bombs_left = 3; //antal bomber tilbage (til affyring)




                }


                if (gtimerIRQFLAG == 1) { // Vores timer sætter gtimerIRQFLAG = 1 hver 10ms
                	gtimerIRQFLAG = 0;

                	// inkræmenter taeller
                	skud_taeller++;
                    sten_taeller++;
                    lcd_taeller++;


                    uint8_t joy = readJoystick();
                    int8_t old_tilt = player.tilt;
                    int32_t old_x = player.x;
                    uint8_t old_level = level;
                    level = get_lvl();
                    score = get_score();

                    // enemy
                    enemy_tick();
                    uint8_t hits = enemy_update();

                    while (hits > 0) {
                        lcd_hearts_remove(hearts); //
                        hits--; //resetter hits når den går op så man ikke hele tiden mister liv
                    }



                    if (hearts[0] == '\0') {    //Hvis du mister alle liv så skal koden her sørger for at alt bliver reset og man kommer til menu
                        // game over
                        setLed(COLOUR_BLACK);
                        start = 0;
                        reset_score();

                        lcd_clear(buffer);      // ryd lcd
                        clrscr();

                        currentState = STATE_MENU;

                        maketitle();
                        make_menu(0, highscore);


                        init_enemies_session(); //næste spil starter med nye enemies


                        break;
                    }

                    // 2. Powerup
                    if (input == 'p') {
                        powerup_ready = 1; //Hvis man trykker p så får man en power-up
                        setLed(COLOUR_BLUE); //LED bliver blå hvis man har en power-up
                    }
                    if (joy == 16 && powerup_ready && !powerup_active) { //aktiverer en evt. power-up
                        powerup_ready = 0; //fjerner evt. power-up
                        powerup_active = 1; // og aktiverer den
                        timer_offset = 0; //Starter timer offset om (det er den som fjerner en 'blok' af strengen for hvert tick)
                        setLed(COLOUR_PINK); //Når power-up active så pink LED
                    }

                    if ((input == 'q') &&
                        bombs_left > 0 &&
                        !bombtimer_active)   //Hvis man trykker q og man har mere end 0 bomber tilbage og man ikke har en bombtimer active
                    																						// (Cooldown fra tidligere bomber)
                    {
                        bombtimer_active = 1;  //hvis man smider bombe aktiverer den bombtimer
                        bombtimer_offset = 0; //starter offset forfra. Virker som timer_offset fra power-up

                        bomb_spawn(bombs,
                                   player.x + 3, player.y - 1,
                                   player.tilt, -1,
                                   17);

                        bombs_left--;  //fjerner en bombe
                        lcd_bombs_remove(Bombs); //fjerner bombe fra LCD
                    }



                    // 3. Navigation
                    if (joy == 4) player.tilt = -2;
                    else if (joy == 5) player.tilt = -1;
                    else if (joy == 8) player.tilt = 2;
                    else if (joy == 9) player.tilt = 1;
                    else player.tilt = 0;

                    if (input == 'a' && player.x > 3) player.x -= 2;
                    if (input == 'd' && player.x < (99 - player.w)) player.x += 2;

                    // 4. Skydning


                    if (powerup_active == 1) {
                        cooldown = 10;  //  powerup  aktiv
                    } else {
                        cooldown = 30;  // normal
                    }


                    if (input == ' ' && skud_taeller >= cooldown) {
                        shoot(bullets, &next_bullet_idx,player.x + 2, player.y - 1,player.tilt, -1, 0);
                        skud_taeller = 0;
                    }

                    // 5. Asterolde og Skud
                    bullets_poll(bullets, &rocky);
                    bombs_update(bombs, bullets);



                    if (sten_taeller >= 15) {
                        // hver 15 gang så den er langsommere
                        updateAsteroid(&rocky);
                        sten_taeller = 0;
                    } else {

                        // fix til at bullet laver huller så den også printer når den ikke rykker sig
                        drawAsteroid(&rocky);
                    }

                    // 6. Raket
                    if (player.x != old_x || player.tilt != old_tilt) {
                        int32_t tx = player.x; int8_t tt = player.tilt;
                        player.x = old_x; player.tilt = old_tilt;
                        makeplayer(&player, 1);
                        player.x = tx; player.tilt = tt;
                    }
                    makeplayer(&player, 0);

                    // 7. LCD HUD (Hvert 100. tick = 1 sekund)



                    if (lcd_taeller >=100) {

                        memset(buffer, 0x00, 512); //Clearer LCD buffer
                        lcd_write_heart(buffer, hearts, 1); //Laver hjerter på bufferen (Line 1)
                        lcd_write_score(buffer, 104, score + (level - 1)*250); //Laver score
                        lcd_write_bomb(buffer, Bombs, 52); //Laver bomber på bufferen (Line 52)

						if (powerup_ready) lcd_write_powerup(buffer, "1", 385); //Hvis power-up er ready laver den et power-up symbol

						if (powerup_active) { //Hvis power-up er aktiv laver den en timer
							lcd_draw_timer(buffer, powerlen, 451, timer_offset);
							if (timer_offset < 19) timer_offset++; //tick baseret
							else {
								powerup_active = 0; // efter 19 slukker power-uppen
								setLed(COLOUR_BLACK);
							}
						}


						if (bombtimer_active) // når man kaster en bombe
						{
							lcd_draw_timer_omvendt(buffer, bomblen, 179, bombtimer_offset);

							if (bombtimer_offset < bomblen) //kør timeren til den skal stoppe : OBS : Dårligt navn (bomblen) til en timer længde
							{
								bombtimer_offset++; //samme som med power-up timeren lige over her
							}
							else
							{
								bombtimer_active = 0; // Cooldown er færdig
							}
						}

						lcd_push_buffer(buffer);  //Bufferen bliver pushet til LCD
						lcd_taeller = 0;
					}


                    // Gem highscore
                    if (score + (level - 1)*250 > highscore){
                    	highscore = score + (level - 1)*250;
                    }


                    // 8. Tilbage til menu
                    if (input == 'b') {
                        setLed(COLOUR_BLACK);
                        start = 0;
                        reset_score();
                        lcd_clear(buffer);
                        currentState = STATE_MENU;
                        clrscr(); maketitle(); make_menu(0, highscore);


						bombtimer_active = 0;
						bombs_left = 3; // resetter antal bomber
						for (int i = 0; i < MAX_BOMBS; i++) {
								if (bombs[i].active) {
									gotoxy(bombs[i].x, bombs[i].y);
									printf(" ");          // <-- ryd bomben visuelt
								}
								bombs[i].active = 0;
								bombs[i].fuse = 0;
						}
						powerup_ready = 0;
						powerup_active = 0;

                        break;
                    }

                    // 9. Brug Boss-key
                    if (input == 'y') {
						setLed(COLOUR_BLACK);
						lcd_clear(buffer);
						currentState = STATE_BOSS;
						clrscr(); boss_key();
						break;
					}

                    // 10. Vis level-skærm (Genstarter alle værdier bortset fra highscore og level, så hvert level starter er ens (med forskellige fjendehastigheder))
                    if (old_level != level && level <= 3) {
                        setLed(COLOUR_BLACK);
                        start = 0;
                        lcd_clear(buffer);
                        currentState = STATE_LVL;
                        clrscr(); print_lvlscreen();


						bombtimer_active = 0;
						bombs_left = 3; // resetter antal bomber
						for (int i = 0; i < MAX_BOMBS; i++) {
								if (bombs[i].active) {
									gotoxy(bombs[i].x, bombs[i].y);
									printf(" ");          // <-- ryd bomben visuelt
								}
								bombs[i].active = 0;
								bombs[i].fuse = 0;
						}
						powerup_ready = 0;
						powerup_active = 0;
						break;
					}


                    // 11. Vinderskærmen (Genstarter alle værdier bortset fra highscore, så spillet starter forfra, hvis man vil spille igen)
                    if (score + (level - 1)*250 >= 750) {
                        setLed(COLOUR_BLACK);
                        start = 0;
                        reset_lvl();
                        reset_score();
                        lcd_clear(buffer);
                        currentState = STATE_WIN;
                        clrscr(); winscreen();


						bombtimer_active = 0;
						bombs_left = 3; // resetter antal bomber
						for (int i = 0; i < MAX_BOMBS; i++) {
								if (bombs[i].active) {
									gotoxy(bombs[i].x, bombs[i].y);
									printf(" ");          // <-- ryd bomben visuelt
								}
								bombs[i].active = 0;
								bombs[i].fuse = 0;
						}
						powerup_ready = 0;
						powerup_active = 0;

                        break;
                    }
                }
            }
            break;

            case STATE_HELP:
            				// Printer alle vores controls og andre guideråd
                        	gotoxy(10,9);
                            printf("CONTROLS");
                        	gotoxy(10,10);
                            printf("USE W AND S IN THE MENU");
                            gotoxy(10,11);
                            printf("PRESS ENTER TO SELECT");
                            gotoxy(10,12);
                            printf("PRESS B TO GO BACK");
                            gotoxy(10,13);
                            printf("PRESS A AND D TO MOVE IN GAME");
                            gotoxy(10,14);
                            printf("PRESS P FOR POWERUP AND CENTER TO ACTIVATE");
                            gotoxy(10,15);
                            printf("PRESS Q FOR BOOOOOMB!");
                            gotoxy(10,16);
                            printf("MOVE JOYSTICK TO AIM");
                            gotoxy(10,17);
                            printf("SPACE TO SHOOT");
                            gotoxy(10,18);
                            printf("WE RECOMMEND PLAYING WITH A BUDDY UNLESS YOURE MENTAL!");
                            gotoxy(10,19);
                            printf("GOOD LUCK!");
                            gotoxy(10,20);
                            printf("PS. IF YOUR BOSS PASSES BY PRESS Y");


                            gotoxy(10,22);
                            printf("WHO WAS HAM?");
                            gotoxy(10,23);
                            printf("A CHIMPANZE! IN 1961 HE WAS WELCOMED BACK, TO");
                            gotoxy(10,24);
                            printf("EARTH, AFTER A TRIP TO SPACE, WITH AN APPLE!");

                            // Tilbage til menuen
                            input = uart_get_char();
                            if (input == 'b') {
                            currentState = STATE_MENU;
                            maketitle();
                            make_menu(selected, highscore);
                            }
                            break;

            // Boss-key-skærmen, der bare venter på, at man trykker på boss-key igen, så man kan komme tilbage til spillet
            case STATE_BOSS:
            	input = uart_get_char();
				if (input == 'y') {
					clrscr();
					window(1, 1, 100, 50, " SPACE HAM ", 0);
					currentState = STATE_PLAYING;
				}
            break;



            // Level-skærmen, der går til spillet efter 1,5 sekunder
            case STATE_LVL:
            	if (gtimerIRQFLAG == 1) {
            		gtimerIRQFLAG = 0;
					lvl_taeller++;
            	}

				if (lvl_taeller > 150) {
					lvl_taeller = 0;
					clrscr();
					window(1, 1, 100, 50, " SPACE HAM ", 0);
					currentState = STATE_PLAYING;
				}
			break;


			// Win-skærmen, der går tilbage til menuen, når man trykker 'b'
            case STATE_WIN:
            	input = uart_get_char();
				if (input == 'b') {
					clrscr(); maketitle(); make_menu(0, highscore);
					currentState = STATE_MENU;
				}
            break;

        }
    }
}
