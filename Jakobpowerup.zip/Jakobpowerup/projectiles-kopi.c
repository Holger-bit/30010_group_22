/*
 * projectiles.c
 *
 *  Created on: 16. jan. 2026
 *      Author: root
 */
#include "projectiles.h"
#include "ansi.h"
#include "30010_io.h"
#include "spil.h"


//static char get_background_char_at(int x, int y)
//                        	{
//                        	    // y==1 top HUD-linje? (tilpas hvis du bruger andre)
//                        	    // her genskaber vi bare rammer (| og -), ellers blank.
//                        	    if (y == 1 || y == 50) return '-';
//                        	    if (x == 1 || x == 100) return '|';
//                        	    return ' ';
//                        	}




void updateProjectiles(Projectile bullets[])
{
    static uint32_t move_counter = 0;
    move_counter++;

    if (move_counter >= 5000)
    {
        for (int i = 0; i < MAX_PROJECTILES; i++)
        {
            if (!bullets[i].active) continue;

            // 1) Genskab det der var under bullet før
            gotoxy(bullets[i].x, bullets[i].y);
            printf("%c", bullets[i].under_char);

            // 2) Flyt
            bullets[i].x += bullets[i].vx;
            bullets[i].y += bullets[i].vy;

            // 3) Deaktiver hvis ude af banen
            if (bullets[i].y < 3 || bullets[i].x < 2 || bullets[i].x > 99 || bullets[i].y > 49)

            {
                bullets[i].active = 0;
                continue;
            }

            // (OPTIONAL) Hvis du ved hvilke tegn der er vægge inde i banen:
            // char tile = get_background_char_at(bullets[i].x, bullets[i].y);
            // if (tile == '#') { bullets[i].active = 0; continue; }  // bullet stopper ved væg

            // 4) Gem hvad der er i baggrunden på NY position
            bullets[i].under_char = get_background_char_at(bullets[i].x, bullets[i].y);

            // 5) Tegn bullet
            gotoxy(bullets[i].x, bullets[i].y);
            printf("*");
        }

        move_counter = 0;
    }
}






//void updatePowerup(LASER laser[])
//{
//    static uint32_t move_counter = 0;
//    move_counter++;
//
//    if (move_counter >= 5000)
//    {
//        for (int i = 0; i < MAX_POWERUP; i++)
//        {
//            if (!laser[i].active) continue;
//
//            // 1) Genskab det der var under bullet før
//            gotoxy(laser[i].x, laser[i].y);
//            printf("%c", laser[i].under_char);
//
//            // 2) Flyt
//            laser[i].x += laser[i].vx;
//            laser[i].y += laser[i].vy;
//
//            // 3) Deaktiver hvis ude af banen
//            if (laser[i].y < 3 || laser[i].x < 2 || laser[i].x > 99 || laser[i].y > 49)
//
//            {
//                laser[i].active = 0;
//                continue;
//            }
//
//            // (OPTIONAL) Hvis du ved hvilke tegn der er vægge inde i banen:
//            // char tile = get_background_char_at(bullets[i].x, bullets[i].y);
//            // if (tile == '#') { bullets[i].active = 0; continue; }  // bullet stopper ved væg
//
//            // 4) Gem hvad der er i baggrunden på NY position
//            laser[i].under_char = get_background_char_at(laser[i].x, laser[i].y);
//
//            // 5) Tegn bullet
//            gotoxy(laser[i].x, laser[i].y);
//            printf("|");
//        }
//
//        move_counter = 0;
//    }
//}












//void spawnExplosionShots(Projectile bullets[], int x, int y) {
//	const int dirs[7][2] = {
//		{ 0,-1}, { 1, 0}, {-1, 0},
//		{ 1,-1}, {-1,-1}, { 1, 1}, {-1, 1}
//	};
//
//	for (int d = 0; d < 7; d++) {
//		// find en ledig bullet-slot
//		for (int j = 0; j < MAX_PROJECTILES; j++) {
//			if (bullets[j].active == 0) {
//				bullets[j].active = 1;
//				bullets[j].x = x;
//				bullets[j].y = y;
//				bullets[j].vx = dirs[d][0];
//				bullets[j].vy = dirs[d][1];
//
//
//
//				break;
//			}
//		}
//	}
//}


//void updateBombs(Bomb bombs[], Projectile bullets[])
//{
//    static uint32_t move_counter = 0;
//    move_counter++;
//
//    if (move_counter >= 5000)
//    {
//        for (int i = 0; i < MAX_BOMBS; i++)
//        {
//            if (!bombs[i].active) continue;
//
//            // 1) Genskab det der var under bomben før
//            gotoxy(bombs[i].x, bombs[i].y);
//            printf("%c", bombs[i].under_char);
//
//            // 2) Flyt
//            bombs[i].x += bombs[i].vx;
//            bombs[i].y += bombs[i].vy;
//
//            // 3) Fuse ned
//            bombs[i].fuse--;
//
//            if (bombs[i].fuse <= 0)
//            {
//                spawnExplosionShots(bullets, bombs[i].x, bombs[i].y);
//                bombs[i].active = 0;
//                continue;
//            }
//
//            // 4) Deaktiver hvis ude af banen
//            if (bombs[i].y < 3 || bombs[i].x < 2 || bombs[i].x > 99 || bombs[i].y > 49)
//
//            {
//                bombs[i].active = 0;
//                continue;
//            }
//
//            // 5) Gem baggrund på ny position
//            bombs[i].under_char = get_background_char_at(bombs[i].x, bombs[i].y);
//
//            // 6) Tegn bomben
//            gotoxy(bombs[i].x, bombs[i].y);
//            printf("*");
//        }
//
//        move_counter = 0;
//    }
//}
