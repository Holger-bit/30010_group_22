#include "player.h"
#include "ansi.h"

#define KEY_HOLD_TICKS 5   // tune this

void player_init(Entity *p)
{
    p->x = 47;
    p->y = 44;
    p->w = 6;
    p->h = 6;
    p->tilt = 0;

    p->left_pressed  = 0;
    p->right_pressed = 0;
    p->move_counter  = 0;

    makeplayer(p, 0);
}

void player_handle_input(Entity *p, char key, uint8_t joystick)
{
    /* joystick → tilt */
    if (joystick == 4) p->tilt = -2;
    else if (joystick == 5) p->tilt = -1;
    else if (joystick == 1 || joystick == 16) p->tilt = 0;
    else if (joystick == 9) p->tilt = 1;
    else if (joystick == 8) p->tilt = 2;
    else if (joystick == 0) p->tilt = 0;

    /* keyboard impulse → timed state */
    if (key == 'a' && p->x > 3) {
        p->x -= 2;
    }
    else if (key == 'd' && p->x < (99 - p->w)) {
        p->x += 2;
    }
}

void player_erase(Entity *p, int32_t old_x, int8_t old_tilt)
{
    int32_t nx = p->x;
    int8_t nt = p->tilt;

    p->x = old_x;
    p->tilt = old_tilt;
    makeplayer(p, 1);

    p->x = nx;
    p->tilt = nt;
}

void makeplayer(Entity *p, int erase)
{
    // Vi har 5 tilt-stadier og raketten er 6 linjer høj
    char *sprites[5][6] = {
        // [0]: MEGET VENSTRE (-2) -> Top: \\;
        { "\\\\    ", " . . ", " |o| ", " |o| ", " .-. ", "|/-\\|" },
        // [1]: LIDT VENSTRE (-1)  -> Top: \;
        { " \\   ", " . . ", " |o| ", " |o| ", " .-. ", "|/-\\|" },
        // [2]: LIGE UD (0)        -> Top: |
        { "  |  ", " . . ", " |o| ", " |o| ", " .-. ", "|/-\\|" },
        // [3]: LIDT HØJRE (1)     -> Top: /
        { "   / ", " . . ", " |o| ", " |o| ", " .-. ", "|/-\\|" },
        // [4]: MEGET HØJRE (2)    -> Top: //
        { "    //", " . . ", " |o| ", " |o| ", " .-. ", "|/-\\|" }
    };

    // SIKKERHED: Tving index til at være mellem 0 og 4
    int index = p->tilt + 2;
    if (index < 0) index = 0;
    if (index > 4) index = 4;

    for (int i = 0; i < 6; i++) {
        gotoxy(p->x, p->y + i);
        if (erase) {
        	gotoxy(p->x, p->y + i);
            printf("      "); // Sletter 8 tegn
        } else {
            // Vi bruger %-6s for at sikre at den altid printer 6 tegn
            printf("%-6s", sprites[index][i]);
        }
    }
}
void player_draw(Entity *p) {
	makeplayer(p, 0);
}

void player_tick(Entity *p)
{
//    if (p->left_timer)  p->left_timer--;
//    if (p->right_timer) p->right_timer--;
//
//    if (p->left_timer || p->right_timer) {
//        p->move_counter++;
//
//        if (p->move_counter >= 3) {
//            if (p->left_timer && p->x > 3) {
//                p->x--;
//            }
//            if (p->right_timer && p->x < (99 - p->w)) {
//                p->x++;
//            }
//            p->move_counter = 0;
//        }
//    } else {
//        p->move_counter = 0;
//    }
}
