/*
 * vect.c
 *
 *  Created on: 8 Jan 2026
 *      Author: malik
 */
#include "vect.h"
#include <stdio.h>

#define FIX16_SHIFT 16
#define FIX16_MULT(a,b)  ( (int32_t)(((int64_t)(a) * (b)) >> FIX16_SHIFT) )
#define FIX16_DIV(a,b)   ( (int32_t)(((int64_t)(a) << FIX16_SHIFT) / (b)) )

// initialisere en vector og sætter x og y værdierne
void initVector(vector_t *v, int32_t x, int32_t y){
	(*v).x = x;
	(*v).y = y;
}
