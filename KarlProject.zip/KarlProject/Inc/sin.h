
#ifndef SIN_H_
#define SIN_H_
#include <stdint.h>
#include <stdio.h>

typedef struct {
int32_t x, y;
} vector_t;

void rotateVector(vector_t *v, int16_t angle);
void printFix(int32_t i);
int32_t expand(int32_t i);
int32_t sine(int16_t x);
int32_t cosine(int16_t x);
int abs(int x);


/** Generated using Dr LUT - Free Lookup Table Generator
  * https://github.com/ppelikan/drlut
  **/
// Formula: sin(2*pi*t/T)



#endif /* SIN_H_ */
