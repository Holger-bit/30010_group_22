/*
 * SPil.c
 *
 *  Created on: 12. jan. 2026
 *      Author: root
 */

#include "spil.h"
#include "ansi.h"
#include "startscreen.h"
#include "30010_io.h"
#include "Player_enemies.h"
#include "joys.h"
#include "timer.h"
#include "bullets.h"   // din bullets.h
#include "enemy.h"
#include <stdint.h>

static volatile uint8_t g_tick = 0;

static void on_timer_tick(void)
{
    g_tick = 1;  // kun et flag (hurtigt!)
}

// Vi definerer tilstandene igen, da de skal bruges i manageren
typedef enum {
    STATE_MENU,
    STATE_PLAYING,
    STATE_HELP
} State;

void run_game_manager(void) {
    State currentState = STATE_MENU;
    uint8_t selected = 0;
    char input;

    // Bullet information
    bullet_t bullets[MAX_BULLETS];
    uint8_t next_bullet = 0;

    // enemy infomation
    enemy_t enemies[MAX_ENEMIES];
    uint8_t enemy_count = 0;
    uint8_t enemy_start = 0;
    uint8_t enemy_step = 0;
    uint8_t spawn_x = 2, spawn_y = 2;
    uint16_t spawn_counter = 0, move_counter = 0;


    // Tegn menuen allerførste gang
    maketitle();
    make_menu(selected);


    while (1) {
        switch (currentState) {

            case STATE_MENU:
                input = uart_get_char();
                if (input != 0) {
                    if (input == 'w') {
                        selected = 0;
                        make_menu(selected);
                    } else if (input == 's') {
                        selected = 1;
                        make_menu(selected);
                    } else if (input == 13 || input == 32) { // Enter eller Mellemrum
                        if (selected == 0) {
                            clrscr();
                            // Her kan du tegne din spil-bane ÉN GANG før spillet starter
                            window(1, 1, 100, 50, " SPACE HAM ", 0);

                            bullets_init(bullets, &next_bullet);
                            timer15_setcallback(on_timer_tick);
                            timer15_init();                 // starter TIM15

                            enemy_init(enemies, &enemy_count, &enemy_start, &enemy_step, &spawn_x, &spawn_y);
                            spawn_counter = 0;
                            move_counter = 0;


                            currentState = STATE_PLAYING;
                        } else {
                            clrscr();
                            currentState = STATE_HELP;
                        }
                    }
                }
                break;

            case STATE_PLAYING:
                        {

                            static Entity player = {47, 40, 6, 6, 0};
                            static uint8_t start = 0;

                            if (start == 0) {
                            	setupjoystick();
                                makeplayer(&player, 0);
                                start = 1;
                            }


                            int vx = 0, vy = -2;  // default: straight up

                            switch (player.tilt) {
                                case -2: vx = -2; vy = -1; break;  // hard left
                                case -1: vx = -1; vy = -2; break;  // up-left
                                case  0: vx =  0; vy = -2; break;  // up
                                case  1: vx =  1; vy = -2; break;  // up-right
                                case  2: vx =  2; vy = -1; break;  // hard right
                            }

                            // 1) Læs input
                            char input = uart_get_char();
                            uint8_t joystick = readJoystick();

                            if (input == ' ') {
                                // spawn from ship nose-ish (tweak offsets if you want)
                                shoot(bullets, &next_bullet, player.x + 2, player.y - 1, vx, vy);
                            }


                            // 3) Tick: opdater & tegn bullets
                            if (g_tick) {
                                g_tick = 0;
                                enemy_tick(&enemy_step, &spawn_counter, &move_counter); // updates spawn/move counters (sets enemy_step / enemy_start)

                                // spawn when counter wrapped (since enemy_tick resets spawn_counter at 1000)
								if (spawn_counter == 0) {
									enemy_spawn(enemies, &enemy_count, &enemy_start, &spawn_x, &spawn_y);
								}

								enemy_update_and_render(enemies, enemy_count, &enemy_start, &enemy_step);

								bullets_poll(bullets);  // moves + draws bullets

								enemy_handle_bullets(enemies, &enemy_count, bullets);  // kills enemies if a bullet is inside their box
                            }

                            // Gem den gamle tilstand for at tjekke om vi skal tegne forfra
                            int8_t old_tilt = player.tilt;
                            int32_t old_x = player.x;

                            // 2. JOYSTICK MAPPING (Direkte tilt styring)
                            // Her tjekker vi for kombinationer (skrå retninger)
                            if (joystick == 4) { // Kun Venstre
                                player.tilt = -2;
                            } else if (joystick == 5) { // Op (1) + Venstre (4) = 5
                                player.tilt = -1;
                            } else if (joystick == 1 || joystick == 16) { // Op eller Center
                                player.tilt = 0;
                            } else if (joystick == 9) { // Op (1) + Højre (8) = 9
                                player.tilt = 1;
                            } else if (joystick == 8) { // Kun Højre
                                player.tilt = 2;
                            } else if (joystick == 0) {
                                player.tilt = 0; // Opretning hvis joysticket slippes
                            }

                            // 3. TASTATUR LOGIK (Kun X-bevægelse)
                            if (input == 'a' && player.x > 3) {
                                player.x -= 2;
                            }
                            else if (input == 'd' && player.x < (99 - player.w)) {
                                player.x += 2;
                            }
                            else if (input == 'b') {
                                start = 0;
                                currentState = STATE_MENU;
                                clrscr(); maketitle(); make_menu(0);
                                break;
                            }

                            // 4. TEGN KUN HVIS NOGET HAR ÆNDRET SIG
                            // Dette fjerner flimmer helt!
                            if (player.x != old_x || player.tilt != old_tilt) {
                                // Slet spilleren (vi bruger de gamle koordinater/tilt indirekte her)
                                // Men den nemmeste måde er at slette på de gamle, og tegne på de nye:

                                // Gem de nye værdier midlertidigt
                                int32_t new_x = player.x;
                                int8_t new_tilt = player.tilt;

                                // Slet på gammel position/tilt
                                player.x = old_x;
                                player.tilt = old_tilt;
                                makeplayer(&player, 1);

                                // Tegn på ny position/tilt
                                player.x = new_x;
                                player.tilt = new_tilt;
                                makeplayer(&player, 0);
                            }

                            break;
                        }


            case STATE_HELP:
                gotoxy(10,10);
                printf("BRUG 'W' OG 'S' TIL AT NAVIGERE");
                gotoxy(10,11);
                printf("TRYK 'ENTER' FOR AT VAELGE");
                gotoxy(10,13);
                printf("TRYK 'b' FOR AT GA TILBAGE");

                gotoxy(50,10);
                printf("I 1961 blev chimpansen Ham beloennet med et");
                gotoxy(50,11);
                printf("aeble efter sin succesfulde returrejse til rummet.");

                input = uart_get_char();
                if (input == 'b') {
                	timer15_stop();
                	timer15_setcallback(0);
                	g_tick = 0;
                	currentState = STATE_MENU;
                    maketitle();
                    make_menu(selected);
                }
                break;
        }
    }
}
