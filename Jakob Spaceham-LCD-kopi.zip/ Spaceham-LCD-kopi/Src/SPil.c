/*
 * SPil.c
 *
 *  Created on: 12. jan. 2026
 *      Author: root
 */

#include "spil.h"
#include "startscreen.h"
#include "ansi.h"
#include "30010_io.h"
#include "Player_enemies.h"
#include "EX5.h"
#include "LCDpush.h"
#include <string.h>
#include "LCDpush.h"
#include "charset.h"
#include "projectiles.h"



// Vi definerer tilstandene igen, da de skal bruges i manageren
typedef enum {
    STATE_MENU,
    STATE_PLAYING,
    STATE_HELP
} State;

void run_game_manager(void) {
    State currentState = STATE_MENU;
    uint8_t selected = 0;
    char input;

    // Tegn menuen allerførste gang
    maketitle();
    make_menu(selected);


    while (1) {
        switch (currentState) {

            case STATE_MENU:
                input = uart_get_char();
                if (input != 0) {
                    if (input == 'w') {
                        selected = 0;
                        make_menu(selected);
                    } else if (input == 's') {
                        selected = 1;
                        make_menu(selected);
                    } else if (input == 13 || input == 32) { // Enter eller Mellemrum
                        if (selected == 0) {
                            clrscr();
                            // Her kan du tegne din spil-bane ÉN GANG før spillet starter
                            window(1, 1, 100, 50, " SPACE HAM ", 0);



                            currentState = STATE_PLAYING;
                        } else {
                            clrscr();
                            currentState = STATE_HELP;
                        }
                    }
                }
                break;

            case STATE_PLAYING:
                        {
                            static Entity player = {47, 40, 6, 6, 0};
                            static uint8_t start = 0;
                            static uint32_t fire_timer = 0; // Tæller frames til næste skud
                            static Projectile bullets[MAX_PROJECTILES] = {0};

                            static uint8_t lcd_ready = 0;// *****
                            static uint8_t  buffer[512];// *****
                        	static uint16_t score = 0;// *****

                        	static uint8_t powerup_ready  = 0;  // *****// start: powerup er klar (symbol vises)
                        	static uint8_t powerup_active = 0;  // *****// timer kører ikke endnu

                        	static char timer_str[] = "01234567890123456789"; // *****// 20 tegn
                        	static const uint8_t timer_len = (uint8_t)(sizeof(timer_str) - 1); // *****
                        	static uint8_t timer_offset = 0;// *****
                        	static char hearts[] = "123"; // *****//laver en string som kan aendres
                        	static char bombs[] = "123"; // *****//laver en string som kan aendres

                       	                    // 5. Opdater LCD kun 1 gang pr. sekund (non-blocking)
                       	 	static uint32_t last_lcd_ms = 0;// *****
                       	                    uint32_t now = sys_millis();// *****
                            if (start == 0) {
                            	setupjoystick();
                            	setupLed();
                            	setLed(COLOUR_BLACK);
                                makeplayer(&player, 0);
                           	    start = 1;
                           	    hearts[0] = '1'; hearts[1] = '2'; hearts[2] = '3'; hearts[3] = '\0';//*****
                           	    bombs[0]  = '1'; bombs[1]  = '2'; bombs[2]  = '3'; bombs[3]  = '\0';//*****


                            }

//                            // --- AUTOMATISK SKYDE-LOGIK ---
//                             fire_timer++;
//                             if (fire_timer == 5000) { // Skyd hvert 15. loop (juster tallet for hastighed)
//
//                             }






                             // --- OPDATER ALT ---
                             updateProjectiles(bullets);

                            // 1. Læs begge inputs
                            char input = uart_get_char();
                            uint8_t joystick = readJoystick();

                            // Gem den gamle tilstand for at tjekke om vi skal tegne forfra
                            int8_t old_tilt = player.tilt;
                            int32_t old_x = player.x;

                            // 2. JOYSTICK MAPPING (Direkte tilt styring)
                            // Her tjekker vi for kombinationer (skrå retninger)
                            if (joystick == 4) { // Kun Venstre
                                player.tilt = -2;
                            } else if (joystick == 5) { // Op (1) + Venstre (4) = 5
                                player.tilt = -1;
                            } else if (joystick == 1 || joystick == 16) { // Op eller Center
                                player.tilt = 0;
                            } else if (joystick == 9) { // Op (1) + Højre (8) = 9
                                player.tilt = 1;
                            } else if (joystick == 8) { // Kun Højre
                                player.tilt = 2;
                            } else if (joystick == 0) {
                                player.tilt = 0; // Opretning hvis joysticket slippes
                            }

                            // 3. TASTATUR LOGIK (Kun X-bevægelse)
                            if (input == 'a' && player.x > 3) {
                                player.x -= 2;
                            }
                            else if (input == 'd' && player.x < (99 - player.w)) {
                                player.x += 2;
                            }

                            else if (input == 't') {
								for (int i = 0; i < MAX_PROJECTILES; i++) {
									if (bullets[i].active == 0) { // Find første ledige plads
										bullets[i].active = 1;
										bullets[i].x = player.x + 3; // Skyd fra midten
										bullets[i].y = player.y - 1;
										bullets[i].vy = -1; // Flyver hurtigt opad

										// Direkte mapping fra player tilt til skud-retning
										bullets[i].vx = player.tilt;

										//fire_timer = 0; // NULSTIL tælleren her!
										break;
									}
								}
                            }

                            else if (input == 'q' || input == 'Q') {
                                              lcd_bombs_remove(bombs);
                                                }


                            else if (input == 'r') {// ***** cheatcode
                                                  powerup_ready = 1;// *****
                                              }// *****

                                              if (joystick == 16) {// *****
                                                  if (powerup_ready && !powerup_active) {// *****
                                                      powerup_ready = 0; // *****     // symbol for "klar" forsvinder
                                                      powerup_active = 1; // *****    // timer starter
                                                      timer_offset = 0;// *****

                                                  }
                                              }
                            else if (input == 'b') {

                                lcd_clear(buffer);   // ***** //ryd LCD
                                timer_offset = 0; // ***** //resetter timer
                            	score = 0; // ***** //resetter score
                            	powerup_ready = 0;
                            	setLed(COLOUR_BLACK);
                            	powerup_active = 0;
                            	start = 0; //***** den raekkefoelge // Nulstil så vi tegner korrekt næste gang
                            	currentState = STATE_MENU;
                            	clrscr(); maketitle(); make_menu(0);

                                break;
                            }




                            // 4. TEGN KUN HVIS NOGET HAR ÆNDRET SIG
                            // Dette fjerner flimmer helt!
                            if (player.x != old_x || player.tilt != old_tilt) {
                                // Slet spilleren (vi bruger de gamle koordinater/tilt indirekte her)
                                // Men den nemmeste måde er at slette på de gamle, og tegne på de nye:

                                // Gem de nye værdier midlertidigt
                                int32_t new_x = player.x;
                                int8_t new_tilt = player.tilt;

                                // Slet på gammel position/tilt
                                player.x = old_x;
                                player.tilt = old_tilt;
                                makeplayer(&player, 1);

                                // Tegn på ny position/tilt
                                player.x = new_x;
                                player.tilt = new_tilt;
                                makeplayer(&player, 0);
                            }


                            	//*****
                            //*****
                            //*****
                            //*****
                            //*****



                            if (!lcd_ready) {
                                lcd_init();
                                lcd_ready = 1;
                            }

                            // 4. HUD state (bevares mellem loops)


                            // 1 Hz LCD update
                            if ((uint32_t)(now - last_lcd_ms) >= 1000) {
                                last_lcd_ms = now;

                                memset(buffer, 0x00, sizeof(buffer));

                                // HUD: hearts/score først (eller i den rækkefølge du vil)
                                lcd_write_heart(buffer, hearts, 1);
                                lcd_write_score(buffer, 104, score);
                                lcd_write_bomb(buffer, bombs, 1);

                                // Powerup klar -> ikon
                                if (powerup_ready) {
                                	setLed(COLOUR_BLUE);
                                    lcd_write_powerup(buffer, "1", 385);
                                }

                                // Powerup aktiv -> timer
                                if (powerup_active) {
                                	setLed(COLOUR_PINK);
                                    lcd_write_timer(buffer, timer_str, 451, timer_offset);

                                    if (timer_offset < timer_len) {
                                        timer_offset++;
                                    } else {
                                        powerup_active = 0;   // færdig
                                        setLed(COLOUR_BLACK);
                                        // her slukker du evt. powerup-effekten
                                    }
                                }

                                lcd_push_buffer(buffer);  // <-- KUN HER
                            }
                            break;
                        }


            case STATE_HELP:
                gotoxy(10,10);
                printf("BRUG 'W' OG 'S' TIL AT NAVIGERE");
                gotoxy(10,11);
                printf("TRYK 'ENTER' FOR AT VAELGE");
                gotoxy(10,13);
                printf("TRYK 'b' FOR AT GA TILBAGE");

                gotoxy(50,10);
                printf("I 1961 blev chimpansen Ham beloennet med et");
                gotoxy(50,11);
                printf("aeble efter sin succesfulde returrejse til rummet.");

                input = uart_get_char();
                if (input == 'b') {
                    currentState = STATE_MENU;
                    maketitle();
                    make_menu(selected);
                }
                break;
        }
    }
}
