#include "ansi.h"
#define ESC 0x1B

void clrscr(void) {
	printf("%c[2J%c[H", ESC, ESC);
}

void clreol(void) {
	printf("%c[K", ESC);
}

void gotoxy(uint8_t x, uint8_t y) {
	printf("%c[%d;%dH", ESC, y, x);
}

void underline(uint8_t on) {
	if (on)
		printf("%c[%dm", ESC, 04);
	else
		printf("%c[%dm", ESC, 24);
}

void blink(uint8_t on) {
	if (on)
		printf("%c[%dm", ESC, 05);
	else
		printf("%c[%dm", ESC, 25);
}

void inverse(uint8_t on) {
	if (on)
		printf("%c[%dm", ESC, 07);
	else
		printf("%c[%dm", ESC, 27);
}

void window(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, char *navn, int style) {
	uint8_t Hline;
	uint8_t Vline;
	uint8_t URcorner;
	uint8_t ULcorner;
	uint8_t LRcorner;
	uint8_t LLcorner;
	uint8_t Rconnect;
	uint8_t Lconnect;

	switch (style) {
	case 0:
	    Hline = 205;
	    Vline = 186;
	    URcorner = 187;
	    ULcorner = 201;
	    LRcorner = 188;
	    LLcorner = 200;
	    Lconnect = 185;
	    Rconnect = 204;
	    break;

	case 1:
	    Hline = 196;
	    Vline = 179;
	    URcorner = 191;
	    ULcorner = 218;
	    LRcorner = 217;
	    LLcorner = 192;
	    Lconnect = 180;
	    Rconnect = 195;
	    break;

	default:
	    Hline = '-';
	    Vline = '|';
	    URcorner = '+';
	    ULcorner = '+';
	    LRcorner = '+';
	    LLcorner = '+';
	    Rconnect = '+';
	    Lconnect = '+';
	    break;
	}


	inverse(1);

	// Tegn overskriftsbaggrund
	for(uint8_t i = x1 + 2; i < x2 - 1; i++) {
		gotoxy(i, y1);
		printf("%c", 32);
	}

	// Tegn overskriftstekst
	gotoxy(x1 + 2, y1);
	printf("%s", navn);

	inverse(0);

	// Tegn T-formene
	gotoxy(x1 + 1, y1);
	printf("%c", Lconnect);
	gotoxy(x2 - 1, y1);
	printf("%c", Rconnect);


	// Tegn lodrette
	for(uint8_t i = y1 + 1; i < y2; i++) {
		gotoxy(x1, i);
		printf("%c", Vline);
		gotoxy(x2, i);
		printf("%c", Vline);
	}

	// Tegn bund
	for(uint8_t i = x1 + 1; i < x2; i++) {
		gotoxy(i, y2);
		printf("%c", Hline);
	}

	// Tegn hjørner
	gotoxy(x1, y1);
	printf("%c", ULcorner);
	gotoxy(x2, y1);
	printf("%c", URcorner);
	gotoxy(x1, y2);
	printf("%c", LLcorner);
	gotoxy(x2, y2);
	printf("%c", LRcorner);


	gotoxy(x2, y2);



}

void fgcolor(uint8_t foreground) {
/*  Value      foreground     Value     foreground
    ------------------------------------------------
      0        Black            8       Dark Gray
      1        Red              9       Light Red
      2        Green           10       Light Green
      3        Brown           11       Yellow
      4        Blue            12       Light Blue
      5        Purple          13       Light Purple
      6        Cyan            14       Light Cyan
      7        Light Gray      15       White
*/
  uint8_t type = 22;             // normal text
	if (foreground > 7) {
	  type = 1;                // bold text
		foreground -= 8;
	}
  printf("%c[%d;%dm", ESC, type, foreground+30);
}

void bgcolor(uint8_t background) {
/* IMPORTANT:   When you first use this function you cannot get back to true white background in HyperTerminal.
   Why is that? Because ANSI does not support true white background (ANSI white is gray to most human eyes).
                The designers of HyperTerminal, however, preferred black text on white background, which is why
                the colors are initially like that, but when the background color is first changed there is no
 	              way comming back.
   Hint:        Use resetbgcolor(); clrscr(); to force HyperTerminal into gray text on black background.

    Value      Color
    ------------------
      0        Black
      1        Red
      2        Green
      3        Brown
      4        Blue
      5        Purple
      6        Cyan
      7        Gray
*/
  printf("%c[%dm", ESC, background+40);
}

void color(uint8_t foreground, uint8_t background) {
// combination of fgcolor() and bgcolor() - uses less bandwidth
  uint8_t type = 22;             // normal text
	if (foreground > 7) {
	  type = 1;                // bold text
		foreground -= 8;
	}
  printf("%c[%d;%d;%dm", ESC, type, foreground+30, background+40);
}

void resetbgcolor() {
// gray on black text, no underline, no blink, no reverse
  printf("%c[m", ESC);
}
