#include "timer.h"
#include "stm32f30x_conf.h" // STM32 config

static void (*tick_callback)(void) = 0;

void timer15_setCallback(void (*cb)(void)) {
    tick_callback = cb;
}

void timer15_init(void) {
	RCC->APB2ENR |= RCC_APB2Periph_TIM15;   // Enable clock for TIM15 peripheral
	TIM15->CR1 &= ~TIM_CR1_CEN;             // Disable timer before configuration
	TIM15->PSC = 6399;   // Prescaler: divide 64 MHz clock by (6399 + 1) = 6400 → 10 kHz timer clock
	TIM15->ARR = 99;     // Auto-reload: 100 timer ticks at 10 kHz → interrupt every 0.01 s (100 Hz)
	TIM15->DIER |= TIM_DIER_UIE;   // Enable update interrupt (timer overflow)
	NVIC_SetPriority(TIM1_BRK_TIM15_IRQn, 1); // Set interrupt priority
	NVIC_EnableIRQ(TIM1_BRK_TIM15_IRQn); // Enable interrupt
	TIM15->CR1 |= TIM_CR1_CEN;   // Enable timer counter (start TIM15)
}


void TIM1_BRK_TIM15_IRQHandler(void)
{
	if (TIM15->SR & TIM_SR_UIF) { // Clear update interrupt flag
		TIM15->SR &= ~TIM_SR_UIF;

		if (tick_callback) {
			tick_callback();
		}
	}
}


