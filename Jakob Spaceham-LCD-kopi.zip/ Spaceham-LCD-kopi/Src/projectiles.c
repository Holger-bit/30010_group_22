/*
 * projectiles.c
 *
 *  Created on: 16. jan. 2026
 *      Author: root
 */
#include "projectiles.h"
#include "ansi.h"
#include "30010_io.h"
#include "spil.h"

void updateProjectiles(Projectile bullets[]) {

	static uint32_t move_counter = 0; // Holder styr på frames
	    move_counter++;

	    // Kun flyt skuddene hvis move_counter er f.eks. 3.
	    // Jo højere tal, jo langsommere bevæger de sig.
	    if (move_counter >= 5000) {
	    	for (int i = 0; i < MAX_PROJECTILES; i++) {
	    	        if (bullets[i].active) {
	    	            // 1. Slet gammel (husk at tjekke om vi sletter noget vigtigt)
	    	            gotoxy(bullets[i].x, bullets[i].y);
	    	            printf(" ");

	    	            // 2. Flyt
	    	            bullets[i].x += bullets[i].vx;
	    	            bullets[i].y += bullets[i].vy;

	    	            // 3. Deaktiver hvis de rammer kanten (100x50)
	    	            if (bullets[i].y < 2 || bullets[i].x < 2 || bullets[i].x > 99) {
	    	                bullets[i].active = 0;
	    	            } else {
	    	                // 4. Tegn
	    	                char bullet_char = '*';
	    	                if (bullets[i].vx > 0) bullet_char = '*';
	    	                if (bullets[i].vx < 0) bullet_char = '*';

	    	                gotoxy(bullets[i].x, bullets[i].y);
	    	                printf("%c", bullet_char);
	    	            }
	    	        }
	    	    }
	    		move_counter = 0; // Nulstil tæller
	    }

}
