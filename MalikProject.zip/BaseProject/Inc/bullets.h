/*
 * bullets.h
 *
 *  Created on: 15 Jan 2026
 *      Author: malik
 */

#ifndef BULLETS_H_
#define BULLETS_H_

#include <stdint.h>
#include "vect.h"

#define MAX_BULLETS 10

typedef struct {
    vector_t pos;     // 16.16
    vector_t vel;     // 16.16
    vector_t prev;    // 16.16
    uint8_t active;   // 0 = unused, 1 = active
} bullet_t;

extern bullet_t bullets[MAX_BULLETS];

void initbullet(bullet_t *b, int32_t x, int32_t y, int32_t vx, int32_t vy);
void opdaterbullet(bullet_t *b, int32_t factor);
void tegnbullet(const bullet_t *b);
void sletbullet(const bullet_t *b);
void bullets_set_origin(int x, int y);

void bullets_init(void);
void shoot(int x, int y, int vx, int vy);
void tick(void);              // NEW: timer callback
void bullets_poll(void);

#endif /* BULLETS_H_ */
