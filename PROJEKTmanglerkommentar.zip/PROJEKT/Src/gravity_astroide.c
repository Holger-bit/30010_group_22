#include "gravity_astroide.h"
#include "ansi.h"
#include <stdio.h>

void updateAsteroid(Asteroid *a) {
    // 1. SLET (Erase)
    gotoxy(a->x, a->y);     printf("     ");
    gotoxy(a->x, a->y + 1); printf("     ");
    gotoxy(a->x, a->y + 2); printf("     ");

    // 2. RYK (Move)
    a->x += a->vx;

    // Grænsetjek
    if (a->x > 94) a->x = 2;
    if (a->x < 2) a->x = 94;

    // 3. TEGN (Draw)
    gotoxy(a->x, a->y);     printf(" ___ ");
    gotoxy(a->x, a->y + 1); printf("|   |");
    gotoxy(a->x, a->y + 2); printf("|___|");
}

// En ekstra lille funktion til at "reparere" asteroiden uden at flytte den
void drawAsteroid(Asteroid *a) {
    gotoxy(a->x, a->y);     printf(" ___ ");
    gotoxy(a->x, a->y + 1); printf("|   |");
    gotoxy(a->x, a->y + 2); printf("|___|");
}
