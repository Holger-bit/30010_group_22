/*
 * joys.h
 *
 *  Created on: 13 Jan 2026
 *      Author: malik
 */

#ifndef JOYS_H_
#define JOYS_H_

#include <stdint.h>

// Bit definitioner for readJoystick()
#define JOY_UP      (1 << 0)
#define JOY_DOWN    (1 << 1)
#define JOY_LEFT    (1 << 2)
#define JOY_RIGHT   (1 << 3)
#define JOY_CENTER  (1 << 4)

// funktioner
void setupjoystick(void);
uint8_t readJoystick(void);
void joystickprint(void);


#endif /* JOYS_H_ */
