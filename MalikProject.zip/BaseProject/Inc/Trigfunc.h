/*
 * Trigfunc.h
 *
 *  Created on: 7 Jan 2026
 *      Author: malik
 */

#ifndef TRIGFUNC_H_
#define TRIGFUNC_H_

#include <stdint.h>

void printFix(int32_t i);
int16_t sinus(int32_t vinkel);
int16_t cosinus(int32_t vinkel);

#endif /* TRIGFUNC_H_ */

