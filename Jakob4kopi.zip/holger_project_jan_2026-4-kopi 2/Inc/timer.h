#ifndef TIMER_H_
#define TIMER_H_

void timer15_init(void);
// Optional: allow registering a callback called each tick
void timer15_setCallback(void (*cb)(void));


#endif /* TIMER_H_ */

