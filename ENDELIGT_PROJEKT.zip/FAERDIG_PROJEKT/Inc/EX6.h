/*
 * EX6.h
 *
 *  Created on: 12. jan. 2026
 *      Author: root
 */

#ifndef EX6_H_
#define EX6_H_



#endif /* EX6_H_ */
