#include "boss.h"
#include "ansi.h"

#define HLINE   196   // ─
#define VLINE   179   // │

#define ULC     218   // ┌
#define URC     191   // ┐
#define LLC     192   // └
#define LRC     217   // ┘

#define TDOWN   194   // ┬  (top connects down)
#define TUP     193   // ┴  (bottom connects up)
#define TRIGHT  195   // ├
#define TLEFT   180   // ┤

#define CROSS   197   // ┼

void boss_key(void)
{
    int x = 4;
    int y = 2;

    const int cols = 8;
    const int rows = 24;
    const int cell_w = 11;

    /* Column headers */
    for (int c = 0; c < cols; c++) {
        gotoxy(x + c * (cell_w + 1) + cell_w / 2, y - 1);
        printf("%c", 'A' + c);
    }

    /* Top border */
    gotoxy(x - 1, y);
    printf("%c", ULC);
    for (int c = 0; c < cols; c++) {
        for (int i = 0; i < cell_w; i++) printf("%c", HLINE);
        printf(c == cols - 1 ? "%c" : "%c", c == cols - 1 ? URC : TDOWN);
    }

    /* Rows */
    for (int r = 0; r < rows; r++) {

        /* Row number */
        gotoxy(1, y + r * 2 + 1);
        printf("%2d", r + 1);

        /* Content line */
        gotoxy(x - 1, y + r * 2 + 1);
        printf("%c", VLINE);
        for (int c = 0; c < cols; c++) {
            for (int i = 0; i < cell_w; i++) printf(" ");
            printf("%c", VLINE);
        }

        /* Separator */
        gotoxy(x - 1, y + r * 2 + 2);
        printf("%c", r == rows - 1 ? LLC : TRIGHT);
        for (int c = 0; c < cols; c++) {
            for (int i = 0; i < cell_w; i++) printf("%c", HLINE);
            if (c == cols - 1)
                printf("%c", r == rows - 1 ? LRC : TLEFT);
            else
                printf("%c", r == rows - 1 ? TUP : CROSS);
        }
    }
    gotoxy(x, y + 1);
    printf("I am");
    gotoxy(x + 1 + cell_w, y + 1);
	printf("Working");
    gotoxy(x + 2*(1 + cell_w), y + 1);
	printf("Don't");
    gotoxy(x + 3*(1 + cell_w), y + 1);
	printf("Worry");

    gotoxy(x + 2*(1 + cell_w), 15*y + 1);
	printf("Press \'y\'");
    gotoxy(x + 3*(1 + cell_w), 15*y + 1);
	printf("to go back");
//    gotoxy(x + 4*(1 + cell_w), 15*y + 1);
//	printf("back");
}

