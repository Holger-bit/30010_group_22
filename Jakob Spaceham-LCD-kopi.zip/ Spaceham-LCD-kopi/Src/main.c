#include "stm32f30x_conf.h" // STM32 config
#include "30010_io.h" // Input/output library for this course
#include "ansi.h"
#include "Lut_sin.h"
#include "EX3.h"
#include "EX1.h"
#include "EX4.h"
#include "EX5.h"
#include "SPIL.h"
#include "startscreen.h"
#include "winscreen.h"
#include "LCDpush.h"
#include "timer.h"
#include "system_tick.h"






int main(void) {

	uart_init(115200);

	time_init();
	//timer15_setCallback(system_tick);


	run_game_manager();
}

//winscreen();
