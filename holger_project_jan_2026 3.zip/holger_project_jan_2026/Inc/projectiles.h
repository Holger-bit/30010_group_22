#ifndef PROJECTILES_H_
#define PROJECTILES_H_

#include <stdint.h>
#include "vect.h"

#define MAX_PROJECTILES 50 // Brug dette navn i stedet for MAX_BULLETS

typedef struct {
    vector_t pos;     // 16.16
    vector_t vel;     // 16.16
    vector_t prev;    // 16.16
    uint8_t active;
} bullet_t; // Du kan kalde den bullet_t eller Projectile, bare vær konsistent

void bullets_init(bullet_t bullets[], uint8_t *next_bullet);
void shoot(bullet_t bullets[], uint8_t *next_bullet, int x, int y, int vx, int vy);
void bullets_poll(bullet_t bullets[]);

#endif
