#include "spil.h"
#include "startscreen.h"
#include "ansi.h"
#include "30010_io.h"
#include "Player_enemies.h"
#include "EX5.h"
#include "LCDpush.h"
#include <string.h>
#include "charset.h"
#include "gravity_astroide.h"
#include "timer.h"
#include "projectiles.h"

// --- GLOBALE VARIABLER (Fra opgaverne) ---
static Entity player = {47, 40, 6, 6, 0};
static bullet_t bullets[MAX_PROJECTILES];
static uint8_t next_bullet_idx = 0;

// 'volatile' flaget fra Exercise 6
volatile uint8_t game_tick = 0;

// Callback-funktionen der kun gør én ting: Sætter flaget
void spil_timer_callback(void) {
    game_tick = 1;
}

typedef enum {
    STATE_MENU,
    STATE_PLAYING,
    STATE_HELP
} State;

void run_game_manager(void) {
    State currentState = STATE_MENU;
    uint8_t selected = 0;
    char input;

    maketitle();
    make_menu(selected);

    while (1) {
        switch (currentState) {
            case STATE_MENU:
                input = uart_get_char();
                if (input != 0) {
                    if (input == 'w') { selected = 0; make_menu(selected); }
                    else if (input == 's') { selected = 1; make_menu(selected); }
                    else if (input == 13 || input == 32) {
                        if (selected == 0) {
                            clrscr();
                            window(1, 1, 100, 50, " SPACE HAM ", 0);
                            currentState = STATE_PLAYING;
                        } else {
                            clrscr();
                            currentState = STATE_HELP;
                        }
                    }
                }
                break;

            case STATE_PLAYING:
                        {
                            // --- STATISKE VARIABLE ---
                            static uint8_t start = 0;
                            static uint16_t score = 0;
                            static char hearts[] = "123";
                            static uint8_t buffer[512];

                            // OMDØBT: æ er erstattet med ae (skud_taeller, sten_taeller, lcd_taeller)
                            static uint32_t skud_taeller = 0;
                            static uint32_t sten_taeller = 0;
                            static uint32_t lcd_taeller = 0;

                            // --- INITIALISERING ---
                            if (start == 0) {
                                setupjoystick();
                                setupLed();
                                timer15_init();
                                timer15_setCallback(spil_timer_callback);
                                lcd_init();
                                bullets_init(bullets, &next_bullet_idx);
                                makeplayer(&player, 0);
                                start = 1;
                            }

                            // --- SPIL-MOTOREN ---
                            if (game_tick == 1) {
                                game_tick = 0;

                                char input = uart_get_char();
                                uint8_t joy = readJoystick();
                                int8_t gammel_tilt = player.tilt;
                                int32_t gammel_x = player.x;

                                // NAVIGATION
                                if (joy == 4) player.tilt = -2;
                                else if (joy == 5) player.tilt = -1;
                                else if (joy == 8) player.tilt = 2;
                                else if (joy == 9) player.tilt = 1;
                                else player.tilt = 0;

                                if (input == 'a' && player.x > 3) player.x -= 2;
                                if (input == 'd' && player.x < (99 - player.w)) player.x += 2;

                                // 3. AUTOMATISK SKYDNING (Brug taeller uden ae)
                                skud_taeller++;
                                if (skud_taeller >= 20) {
                                    shoot(bullets, &next_bullet_idx, player.x + 3, player.y - 1, player.tilt, -1);
                                    skud_taeller = 0;
                                }

                                // 4. ASTEROIDEN (Brug taeller uden ae)
                                sten_taeller++;
                                if (sten_taeller >= 3) {
                                    updateAsteroid(&rocky);
                                    sten_taeller = 0;
                                }

                                // 5. SKUD
                                bullets_poll(bullets);

                                // 6. TEGN SPILLER
                                if (player.x != gammel_x || player.tilt != gammel_tilt) {
                                    int32_t ny_x = player.x; int8_t ny_tilt = player.tilt;
                                    player.x = gammel_x; player.tilt = gammel_tilt;
                                    makeplayer(&player, 1);
                                    player.x = ny_x; player.tilt = ny_tilt;
                                }
                                makeplayer(&player, 0);

                                // 7. LCD HUD (Brug taeller uden ae)
                                lcd_taeller++;
                                if (lcd_taeller >= 100) {
                                    memset(buffer, 0x00, 512);
                                    lcd_write_heart(buffer, hearts, 1);
                                    lcd_write_score(buffer, 104, score);
                                    lcd_push_buffer(buffer);
                                    lcd_taeller = 0;
                                }

                                // 8. TILBAGE TIL MENU
                                if (input == 'b') {
                                    start = 0;
                                    currentState = STATE_MENU;
                                    clrscr(); maketitle(); make_menu(0);
                                }
                            }
                        }
                        break;

            case STATE_HELP:
                input = uart_get_char();
                if (input == 'b') {
                    currentState = STATE_MENU;
                    maketitle();
                    make_menu(selected);
                }
                break;
        }
    }
}
