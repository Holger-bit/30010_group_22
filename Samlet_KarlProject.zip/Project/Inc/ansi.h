#ifndef _ANSI_H_
#define _ANSI_H_
/* Includes -------------------------------------------------------------*/
#include <stdint.h>
#include <stdio.h>

void clrscr(void);
void clreol(void);
void gotoxy(uint8_t x, uint8_t y);
void underline(uint8_t on);
void blink(uint8_t on);
void inverse(uint8_t on);
void window(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, char *navn, int style);
void hitWindow(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2);
void moving_ball(uint8_t x, uint8_t y, uint8_t dir);

#endif /* _ANSI_H_ */
