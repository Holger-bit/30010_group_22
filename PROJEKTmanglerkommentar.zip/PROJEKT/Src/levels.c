#include "30010_io.h"
#include "levels.h"
#include "ansi.h"


static uint8_t level = 1;


uint8_t get_lvl(void) {
	return level;
}

void reset_lvl(void) {
	level = 1;
}

void lvlup(void) {
	level++;
}



void print_lvlscreen(void){
	uint8_t x = 5;
	uint8_t y = 5;
	if (level == 1) {
		gotoxy(x, y);
		printf("##       ######## ##     ## ######## ##            ## ");
		gotoxy(x, ++y);
		printf("##       ##       ##     ## ##       ##           ### ");
		gotoxy(x, ++y);
		printf("##       ##       ##     ## ##       ##            ## ");
		gotoxy(x, ++y);
		printf("##       ######   ##     ## ######   ##            ## ");
		gotoxy(x, ++y);
		printf("##       ##        ##   ##  ##       ##            ## ");
		gotoxy(x, ++y);
		printf("##       ##         ## ##   ##       ##            ## ");
		gotoxy(x, ++y);
		printf("##       ##          ###    ##       ##            ## ");
		gotoxy(x, ++y);
		printf("##       ##          ###    ##       ##            ## ");
		gotoxy(x, ++y);
		printf("######## ########    ###    ######## ########      ####");

	}
	else if (level == 2) {
		gotoxy(x, y);
		printf("##       ######## ##     ## ######## ##            ####### ");
		gotoxy(x, ++y);
		printf("##       ##       ##     ## ##       ##           ##     ##");
		gotoxy(x, ++y);
		printf("##       ##       ##     ## ##       ##                  ##");
		gotoxy(x, ++y);
		printf("##       ######   ##     ## ######   ##            ####### ");
		gotoxy(x, ++y);
		printf("##       ##        ##   ##  ##       ##           ##       ");
		gotoxy(x, ++y);
		printf("##       ##         ## ##   ##       ##           ##       ");
		gotoxy(x, ++y);
		printf("##       ##          ###    ##       ##           ##       ");
		gotoxy(x, ++y);
		printf("##       ##          ###    ##       ##           ##       ");
		gotoxy(x, ++y);
		printf("######## ########    ###    ######## ########      ########");

	}
	else if (level == 3) {
		gotoxy(x, y);
		printf("##       ######## ##     ## ######## ##            ####### ");
		gotoxy(x, ++y);
		printf("##       ##       ##     ## ##       ##           ##     ##");
		gotoxy(x, ++y);
		printf("##       ##       ##     ## ##       ##                  ##");
		gotoxy(x, ++y);
		printf("##       ######   ##     ## ######   ##            ####### ");
		gotoxy(x, ++y);
		printf("##       ##        ##   ##  ##       ##                  ##");
		gotoxy(x, ++y);
		printf("##       ##         ## ##   ##       ##           ##     ##");
		gotoxy(x, ++y);
		printf("##       ##          ###    ##       ##           ##     ##");
		gotoxy(x, ++y);
		printf("##       ##          ###    ##       ##           ##     ##");
		gotoxy(x, ++y);
		printf("######## ########    ###    ######## ########      ####### ");

	}
}

