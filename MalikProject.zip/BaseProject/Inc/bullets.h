/*
 * bullets.h
 *
 *  Created on: 15 Jan 2026
 *      Author: malik
 */

#ifndef BULLETS_H_
#define BULLETS_H_

#include <stdint.h>
#include "vect.h"

#define MAX_BULLETS 10

typedef struct {
    vector_t pos;     // 16.16
    vector_t vel;     // 16.16
    vector_t prev;    // 16.16
    uint8_t active;   // 0 = unused, 1 = active
} bullet_t;

void bullets_init(bullet_t bullets[], uint8_t *next_bullet);
void shoot(bullet_t bullets[], uint8_t *next_bullet,
    int x, int y, int vx, int vy
);

void bullets_poll(bullet_t bullets[]);

#endif /* BULLETS_H_ */
