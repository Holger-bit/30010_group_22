#include "game_menu.h"
#include "startscreen.h"
#include "ansi.h"
#include "30010_io.h"

static uint8_t coming_back = 0;

void menu_init(uint8_t *selected)
{
    *selected = 0;
    maketitle();
    make_menu(*selected);
    coming_back = 1;
}

GameState menu_update(uint8_t *selected)
{
	if (coming_back == 0) {
		menu_init(selected);
	}
    char input = uart_get_char();

    if (input == 'w') {
        *selected = 0;
        make_menu(*selected);
    }
    else if (input == 's') {
        *selected = 1;
        make_menu(*selected);
    }
    else if (input == 13 || input == 32) {
        clrscr();
        if (*selected == 0) {
        	coming_back = 0;
            window(1, 1, 100, 50, " SPACE HAM ", 0);
            return STATE_PLAYING;
        }
        else {
        	coming_back = 0;
            return STATE_HELP;
        }
    }

    return STATE_MENU;
}
