#ifndef GAME_PLAY_H
#define GAME_PLAY_H

#include "game_manager.h"

GameState play_update(void);

#endif
