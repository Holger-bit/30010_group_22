/*
 * LED.h
 *
 *  Created on: 19 Jan 2026
 *      Author: karl
 */

#ifndef LED_H_
#define LED_H_

// farve definitioner 0b00000RGB
#define COLOUR_BLACK (0b00000000)
#define COLOUR_RED (0b00000100)
#define COLOUR_GREEN (0b00000010)
#define COLOUR_BLUE (0b00000001)
#define COLOUR_CYAN (0b00000011)
#define COLOUR_PINK (0b00000101)
#define COLOUR_YELLOW (0b00000110)
#define COLOUR_WHITE (0b00000111)

void setLed(uint8_t joystickposition);
void setupLed(void);

#endif /* LED_H_ */
