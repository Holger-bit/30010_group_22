#include "enemy.h"
#include "ansi.h"
#include <stdio.h>
#include "30010_io.h"
#include "EX5.h"
#include "levels.h"

// Variabler
enemy_t enemies[MAX_ENEMIES];
static uint8_t enemy_count = 0;
volatile uint8_t enemy_start = 0;
volatile uint8_t enemy_step = 0;	// En variable, der ikke bliver brugt længere, men det blev opdaget sent, så vi har valgt at lade være med at slætte den
static uint16_t spawn_timer = 0;
static uint16_t move_counter = 0;
static uint8_t level_speed = 1;
static uint16_t score = 0;

// Sætter spawngridet og startpositionerne op
#define GRID_SLOTS 10
#define SLOT_WIDTH 10
#define START_X 2
#define START_Y 2

#define WAVES 5			// Ikke rigtig waves, siden de spawner lidt flydende, men det var en let forståelig måde at sætte arrayet op på
#define NO_SPAWN 255	// Hvis der ikke skal spawne enemies

typedef struct {
    uint8_t delay[GRID_SLOTS*WAVES];
    uint8_t spawned[GRID_SLOTS*WAVES];
} wave_t;

// Spawntider for hver gridpunkt. Hver række er en "wave". Tallet bestemmer hvor mange tick, der skal gå, før der er en fjende, der spawner
static wave_t current_wave = {
    .delay   = {NO_SPAWN, 0,  1, 		NO_SPAWN, NO_SPAWN, NO_SPAWN, NO_SPAWN, 5, 		  2,  		NO_SPAWN,
    			7,		  3,  NO_SPAWN, 8, 		  NO_SPAWN, 6, 		  9, 		NO_SPAWN, 6,  		4,
				10, 	  6,  NO_SPAWN, 12, 	  7, 		NO_SPAWN, 14, 		NO_SPAWN, 10, 		9,
				NO_SPAWN, 9,  10, 		NO_SPAWN, NO_SPAWN, 15, 	  NO_SPAWN, 16, 	  15, 		NO_SPAWN,
				17, 	  12, 18, 		NO_SPAWN, 12, 		NO_SPAWN, 17, 		19, 	  NO_SPAWN, 13},
    .spawned = {0}
};

// Printer en fjende fra et startpunkt (øverste venstre hjørne). "enemy_type" var fordi vi tænkte, at der kunne være forskellige fjender, men det nåede vi ikke
void printEnemy(uint8_t x, uint8_t y, uint8_t enemy_type) {
    if (y < 3) return; // Gør det umuligt at tegne på linje 1 eller 2

    if (enemy_type == 1) {
        fgcolor(2);								// Farver fjenden grøn
        gotoxy(x, y);   printf(" /\\_/\\ ");
        gotoxy(x, y+1); printf("( 0 0 )");
        gotoxy(x, y+2); printf("=(_Y_)=");
        gotoxy(x, y+3); printf("  V-V  ");
        fgcolor(15);
    }
}

// Skriver over fjendens position med mellemrum
void clearEnemy(uint8_t x, uint8_t y) {

    for (int i = 0; i < 4; i++) {
        if (y + i >= 3) { // Tjek hver af de 4 linjer i fjenden. Igen for ikke at tegne på linje 1 eller 2
            gotoxy(x, y + i);
            printf("       ");
        }
    }
}

// Sætter nye fjenders status til i live og giver den gridpositionen, der matcher deres position i arrayet
void spawnEnemyAtColumn(uint8_t col)
{
    for (uint8_t i = 0; i < MAX_ENEMIES; i++) {
        if (!enemies[i].alive) {						// Sørger for at døde fjender ikke overtager en plads i MAX_ENEMIES

            enemies[i].x = START_X + col * SLOT_WIDTH;
            enemies[i].y = START_Y;
            enemies[i].alive = 1;

            if (i >= enemy_count)
                enemy_count = i + 1;

            enemy_start = 1;		// Denne variabel er stadig ligegyldig
            return;
        }
    }
}

// Sætter score op, hvis en fjende dør, fjerne fjenden og sætter dens status til i live. Og leveler op, hvis scoren er høj nok
void killEnemy(enemy_t *dying_enemy) {
	score += 10;
    clearEnemy(dying_enemy->x, dying_enemy->y);
    dying_enemy->alive = 0;
    if (score >= 250) {	// Level up burde egentlig ske ude i SPil.c, så vi ikke risikerer at level op, og dø "på samme tid". Det havde vi bare ikke tid til at fikse
    	lvlup();
    	score = 0;
    }
}

// Gør at man kan få scoren i andre dokumenter
uint16_t get_score(void) {
	return score;
}


void reset_score(void) {
	score = 0;
}

// Tjekker om en fjende rammer bunden. Hvis ja, dræb den.
static uint8_t detectCollision(void)
{
    uint8_t hits = 0;

    for (uint8_t i = 0; i < enemy_count; i++)
    {
        if (enemies[i].alive && enemies[i].y > 44)
        {
            hits++;
            killEnemy(&enemies[i]);
        }
    }

    return hits; // hits' værdi er mængen af skade man tager.
}

// Tællere der bestemmer, hvornår fjender skal spawne og bevæge sig. (Bliver hurtigere når man stiger i level)
void enemy_tick(void) {


    spawn_timer++;
    level_speed = get_lvl(); // Højere level_speed giver hurtigere fjender

// Spawner fjender på de rigtige tispunkter
    for (uint8_t i = 0; i < GRID_SLOTS*WAVES; i++) {
        if (current_wave.delay[i] == NO_SPAWN)
            continue;
        if (!current_wave.spawned[i] &&
            spawn_timer >= current_wave.delay[i] * 200/level_speed) {

            spawnEnemyAtColumn(i % GRID_SLOTS);
            current_wave.spawned[i] = 1;
        }
    }

// Bevæger fjender på de rigtige tidspunkter
    if (++move_counter >= 50/level_speed) {
        enemy_step = 1;
        move_counter = 0;
    }
}

uint8_t enemy_update(void)
{
    uint8_t hits = 0;

    if (enemy_step)
    {
// Flyt alle fjender i live ned en pixel og slet deres fjendetegninger
        for (uint8_t i = 0; i < enemy_count; i++)
        {
            if (enemies[i].alive)
            {
                clearEnemy(enemies[i].x, enemies[i].y);
                enemies[i].y++;
            }
        }

// Tjekker om nogle af fjenderne ramte bunden og hits bliver +1 for hver fjende, der ramte bunden
        hits = detectCollision();

// Tegn alle fjender, der er i live
        for (uint8_t i = 0; i < enemy_count; i++)
        {
            if (enemies[i].alive)
            {
                printEnemy(enemies[i].x, enemies[i].y, 1);
            }
        }

        enemy_step = 0;
    }

    return hits;   // Bliver kaldt i SPil.c for at give skade til spilleren
}

// Genstarter alt enemybaseret. Bortset fra scoren, som var mere overskueligt at skrive hver for sig, når det blev brugt i SPil.c
void init_enemies_session(void) {
    enemy_count = 0;
    enemy_start = 0;	// Bliver stadig ikke brugt til noget
    enemy_step = 0;
    spawn_timer = 0;
    move_counter = 0;

    for(int i = 0; i < GRID_SLOTS * WAVES; i++) {
        current_wave.spawned[i] = 0;
    }
    for(int i = 0; i < MAX_ENEMIES; i++) {
        enemies[i].alive = 0;
    }
}

