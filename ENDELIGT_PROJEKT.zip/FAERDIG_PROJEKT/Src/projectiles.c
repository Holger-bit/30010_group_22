/*
 * projectiles.c
 *
 *  Created on: 16. jan. 2026
 *      Author: root
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "ansi.h"
#include "projectiles.h"
#include "gravity_astroide.h"
#include "enemy.h"

#define FIX16_SHIFT 16
extern uint16_t score;

// SPILLEFELTETS GRÆNSER - Beskytter titellinjen (linje 1 og 2)
#define PLAY_MIN_X 2
#define PLAY_MAX_X 99
#define PLAY_MIN_Y 3
#define PLAY_MAX_Y 49

static void tegnbullet(const bullet_t *b)
{
    if (!b->active) return;

    uint8_t x = (uint8_t)(b->pos.x >> 16);
    uint8_t y = (uint8_t)(b->pos.y >> 16);

    if (y >= PLAY_MIN_Y && y <= PLAY_MAX_Y && x >= PLAY_MIN_X && x <= PLAY_MAX_X) {
        gotoxy(x, y);
        printf("*");
    }
}

static void initbullet(bullet_t *b, int32_t x, int32_t y, int32_t vx, int32_t vy) {
    b->pos.x = x << 16;
    b->pos.y = y << 16;
    b->prev = b->pos;

    // HASTIGHED: Vi deler med 4 for at gøre bevægelsen flydende i terminalen
    b->vel.x = (vx << 16) / 4;
    b->vel.y = (vy << 16) / 4;

    b->active = 1;
}

static void sletbullet(const bullet_t *b) {
    uint8_t x = (uint8_t)(b->prev.x >> 16);
    uint8_t y = (uint8_t)(b->prev.y >> 16);

    if (y >= PLAY_MIN_Y && y <= PLAY_MAX_Y && x >= PLAY_MIN_X && x <= PLAY_MAX_X) {
        gotoxy(x, y);
        printf(" ");
    }
}

static void opdaterbullet(bullet_t *b, Asteroid * rocky) {
    if (!b->active) return;

    b->prev = b->pos;
    int32_t bX = b->pos.x >> 16;
    int32_t bY = b->pos.y >> 16;

    // --- 1. TYNGDEKRAFT (Radial Influence) ---
    // Vi beregner afstanden til asteroidens midte (x+2, y+1)
    int32_t dist_x = (rocky->x + 2) - bX;
    int32_t dist_y = (rocky->y + 1) - bY;

    // Tjek om skuddet er tæt på (12 vandret, 8 lodret)
    if (labs(dist_x) < 12 && labs(dist_y) < 8) {
        // Vi bruger 1 << 15 (en halv pixel) som sugekraft pr. tick
        if (dist_x > 0) b->pos.x += (1 << 15);
        else if (dist_x < 0) b->pos.x -= (1 << 15);

        // Suger også en lille smule i Y-retning for realisme
        if (dist_y > 0) b->pos.y += (1 << 14);
        else if (dist_y < 0) b->pos.y -= (1 << 14);
    }

    // --- 2. KOLLISION MED ASTEROIDE ---
    if (bX >= rocky->x && bX < (rocky->x + 5) && bY >= rocky->y && bY < (rocky->y + 3)) {
        b->active = 0;
        return;
    }

    // --- 3. KOLLISION MED FJENDER ---
    for (int e = 0; e < MAX_ENEMIES; e++) {
        if (enemies[e].alive) {
            if (bX >= enemies[e].x && bX < (enemies[e].x + 7) &&
                bY >= enemies[e].y && bY < (enemies[e].y + 4))
            {
                b->active = 0;
                killEnemy(&enemies[e]);
                score += 10;
                return;
            }
        }
    }

    // --- 4. BEVÆGELSE ---
    b->pos.x += b->vel.x;
    b->pos.y += b->vel.y;

    // --- 5. KANT-TJEK ---
    bX = b->pos.x >> 16;
    bY = b->pos.y >> 16;
    if (bX < PLAY_MIN_X || bX > PLAY_MAX_X || bY < PLAY_MIN_Y || bY > PLAY_MAX_Y) {
        b->active = 0;
    }
}

void bullets_init(bullet_t bullets[], uint8_t *next_bullet) {
    for (int i = 0; i < MAX_PROJECTILES; i++) bullets[i].active = 0;
    *next_bullet = 0;
}

void shoot(bullet_t bullets[], uint8_t *next_bullet, int x, int y, int vx, int vy) {
    initbullet(&bullets[*next_bullet], x, y, vx, vy);
    (*next_bullet)++;
    if (*next_bullet >= MAX_PROJECTILES) *next_bullet = 0;
}

void updateProjectiles(bullet_t bullets[], Asteroid * rocky) {
    for (int i = 0; i < MAX_PROJECTILES; i++) {
        if (bullets[i].active) {
            sletbullet(&bullets[i]);
            opdaterbullet(&bullets[i], rocky);

            if (bullets[i].active) {
                tegnbullet(&bullets[i]);
            }
        }
    }
}

void spawnExplosionShots(bullet_t bullets[], int x, int y)
{
	const int dirs[7][2] = {
		{ 0,-1}, { 1, 0}, {-1, 0},
		{ 1,-1}, {-1,-1}, { 1, 1}, {-1, 1}
	};

	for (int d = 0; d < 7; d++) {
		// find en ledig bullet-slot
		for (int j = 0; j < MAX_PROJECTILES; j++) {
			if (bullets[j].active == 0) {


				bullets[j].pos.x = x << 16;
				bullets[j].pos.y = y << 16;
				bullets[j].prev = bullets[j].pos;
				bullets[j].vel.x = (dirs[d][0] << 16) / 4;
				bullets[j].vel.y = (dirs[d][1] << 16) / 4;
				bullets[j].active = 1;
				break;
			}
		}
	}
}


void updateBombs(Bomb bombs[], bullet_t bullets[])
{
    static uint32_t move_counter = 0;
    move_counter++;

    if (move_counter >= 5)
    {
        for (int i = 0; i < MAX_BOMBS; i++)
        {
            if (!bombs[i].active) continue;

            // 1) Genskab det der var under bomben før
            gotoxy(bombs[i].x, bombs[i].y);
            printf("%c", bombs[i].under_char);

            // 2) Flyt
            bombs[i].x += bombs[i].vx;
            bombs[i].y += bombs[i].vy;

            // 3) Fuse ned
            bombs[i].fuse--;

            if (bombs[i].fuse <= 0)
            {
                spawnExplosionShots(bullets, bombs[i].x, bombs[i].y);
                bombs[i].active = 0;
                continue;
            }

            // 4) Deaktiver hvis ude af banen
            if (bombs[i].y < 3 || bombs[i].x < 2 || bombs[i].x > 99 || bombs[i].y > 49)

            {
                bombs[i].active = 0;
                continue;
            }

            // 5) Gem baggrund på ny position
            bombs[i].under_char = ' ';

            // 6) Tegn bomben
            gotoxy(bombs[i].x, bombs[i].y);
            printf("*");
        }

        move_counter = 0;
    }
}




