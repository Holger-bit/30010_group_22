/*
 * EX6.c
 *
 *  Created on: 12. jan. 2026
 *      Author: root
 */



