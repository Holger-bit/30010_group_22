/*
 * enemy.c
 *
 *  Created on: 20. jan. 2026
 *      Author: root
 */
#include "enemy.h"
#include "ansi.h"
#include <stdio.h>
#include "30010_io.h"
#include "EX5.h"

// Variabler (Fjernet static på enemies så projectiles.c kan se dem)
enemy_t enemies[MAX_ENEMIES];
static uint8_t enemy_count = 0;
volatile uint8_t enemy_start = 0;
volatile uint8_t enemy_step = 0;
static uint16_t spawn_timer = 0;
static uint16_t move_counter = 0;

#define GRID_SLOTS 9
#define SLOT_WIDTH 9
#define START_X 4
#define START_Y 3

typedef struct {
    uint8_t delay[GRID_SLOTS];
    uint8_t spawned[GRID_SLOTS];
} wave_t;

static wave_t current_wave = {
    .delay   = {3, 0, 1, 3, 2, 1, 4, 5, 6},
    .spawned = {0}
};

void printEnemy(uint8_t x, uint8_t y, uint8_t enemy_type) {
    if (y < 3) return; // SIKKERHED: Tegn aldrig på linje 1 eller 2

    if (enemy_type == 1) {
        fgcolor(2);
        gotoxy(x, y);   printf(" /\\_/\\ ");
        gotoxy(x, y+1); printf("( 0 0 )");
        gotoxy(x, y+2); printf("=(_Y_)=");
        gotoxy(x, y+3); printf("  V-V  ");
        fgcolor(15);
    }
}

void clearEnemy(uint8_t x, uint8_t y) {

    for (int i = 0; i < 4; i++) {
        if (y + i >= 3) { // Tjek hver af de 4 linjer i fjenden
            gotoxy(x, y + i);
            printf("       ");
        }
    }
}
void spawnEnemyAtColumn(uint8_t col) {
    if (enemy_count >= MAX_ENEMIES) return;
    enemies[enemy_count].x = START_X + col * SLOT_WIDTH;
    enemies[enemy_count].y = START_Y;
    enemies[enemy_count].alive = 1;
    enemy_count++;
    enemy_start = 1;
}

void killEnemy(enemy_t *dying_enemy) {
    clearEnemy(dying_enemy->x, dying_enemy->y);
    dying_enemy->alive = 0;
    // Her kan du kalde score++ hvis du har extern score;
}

void detectCollision(void) {
    for (uint8_t i = 0; i < enemy_count; i++) {
        if (enemies[i].alive && enemies[i].y > 44) {
            killEnemy(&enemies[i]);
        }
    }
}

void enemy_tick(void) {


    spawn_timer++; // Tæller hver frame (10ms)

    /* ---- Wave spawner ---- */
    for (uint8_t i = 0; i < GRID_SLOTS; i++) {
        if (!current_wave.spawned[i] && spawn_timer >= current_wave.delay[i] * 200) {
            spawnEnemyAtColumn(i);
            current_wave.spawned[i] = 1;
        }
    }

    /* ---- Enemy movement rate ---- */
    if (++move_counter >= 70) {
        enemy_step = 1;
        move_counter = 0;
    }
}

void enemy(void) {
    if (enemy_step) {
        for (uint8_t i = 0; i < enemy_count; i++) {
            if (enemies[i].alive) {
                clearEnemy(enemies[i].x, enemies[i].y);
                enemies[i].y++;
            }
        }
        detectCollision();
        for (uint8_t i = 0; i < enemy_count; i++) {
            if (enemies[i].alive) {
                printEnemy(enemies[i].x, enemies[i].y, 1);
            }
        }
        enemy_step = 0;
    }

    if (enemy_start) {
        printEnemy(enemies[enemy_count-1].x, enemies[enemy_count-1].y, 1);
        enemy_start = 0;
    }
}

void init_enemies_session(void) {
    enemy_count = 0;
    enemy_start = 0;
    enemy_step = 0;
    spawn_timer = 0;   // <--- NU KAN VI NULSTILLE DEN!
    move_counter = 0;  // <--- OG DENNE!

    for(int i = 0; i < GRID_SLOTS; i++) {
        current_wave.spawned[i] = 0;
    }
    for(int i = 0; i < MAX_ENEMIES; i++) {
        enemies[i].alive = 0;
    }
}

