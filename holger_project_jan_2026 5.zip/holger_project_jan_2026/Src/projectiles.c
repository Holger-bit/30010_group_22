/*
 * projectiles.c
 *
 *  Created on: 16. jan. 2026
 *      Author: root
 */



//HOLGER GAMMEL KODE
//#include "projectiles.h"
//#include "ansi.h"
//#include "30010_io.h"
//#include "spil.h"
//#include "gravity_astroide.h"
//#include <stdint.h>
//#include <stdio.h>
//#include <stdlib.h>

//void updateProjectiles(Projectile bullets[]) {
//    static uint8_t move_counter = 0;
//
//    // Vi kører kun logikken hver 5. frame for at styre farten
//    if (++move_counter >= 5) {
//        for (int i = 0; i < MAX_PROJECTILES; i++) {
//            if (bullets[i].active) {
//
//                // 1. SLET skuddet på dets nuværende plads med det samme!
//                gotoxy(bullets[i].x, bullets[i].y);
//                printf(" ");
//
//                // 2. TYNGDEKRAFT (Beregnes mens skuddet er "i luften")
//                // Asteroiden er y, y+1, y+2 høj. Midten er y+1.
//                int32_t dist_x = (rocky.x + 2) - bullets[i].x;
//                int32_t dist_y = (rocky.y + 1) - bullets[i].y;
//
//                if (labs(dist_x) < 12 && labs(dist_y) < 8) {
//                    if (dist_x > 0) bullets[i].x++;
//                    else if (dist_x < 0) bullets[i].x--;
//                }
//
//                // 3. RYK skuddet (Hastighed)
//                bullets[i].x += bullets[i].vx;
//                bullets[i].y += bullets[i].vy;
//
//                // 4. TJEK KOLLISION (Ramte vi asteroiden nu?)
//                if (bullets[i].x >= rocky.x && bullets[i].x < (rocky.x + 5) &&
//                    bullets[i].y >= rocky.y && bullets[i].y < (rocky.y + 3))
//                {
//                    bullets[i].active = 0; // Skuddet dør
//                    continue; // Gå videre til næste skud i arrayet
//                }
//
//                // 5. TJEK KANT (Er skuddet røget ud af banen?)
//                if (bullets[i].y < 2 || bullets[i].x < 2 || bullets[i].x > 98) {
//                    bullets[i].active = 0;
//                    continue;
//                }
//
//                // 6. TEGN skuddet på den nye position
//                gotoxy(bullets[i].x, bullets[i].y);
//                printf("*");
//            }
//        }
//        move_counter = 0; // Nulstil farten
//    }
//}


#include <stdio.h>
#include <stdlib.h> // VIGTIG: Fixer labs() og abs() fejlen
#include <stdint.h>
#include "ansi.h"
#include "projectiles.h"
#include "gravity_astroide.h"

#define FIX16_SHIFT 16

// SPILLEFELTETS GRÆNSER - Rettet for at beskytte titellinjen
#define PLAY_MIN_X 2
#define PLAY_MAX_X 99
#define PLAY_MIN_Y 3  // Vi starter ved 3, fordi linje 1 og 2 er ramme + titel
#define PLAY_MAX_Y 49

static void initbullet(bullet_t *b, int32_t x, int32_t y, int32_t vx, int32_t vy) {
    b->pos.x = x << 16;
    b->pos.y = y << 16;
    b->prev = b->pos;

    // HASTIGHED: Vi deler med 8 for at gøre dem endnu langsommere
    b->vel.x = (vx << 16) / 4;
    b->vel.y = (vy << 16) / 4;

    b->active = 1;
}

static void sletbullet(const bullet_t *b) {
    uint8_t x = (uint8_t)(b->prev.x >> 16);
    uint8_t y = (uint8_t)(b->prev.y >> 16);
    // SLET KUN hvis vi er under titellinjen (y >= 3)
    if (y >= PLAY_MIN_Y && y <= PLAY_MAX_Y && x >= PLAY_MIN_X && x <= PLAY_MAX_X) {
        gotoxy(x, y);
        printf(" ");
    }
}

static void opdaterbullet(bullet_t *b) {
    if (!b->active) return;
    b->prev = b->pos;

    int32_t bX = b->pos.x >> 16;
    int32_t bY = b->pos.y >> 16;

    // TYNGDEKRAFT (Brug labs() til int32_t)
    int32_t dist_x = (rocky.x + 2) - bX;
    int32_t dist_y = (rocky.y + 1) - bY;
    if (labs(dist_x) < 12 && labs(dist_y) < 8) {
        if (dist_x > 0) b->pos.x += (1 << 13);
        else if (dist_x < 0) b->pos.x -= (1 << 13);
    }

    // KOLLISION MED ASTEROIDE
    if (bX >= rocky.x && bX < (rocky.x + 5) && bY >= rocky.y && bY < (rocky.y + 3)) {
        b->active = 0;
        return;
    }

    // BEVÆGELSE
    b->pos.x += b->vel.x;
    b->pos.y += b->vel.y;

    // TJEK KANT (Dræb skuddet før det rammer titlen på linje 2)
    bX = b->pos.x >> 16;
    bY = b->pos.y >> 16;
    if (bY < PLAY_MIN_Y || bX < PLAY_MIN_X || bX > PLAY_MAX_X || bY > PLAY_MAX_Y) {
        b->active = 0;
    }
}

void bullets_init(bullet_t bullets[], uint8_t *next_bullet) {
    for (int i = 0; i < MAX_PROJECTILES; i++) bullets[i].active = 0;
    *next_bullet = 0;
}

void shoot(bullet_t bullets[], uint8_t *next_bullet, int x, int y, int vx, int vy) {
    initbullet(&bullets[*next_bullet], x, y, vx, vy);
    (*next_bullet)++;
    if (*next_bullet >= MAX_PROJECTILES) *next_bullet = 0;
}

void bullets_poll(bullet_t bullets[]) {
    for (int i = 0; i < MAX_PROJECTILES; i++) {
        if (bullets[i].active) {
            sletbullet(&bullets[i]);
            opdaterbullet(&bullets[i]);
            if (bullets[i].active) {
                gotoxy(bullets[i].pos.x >> 16, bullets[i].pos.y >> 16);
                printf("*");
            }
        }
    }
}
