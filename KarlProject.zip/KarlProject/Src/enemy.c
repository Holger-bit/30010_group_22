#include "enemy.h"
#include "ansi.h"
#include <stdio.h>
#include "joystick.h"
#include "levels.h"

static enemy_t enemies[MAX_ENEMIES];
static uint8_t enemy_count = 0;
volatile uint8_t enemy_start = 0;
volatile uint8_t enemy_step = 0;

void moveEnemies(void) {
	for (uint8_t i = 0; i < enemy_count; i++) {
		if (enemies[i].alive) {
			enemies[i].y++;
			enemy_step = 1;
		}
	}
}

void printEnemy(uint8_t x, uint8_t y, uint8_t enemy_type) {
	switch (enemy_type){
	case 1:
		gotoxy(x, y);
		printf(" /\\_/\\ ");
		gotoxy(x, y+1);
		printf("( 0 0 )");
		gotoxy(x, y+2);
		printf("=(_Y_)=");
		gotoxy(x, y+3);
		printf("  V-V  ");
		break;
	}
}

void clearEnemy(uint8_t x, uint8_t y) {
	gotoxy(x, y);
	printf("       ");
	gotoxy(x, y+1);
	printf("       ");
	gotoxy(x, y+2);
	printf("       ");
	gotoxy(x, y+3);
	printf("       ");
}

void spawnEnemy(void) {
	static uint8_t start_x = 2;
	static uint8_t start_y = 0;

    enemies[enemy_count].x = start_x;
    enemies[enemy_count].y = start_y;
    enemies[enemy_count].alive = 1;
    enemy_count++;

    start_x += 9;
    if (start_x > 90) {
    	start_x = 0;
    }
    enemy_start = 1;   // signal, not print
}

void killEnemy(enemy_t *dying_enemy) {
	clearEnemy(dying_enemy->x, dying_enemy->y);
	dying_enemy->alive = 0;
	dying_enemy->x = 0;
	dying_enemy->y = 0;
	lvlup();
}

void detectCollision(void) {
	for (uint8_t i = 0; i < enemy_count; i++) {
		if (enemies[i].y > 50-4) {
			killEnemy(&enemies[i]);
		}
	}
}

void enemy_tick(void)
{
    static uint16_t spawn_counter = 0;
    static uint16_t move_counter = 0;

    if (++spawn_counter >= 1000) {
        spawnEnemy();
        spawn_counter = 0;
    }
    if (++move_counter >= 100) {
    	enemy_step = 1;
    	move_counter = 0;
    }

}

void enemy(void) {
	if (enemy_step) {

		// 1. Move
		for (uint8_t i = 0; i < enemy_count; i++) {
			if (enemies[i].alive) {
				enemies[i].y++;
			}
		}

		// 2. Collisions
		detectCollision();

		// 3. Render
		for (uint8_t i = 0; i < enemy_count; i++) {
			if (enemies[i].alive) {
				clearEnemy(enemies[i].x, enemies[i].y - 1);
				printEnemy(enemies[i].x, enemies[i].y, 1);
			}
		}

		enemy_step = 0;
	}
	static uint8_t j_old = 0;
	static uint8_t kill_count = 0;
	uint8_t j = readJoystick();


	if (enemy_step) {
		for (uint8_t i = 0; i < enemy_count; i++) {
			if (enemies[i].alive) {
				clearEnemy(enemies[i].x, enemies[i].y-1);
				printEnemy(enemies[i].x, enemies[i].y, 1);
			}
		}
		enemy_step = 0;
	}

	if (enemy_start) {
		printEnemy(enemies[enemy_count-1].x, enemies[enemy_count-1].y, 1);
		enemy_start = 0;
	}

	if (j != j_old) {
		if (j & (1 << 4)) {        // center pressed
			killEnemy(&enemies[kill_count]);
			kill_count++;

		}
	}
	j_old = j;

	detectCollision();
}
