/*
 * RGB.h
 *
 *  Created on: 13 Jan 2026
 *      Author: malik
 */

#ifndef RGB_H_
#define RGB_H_

#include <stdint.h>

typedef enum {
    LED_OFF = 0,
    LED_RED,
    LED_GREEN,
    LED_BLUE,
    LED_CYAN,     // G + B
    LED_MAGENTA,  // R + B
    LED_YELLOW,   // R + G
    LED_WHITE     // R + G + B
} LedColor;

void rgb_init(void);
void setLed(LedColor c);
void joytoRGB(uint8_t js);

#endif /* RGB_H_ */
