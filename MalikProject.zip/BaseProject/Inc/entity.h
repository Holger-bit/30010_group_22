/*
 * entity.h
 *
 *  Created on: 15 Jan 2026
 *      Author: malik
 */

#ifndef ENTITY_H_
#define ENTITY_H_

#include <stdint.h>

typedef struct {
    int16_t x, y;
    int16_t prev_x, prev_y;
    char ch;
} entity_t;

void entity_erase(const entity_t *e);
void entity_draw(const entity_t *e);

#endif /* ENTITY_H_ */
