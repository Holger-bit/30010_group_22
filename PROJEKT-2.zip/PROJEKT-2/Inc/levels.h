#ifndef LEVELS_H_
#define LEVELS_H_

void lvlup(void);
uint8_t get_lvl(void);
void print_lvlscreen(void);
void reset_lvl(void);

#endif
